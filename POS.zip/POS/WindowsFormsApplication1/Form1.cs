﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IngenicoDLL;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            IngenicoIntegration _ingenico = new IngenicoIntegration();
            string strMsg = _ingenico.SendSale(txtIPAddress.Text.Trim(), Convert.ToInt32(txtPort.Text.Trim()), Convert.ToDouble(txtAmount.Text.Trim()));
            
            MessageBox.Show(strMsg);
        }
    }
}
