﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace IngenicoDLL
{
    public class IngenicoIntegration
    {
        public string SendSale(string strIPAddress, int intPort, Double dblSaleAmount)
        {
            try
            {
                

                string strSale = "001" + (dblSaleAmount * 100).ToString();
                string returnMsg = "";
                IPAddress ipAddress = IPAddress.Parse(strIPAddress);
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, intPort);
                Char fs = (char)0x1c;
                StringBuilder stringMsg = new StringBuilder();
                stringMsg.Append("00");
                stringMsg.Append(fs);
                stringMsg.Append(strSale);
                string message = stringMsg.ToString();
                


                //Socket listner = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                //listner.Connect(remoteEP);
                ////byte[] msg = Encoding.ASCII.GetBytes("30 30 3c 46 53 3e 30 30 31 31 30 30 30");
                //int bytesSent = listner.BeginSend(msg);

                //int bytesRec = listner.ReceiveAsync(bytes);
                //var responseData = System.Text.Encoding.ASCII.GetString(bytes, 0, bytesRec);

                SocketClient _object = new SocketClient();
                returnMsg = _object.StartClient(strIPAddress, intPort, message);
                return returnMsg;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            

        }
    }
}
