<?php 
/* Template Name: Price Listing */
get_header();  
$imic_options = get_option('imic_options');
/* Page Banner HTML
=============================*/
imic_page_banner($pageID = get_the_ID()); 
$id = get_the_ID();
if(isset($imic_options['sidebar_width'])&&$imic_options['sidebar_width'] != ''){
	$ContentWidth = 12 - $imic_options['sidebar_width'];
	$SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($id,'imic_select_sidebar_width', true);
if($pageSidebarWidth != ''){
	$ContentWidth = 12 - $pageSidebarWidth;
	$SidebarWidth = $pageSidebarWidth;
}
$pageSidebar = get_post_meta($id,'imic_select_sidebar_from_list',true);
if(!empty($pageSidebar)&&is_active_sidebar($pageSidebar))
{
	$class = $ContentWidth;
}
else
{
	$class = 12;  
} ?>
  <!-- Start Content -->
<div class="main" role="main">
    <div id="content" class="content full">
		<div class="container">
			<div class="page">
				<div class="row">
					<div class="col-md-<?php echo esc_attr($class); ?> pricing-page" id="content-col">
                    	
                        	<?php if(have_posts()):while(have_posts()):the_post();
							  the_content();
							  endwhile; endif; ?>
                    
						<?php
                        if(isset($imic_options['plan_group'])){
                        	$plan_group= $imic_options['plan_group']; 
                        }else{
                        	$plan_group='';
                        } 
                        if(!empty($plan_group)&&(isset($imic_options['plan_show_option']))&&!empty($imic_options['plan_show_option'])){
                        	$payment_url = imic_get_template_url('template-payment.php');
                        	$count_words = array( "zero", "one" , "two", "three", "four","five","six","seven","eight","nine","ten");?>
                        	<div class="pricing-table <?php echo esc_attr($count_words[count($plan_group)]); ?>-cols margin-40">
                        	<?php  foreach($plan_group as $new_plan_group){
								$popular_active = (isset($imic_options['popular_plan']))?$imic_options['popular_plan']:'';
								$popular_reason = (isset($imic_options['popular_plan_text']))?$imic_options['popular_plan_text']:'';
								$hightlight_class = '';
								$highlight_reason = '';
								if($popular_active == $new_plan_group['title']){
									$hightlight_class = 'highlight';
									$highlight_reason = '<span class="highlight-reason">'.$popular_reason.'</span>';
								}
                        		$payment_url=esc_url(add_query_arg('payment',str_replace(' ' , '-', $new_plan_group['title'] ),$payment_url));
                        		echo'<div class="pricing-column '.$hightlight_class.'">
                        		<h3>'.$new_plan_group['title'].''
								.$highlight_reason.'</h3>';
                        		echo '<div class="pricing-column-content">';
                        			if(!empty($new_plan_group['property_price'])){
                        				$currency_symbol = imic_get_currency_symbol(get_option('paypal_currency_options')); 
                        				echo'<h4> <span class="dollar-sign">'.$currency_symbol.'</span> '.$new_plan_group['property_price'].' </h4>';
                       				}
                        			if(!empty($new_plan_group['number_of_property'])){
                        				echo '<ul>';
                        					echo'<li><strong>'.$new_plan_group['number_of_property'].esc_html__(' Listings','framework').'</strong></li>';
                        				echo '</ul>';
                        			}
                        			if(!empty($new_plan_group['property_description'])){
                        				echo '<ul class="features">';
                        					$plan_description = explode('.',$new_plan_group['property_description']);
                        					foreach($plan_description as $plan_description){
                        						if(!empty($plan_description)){
                         							echo'<li>'.$plan_description.'</li>';
                        						}
											}
                        				echo '</ul>';
                        			}
                        			echo'<a class="btn btn-primary" href="'.$payment_url.'">'.esc_html__('Sign up now!','framework').'</a> </div></div>';
                        		} ?>
 							</div>
						<?php }
						else{
   							echo '<div class="alert alert-info">'.esc_html__('Sorry, no paid property plans available for now.','framework').'</div>';    
						}?>
					</div>
					<!-- Start Sidebar -->
					<?php if(!empty($pageSidebar)&&is_active_sidebar($pageSidebar)) { ?>
                        <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
                            <?php dynamic_sidebar($pageSidebar); ?>
                        </div>
                    <?php } ?> 
				</div> 
			</div>
      	</div>
	</div>
</div>
<?php get_footer(); ?>