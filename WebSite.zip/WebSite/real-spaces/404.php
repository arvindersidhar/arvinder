<?php
header("HTTP/1.1 404 Not Found");
header("Status: 404 Not Found");
get_header();
$imic_options = get_option('imic_options');
//Banner Image from Theme Options
if (isset($imic_options['banner_image']) && !empty($imic_options['banner_image']['url'])) {
  ?>
  <!-- Site Showcase -->
  <div class="site-showcase">
    <!-- Start Page Header -->
    <div class="parallax page-header" style="background-image:url(<?php echo esc_url($imic_options['banner_image']['url']); ?>);">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1><?php esc_html_e('404 Error', 'framework'); ?></h1>
          </div>
        </div>
      </div>
    </div>
    <!-- End Page Header -->
  </div>
<?php } ?>
<!-- Start Content -->
<div class="main" role="main">
  <div id="content" class="content full">
    <div class="container">
      <div class="page error-404">
        <div class="row">
          <div class="col-md-12">
            <h2><i class="fa fa-exclamation-triangle"></i> <?php esc_html_e('404', 'framework'); ?></h2>
            <p><?php esc_html_e('Sorry, the page you are looking for cannot be found! Trying search for a page or return to the', 'framework'); ?> <a href="<?php echo site_url(); ?>"><?php esc_html_e('home', 'framework'); ?></a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>