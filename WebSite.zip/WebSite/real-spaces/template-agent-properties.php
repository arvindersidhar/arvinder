<?php
/* Template Name: Agent Properties */
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
global $current_user; //Theme Global Variable
$currency_decimal_point = (isset($imic_options['currency_decimal_point'])) ? $imic_options['currency_decimal_point'] : '';
$currency_decimal_point = ($currency_decimal_point == '') ? 0 : $currency_decimal_point;
$currency_thousand_separator = (isset($imic_options['currency_thousand_separator'])) ? $imic_options['currency_thousand_separator'] : '';
$currency_decimal_separator = (isset($imic_options['currency_decimal_separator'])) ? $imic_options['currency_decimal_separator'] : '';
wp_get_current_user(); // Make sure global is set, if not set it.
if ((user_can($current_user, "agent")) || (user_can($current_user, "administrator"))) {
    /* Site Showcase */
    imic_page_banner($pageID = get_the_ID());
    /* End Site Showcase */
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
    global $current_user;
    $currency_symbol = (isset($imic_options['currency-select'])) ? imic_get_currency_symbol($imic_options['currency-select']) : '';
    wp_get_current_user();
    if (get_query_var('remove')) {
        $delete_id = get_query_var('remove');
        $post_author = get_post_field('post_author', $delete_id);
        $user_name = $current_user->ID;
        if ($post_author == $user_name) {
            wp_trash_post($delete_id);
        }
    }
    $edit_url = imic_get_template_url('template-submit-property.php');

    $id = get_the_ID();
    if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
        $ContentWidth = 12 - $imic_options['sidebar_width'];
        $SidebarWidth = $imic_options['sidebar_width'];
    }
    $pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
    if ($pageSidebarWidth != '') {
        $ContentWidth = 12 - $pageSidebarWidth;
        $SidebarWidth = $pageSidebarWidth;
    }
    $pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
    if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
        $class = $ContentWidth;
    } else {
        $class = 12;
    }
    ?>
    <!-- Start Content -->
    <div class="main" role="main">
        <div id="content" class="content full">
            <div class="container">
                <div class="page">
                    <div class="row">
                        <div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">

                            <?php if (have_posts()) : while (have_posts()) : the_post();
                                    the_content();
                                endwhile;
                            endif; ?>

                            <div class="block-heading" id="details">
                                <?php
                                if (!empty($edit_url)) :
                                    echo '<a href="' . $edit_url . '" class="btn btn-sm btn-primary pull-right">' . esc_html__('Add new property ', 'framework') . '<i class="fa fa-long-arrow-right"></i></a>';
                                endif; ?>
                                <h4><span class="heading-icon"><i class="fa fa-home"></i></span><?php esc_html_e('Listed Properties', 'framework'); ?></h4>
                            </div>
                            <?php query_posts(array('post_type' => 'property', 'author' => $current_user->ID, 'paged' => $paged));
                            if (have_posts()) : ?>
                                <div class="properties-table">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th><?php esc_html_e('Image', 'framework'); ?></th>
                                                <th width="20%"><?php esc_html_e('Name', 'framework'); ?></th>
                                                <th width="12%"><?php esc_html_e('Type', 'framework'); ?></th>
                                                <th width="12%"><?php esc_html_e('Contract', 'framework'); ?></th>
                                                <th width="15%"><?php esc_html_e('Price', 'framework'); ?></th>
                                                <th width="26%"><?php esc_html_e('Actions', 'framework'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            while (have_posts()) : the_post();
                                                $property_area = get_post_meta(get_the_ID(), 'imic_property_area', true);
                                                $property_baths = get_post_meta(get_the_ID(), 'imic_property_baths', true);
                                                $property_beds = get_post_meta(get_the_ID(), 'imic_property_beds', true);
                                                $property_parking = get_post_meta(get_the_ID(), 'imic_property_parking', true);
                                                $property_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
                                                $property_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
                                                $property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
                                                $property_price = number_format(intval($property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
                                                $type = wp_get_object_terms(get_the_ID(), 'property-type', array('fields' => 'ids'));
                                                if (!empty($type)) {
                                                    $term = get_term($type[0], 'property-type');
                                                }
                                                $contract = wp_get_object_terms(get_the_ID(), 'property-contract-type', array('fields' => 'ids'));
                                                if (!empty($contract)) {
                                                    $terms = get_term($contract[0], 'property-contract-type');
                                                } ?>
                                                <tr>
                                                    <td>
                                                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('100-67-size'); ?></a>
                                                    </td>
                                                    <td><a href="<?php the_permalink(); ?>"><?php echo get_the_title(); ?></a><?php echo imicPropertyId(get_the_ID()); ?></td>
                                                    <td><?php if (!empty($term)) {
                                                            echo esc_attr($term->name);
                                                        } ?></td>
                                                    <td><?php if (!empty($terms)) {
                                                            echo esc_attr($terms->name);
                                                        } ?></td>
                                                    <td valign="middle">
                                                        <?php if (!empty($property_price)) :
                                                            echo imic_property_price_with_currency($property_price, $currency_symbol);
                                                        endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo esc_url(add_query_arg('site', get_the_ID(), $edit_url)); ?>" class="action-button"><i class="fa fa-pencil"></i> <span><?php esc_html_e('Edit', 'framework'); ?></span></a>
                                                        <a href="<?php the_permalink(); ?>" class="action-button"><i class="fa fa-eye"></i> <span><?php esc_html_e('View', 'framework'); ?></span></a>
                                                        <a href="<?php echo esc_url(add_query_arg('remove', get_the_ID())); ?>" class="action-button"><i class="fa fa-ban"></i> <span><?php esc_html_e('Remove', 'framework'); ?></span></a>
                                                    </td>
                                                </tr>
                                            <?php endwhile; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php
                        else :
                            echo '<h3>' . esc_html__("You do not have any Property  to create property click here", 'framework') . '<a href="' . $edit_url . '" class="btn btn-sm btn-primary">' . esc_html__('Add new property ', 'framework') . '<i class="fa fa-long-arrow-right"></i></a></h3>';
                        endif;
                        echo '<div class="text-align-center">';
                        pagination();
                        wp_reset_query();
                        echo '</div>'; ?>
                        </div>
                        <!-- Start Sidebar -->
                        <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
                            <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
                                <?php dynamic_sidebar($pageSidebar); ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } else {
    echo imic_unidentified_agent();
}
get_footer(); ?>