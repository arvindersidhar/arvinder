<?php
/*
Template Name: Blog
*/
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
$page_for_posts = get_option('page_for_posts');
//check by Blog
if (is_home() && !empty($page_for_posts)) {
	$blog_id = $page_for_posts;
} else {
	$blog_id = get_the_ID();
}
/* Site Showcase */
imic_page_banner($pageID = $blog_id);
/* End Site Showcase */
$blog_type = get_post_meta($blog_id, 'imic_blog_type', true);
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
	$ContentWidth = 12 - $imic_options['sidebar_width'];
	$SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($blog_id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
	$ContentWidth = 12 - $pageSidebarWidth;
	$SidebarWidth = $pageSidebarWidth;
}
$pageSidebar = get_post_meta($blog_id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
	$class = $ContentWidth;
} else {
	$class = 12;
}
$blog_classes_open = ($blog_type == 'masonry') ? '<ul class="grid-holder col-3">' : '<ul class="timeline">';
$blog_classes_close = ($blog_type == 'masonry') ? '</ul>' : '</ul>';
?>
<!-- Start Content -->
<div class="main" role="main">
	<div id="content" class="content full">
		<div class="container">
			<div class="row">
				<div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">
					<?php echo '' . $blog_classes_open;
					$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
					query_posts(array('post_type' => 'post', 'paged' => $paged));
					if (have_posts()) :
						while (have_posts()) : the_post();
							get_template_part('content', $blog_type);
						endwhile;
					else :
						get_template_part('content', 'none');
					endif;
					echo '' . $blog_classes_close;
					if ($blog_type == 'masonry') :
						echo '<div class="text-align-center">';
						pagination();
						echo '</div>';
					endif;
					wp_reset_query(); ?>
				</div>
				<!-- Start Sidebar -->
				<?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
					<div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
						<?php dynamic_sidebar($pageSidebar); ?>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
	<?php get_footer(); ?>