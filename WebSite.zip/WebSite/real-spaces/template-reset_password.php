<?php
/* Template Name: Reset Password */
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
$id = get_the_ID();
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
	$ContentWidth = 12 - $imic_options['sidebar_width'];
	$SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
	$ContentWidth = 12 - $pageSidebarWidth;
	$SidebarWidth = $pageSidebarWidth;
}
$pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
	$class = $ContentWidth;
} else {
	$class = 12;
}
?>
<div class="main" role="main">
	<div id="content" class="content full">
		<div class="container">
			<div class="row">
				<div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">

					<?php if (have_posts()) : while (have_posts()) : the_post();
							the_content();
						endwhile;
					endif; ?>
					<?php
					$p_flag = 0;
					if (isset($_GET['action']) && $_GET['action'] == 'resetpass') {
						if (isset($_POST['pass1'])) {
							$pwd1 = $_POST['pass1'];
							$pwd2 = $_POST['pass2'];
							if (trim($pwd1) == '') {
								echo '<div class="alert alert-error">' . esc_html__('You must enter password.', 'framework') . '</div>';
								$p_flag = 1;
							} else if (trim($pwd2) == '') {
								echo '<div class="alert alert-error">' . esc_html__('You must enter repeat password.', 'framework') . '</div>';
								$p_flag = 1;
							} else if (trim($pwd1) != trim($pwd2)) {
								echo '<div class="alert alert-error">' . esc_html__('Passwords does not match.', 'framework') . '</div>';
								$p_flag = 1;
							}
							if ($p_flag != 1 && isset($_POST['user_login'])) {
								$user_login = $_POST['user_login'];
								$password = $_POST['pass1'];
								global $wpdb;
								$wpdb->update($wpdb->users, array('user_pass' => md5($password)), array('user_login' => $user_login));
								echo '<div class="alert alert-success">';
								esc_html_e('Your password has been successfully updated.', 'framework');
								echo ' <a href ="' . imic_get_template_url('template-register.php') . '" class ="class="submit_button btn btn-primary button2">' . esc_html__('Login Here', 'framework') . '</a>';
								echo '</div>';
							}
						}
					}
					if (isset($_GET['login']) || ($p_flag == 1)) {
						?>
						<form name="resetpassform" id="register-form" action="<?php echo imic_get_template_url('template-reset_password.php'); ?>?action=resetpass" method="post" autocomplete="off">
							<input type="hidden" id="user_login" name="user_login" value="<?php echo '' . $_GET['login']; ?>" autocomplete="off">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" name="pass1" id="pwd1" class="form-control" value="<?php echo (isset($_POST['pass1']) ? $_POST['pass1'] : ''); ?>" placeholder="<?php esc_html_e('Password', 'framework'); ?>">
							</div>
							<br>
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-refresh"></i></span>
								<input type="password" name="pass2" id="pwd2" value="<?php echo (isset($_POST['pass2']) ? $_POST['pass2'] : ''); ?>" class="form-control" placeholder="<?php esc_html_e('Repeat Password', 'framework') ?>">
							</div>
							<br />
							<input type="submit" name="wp-submit" id="wp-submit" class="submit_button btn btn-primary button2" value="<?php esc_html_e('Login Here', 'framework'); ?>">
						</form>
					<?php
				} elseif (isset($_GET['action']) && $_GET['action'] == 'resetpass') { } else {
					?>
						<form method="post" class="register-form" action="">
							<div class="input-group">
								<input type="text" name="user_login" id="username" class="form-control" placeholder="<?php esc_html_e('Username or Email', 'framework'); ?>">
							</div>
							<br>
							<?php do_action('login_form', 'resetpass'); ?>
							<input type="submit" name="user-submit" value="<?php esc_html_e('Reset password', 'framework'); ?>" class="submit_button btn btn-primary button2" />
							<?php
							if (isset($_POST['reset_pass'])) {
								global $wpdb;
								$username = trim($_POST['user_login']);
								$user_exists = false;
								// First check by username
								if (username_exists($username)) {
									$user_exists = true;
									$user = get_user_by('login', $username);
								}
								// Then, by e-mail address
								elseif (email_exists($username)) {
									$user_exists = true;
									$user = get_user_by('email', $username);
								} else {
									$msg = '<p>' . esc_html__('Username or Email was not found, try again!', 'framework') . '</p>';
									echo '<div class="margin-20"></div><div class="alert alert-info">' . $msg . '</div>';
								}
								if ($user_exists) {
									$user_login = $user->user_login;
									$user_email = $user->user_email;
									$key = $wpdb->get_var($wpdb->prepare("SELECT user_activation_key FROM $wpdb->users WHERE user_login = %s", $user_login));
									if (empty($key)) {
										// Generate something random for a key...
										$key = wp_generate_password(20, false);
										do_action('retrieve_password_key', $user_login, $key);
										// Now insert the new md5 key into the db
										$wpdb->update($wpdb->users, array('user_activation_key' => $key), array('user_login' => $user_login));
									}
									//create email message
									$message = esc_html__('Someone has asked to reset the password for the following site and username.', 'framework') . "\r\n\r\n";
									$message .= get_option('siteurl') . "\r\n\r\n";
									$message .= sprintf(__('Username: %s', 'framework'), $user_login) . "\r\n\r\n";
									$message .= esc_html__('To reset your password visit the following address, otherwise just ignore this email and nothing will happen.', 'framework') . "\r\n\r\n";
									$message .= network_site_url("reset-password?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') . "\r\n";
									//send email meassage
									if (wp_mail($user_email, sprintf(esc_html__('[%s] Password Reset', 'framework'), get_option('blogname')), $message)) {
										$mesg = '<p>' . esc_html__('A message will be sent to your email address.', 'framework') . '</p>';
									} else {
										$mesg = '<p>' . esc_html__('The e-mail could not be sent.', 'framework') . "<br />\n" . esc_html__('Possible reason: Your host may have disabled the mail function...', 'framework') . '</p>';
									}
									if (isset($mesg)) {
										echo '<div class="alert">' . $mesg . '</div>';
									}
								}
							}
							?>
							<input type="hidden" name="reset_pass" value="1" />
							<input type="hidden" name="user-cookie" value="1" />
						</form>
					<?php } ?>
				</div>
				<!-- Start Sidebar -->
				<?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
					<div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
						<?php dynamic_sidebar($pageSidebar); ?>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>