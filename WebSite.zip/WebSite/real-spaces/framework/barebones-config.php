<?php

/**
 * ReduxFramework Barebones Sample Config File
 * For full documentation, please visit: http://docs.reduxframework.com/
 */

if (!defined('REALSPACES_CORE__PLUGIN_PATH')) {
	return;
}
// This is your option name where all the Redux data is stored.
$opt_name = "imic_options";

/**
 * ---> SET ARGUMENTS
 * All the possible arguments for Redux.
 * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
 * */

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
	// TYPICAL -> Change these values as you need/desire
	'opt_name'             => $opt_name,
	// This is where your data is stored in the database and also becomes your global variable name.
	'display_name'         => $theme->get('Name'),
	// Name that appears at the top of your panel
	'display_version'      => $theme->get('Version'),
	// Version that appears at the top of your panel
	'menu_type'            => 'submenu',
	//Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
	'allow_sub_menu'       => true,
	// Show the sections below the admin menu item or not
	'menu_title'           => esc_html__('Theme Options', 'framework'),
	'page_title'           => esc_html__('Theme Options', 'framework'),
	// You will need to generate a Google API key to use this feature.
	// Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
	'google_api_key'       => '',
	// Set it you want google fonts to update weekly. A google_api_key value is required.
	'google_update_weekly' => false,
	// Must be defined to add google fonts to the typography module
	'async_typography'     => true,
	// Use a asynchronous font on the front end or font string
	//'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
	'admin_bar'            => true,
	// Show the panel pages on the admin bar
	'admin_bar_icon'       => 'dashicons-portfolio',
	// Choose an icon for the admin bar menu
	'admin_bar_priority'   => 50,
	// Choose an priority for the admin bar menu
	'global_variable'      => '',
	// Set a different name for your global variable other than the opt_name
	'dev_mode'             => false,
	// Show the time the page took to load, etc
	'update_notice'        => true,
	// If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
	'customizer'           => true,
	// Enable basic customizer support
	//'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
	//'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

	// OPTIONAL -> Give you extra features
	'page_priority'        => null,
	// Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
	'page_parent'          => 'imi-admin-welcome',
	// For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
	'page_permissions'     => 'manage_options',
	// Permissions needed to access the options panel.
	'menu_icon'            => '',
	// Specify a custom URL to an icon
	'last_tab'             => '',
	// Force your panel to always open to a specific tab (by id)
	'page_icon'            => 'icon-themes',
	// Icon displayed in the admin panel next to your menu_title
	'page_slug'            => '_options',
	// Page slug used to denote the panel
	'save_defaults'        => true,
	// On load save the defaults to DB before user clicks save or not
	'default_show'         => false,
	// If true, shows the default value next to each field that is not the default value.
	'default_mark'         => '',
	// What to print by the field's title if the value shown is default. Suggested: *
	'show_import_export'   => true,
	// Shows the Import/Export panel when not used as a field.

	// CAREFUL -> These options are for advanced use only
	'transient_time'       => 60 * MINUTE_IN_SECONDS,
	'output'               => true,
	// Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
	'output_tag'           => true,
	// Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
	// 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

	// FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
	'database'             => '',
	// possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

	'use_cdn'              => true,
	// If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

	//'compiler'             => true,

	// HINTS
	'hints'                => array(
		'icon'          => 'el el-question-sign',
		'icon_position' => 'right',
		'icon_color'    => 'lightgray',
		'icon_size'     => 'normal',
		'tip_style'     => array(
			'color'   => 'light',
			'shadow'  => true,
			'rounded' => false,
			'style'   => '',
		),
		'tip_position'  => array(
			'my' => 'top left',
			'at' => 'bottom right',
		),
		'tip_effect'    => array(
			'show' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'mouseover',
			),
			'hide' => array(
				'effect'   => 'slide',
				'duration' => '500',
				'event'    => 'click mouseleave',
			),
		),
	)
);

$ext_path = REALSPACES_CORE__PLUGIN_PATH . 'imi-admin/theme-options/extensions/';
Redux::setExtensions($opt_name, $ext_path);

// ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
$args['share_icons'][] = array(
	'url'   => 'https://www.facebook.com/imithemes',
	'title' => 'Like us on Facebook',
	'icon'  => 'el el-facebook'
);
$args['share_icons'][] = array(
	'url'   => 'https://twitter.com/imithemes',
	'title' => 'Follow us on Twitter',
	'icon'  => 'el el-twitter'
);

// Panel Intro text -> before the form
if (!isset($args['global_variable']) || $args['global_variable'] !== false) {
	if (!empty($args['global_variable'])) {
		$v = $args['global_variable'];
	} else {
		$v = str_replace('-', '_', $args['opt_name']);
	}
} else { }

Redux::setArgs($opt_name, $args);

// Set the help sidebar
$content = esc_html__('<p>This is the sidebar content, HTML is allowed.</p>', 'framework');
Redux::setHelpSidebar($opt_name, $content);

$defaultLogo = get_template_directory_uri() . '/assets/images/logo.png';
$default_retina_logo = get_template_directory_uri() . '/assets/images/logo@2x.png';
$defaultAdminLogo = get_template_directory_uri() . '/assets/images/logo-admin.png';
$default_favicon = get_template_directory_uri() . '/assets/images/favicon.ico';
$default_iphone = get_template_directory_uri() . '/assets/images/apple-iphone.png';
$default_iphone_retina = get_template_directory_uri() . '/assets/images/apple-iphone-retina.png';
$default_ipad = get_template_directory_uri() . '/assets/images/apple-ipad.png';
$default_ipad_retina = get_template_directory_uri() . '/assets/images/apple-ipad-retina.png';
$defaultBannerImages = get_template_directory_uri() . '/assets/images/page-header.png';
$default_agent_image = get_template_directory_uri() . '/assets/images/default_agent.png';


// -> START Basic Fields
Redux::setSection($opt_name, array(
	'icon'      => 'el-icon-cogs',
	'title'     => __('General', 'framework'),
	'fields'    => array(
		$fields = array(
			'id'       => 'country-select',
			'multi'    => true,
			'type'     => 'select',
			'title'    => __('Select Country', 'framework'),
			'subtitle' => __('Select country for this site.', 'framework'),
			'desc'     => __('State list will generate through selected country.', 'framework'),
			// Must provide key => value pairs for select options
			'options'  => array(
				'tocustom' => 'Theme Options Custom Values',
				'Algeria' => 'Algeria', 'Angola' => 'Angola', 'Benin' => 'Benin', 'Botswana' => 'Botswana', 'Burkina-Faso' => 'Burkina Faso', 'Burundi' => 'Burundi', 'Cameroon' => 'Cameroon', 'Cape-Verde' => 'Cape Verde', 'Central-African-Republic' => 'Central African Republic', 'Chad' => 'Chad', 'Comoros' => 'Comoros', 'Congo' => 'Congo', 'democratic-republic-of-the-congo' => 'Democratic Republic of the Congo', 'Djibouti' => 'Djibouti', 'Egypt' => 'Egypt', 'Equatorial-Guinea' => 'Equatorial Guinea', 'Eritrea' => 'Eritrea', 'Ethiopia' => 'Ethiopia', 'Gabon' => 'Gabon', 'Gambia' => 'Gambia', 'Ghana' => 'Ghana', 'Guinea' => 'Guinea', 'Guinea-Bissau' => 'Guinea-Bissau', 'ivory-coast' => 'Ivory Coast', 'Kenya' => 'Kenya', 'Lesotho' => 'Lesotho', 'Liberia' => 'Liberia', 'Libya' => 'Libya', 'Madagascar' => 'Madagascar', 'Malawi' => 'Malawi', 'Mali' => 'Mali', 'Mauritania' => 'Mauritania', 'Mauritius' => 'Mauritius', 'Morocco' => 'Morocco', 'Mozambique' => 'Mozambique', 'Namibia' => 'Namibia', 'Niger' => 'Niger', 'Nigeria' => 'Nigeria', 'Rwanda' => 'Rwanda', 'saint-helena' => 'Saint Helena', 'Sao-Tome-Principe' => 'Sao Tome/Principe', 'Senegal' => 'Senegal', 'Seychelles' => 'Seychelles', 'Sierra-Leone' => 'Sierra Leone', 'Somalia' => 'Somalia', 'South-Africa' => 'South Africa', 'Sudan' => 'Sudan', 'Swaziland' => 'Swaziland', 'Tanzania' => 'Tanzania', 'Togo' => 'Togo', 'Tunisia' => 'Tunisia', 'Uganda' => 'Uganda', 'Zambia' => 'Zambia', 'Zimbabwe' => 'Zimbabwe', 'Bangladesh' => 'Bangladesh', 'Bhutan' => 'Bhutan', 'Brunei' => 'Brunei', 'Myanmar' => 'Myanmar', 'Cambodia' => 'Cambodia', 'China' => 'China', 'East-Timor' => 'East Timor', 'India' => 'India', 'Indonesia' => 'Indonesia', 'Japan' => 'Japan', 'Kazakhstan' => 'Kazakhstan', 'Korea-north' => 'Korea (north)', 'Korea-south' => 'Korea (south)', 'Laos' => 'Laos', 'Malaysia' => 'Malaysia', 'Maldives' => 'Maldives', 'Mongolia' => 'Mongolia', 'Nepal' => 'Nepal', 'Philippines' => 'Philippines', 'russia' => 'Russia', 'Singapore' => 'Singapore', 'Sri-Lanka' => 'Sri Lanka', 'Taiwan' => 'Taiwan', 'Thailand' => 'Thailand', 'Vietnam' => 'Vietnam', 'Australia' => 'Australia', 'Fiji' => 'Fiji', 'Kiribati' => 'Kiribati', 'Micronesia' => 'Micronesia', 'Nauru' => 'Nauru', 'New-Zealand' => 'New Zealand', 'Palau' => 'Palau', 'Papua-New-Guinea' => 'Papua New Guinea', 'Samoa' => 'Samoa', 'solomon-islands' => 'Solomon Islands', 'Tonga' => 'Tonga', 'Tuvalu' => 'Tuvalu', 'Vanuatu' => 'Vanuatu', 'Anguilla' => 'Anguilla', 'Antigua-Barbuda' => 'Antigua/Barbuda', 'Aruba' => 'Aruba', 'Bahamas' => 'Bahamas', 'Barbados' => 'Barbados', 'Cuba' => 'Cuba', 'Dominica' => 'Dominica', 'Dominican-Republic' => 'Dominican Republic', 'Grenada' => 'Grenada', 'Guadeloupe' => 'Guadeloupe', 'Haiti' => 'Haiti', 'Jamaica' => 'Jamaica', 'Martinique' => 'Martinique', 'Montserrat' => 'Montserrat', 'Netherlands -Antilles' => 'Netherlands Antilles', 'Puerto-Rico' => 'Puerto Rico', 'St-Kitts-Nevis' => 'St. Kitts/Nevis', 'St-Lucia' => 'St. Lucia', 'St Vincent/Grenadines' => 'St-Vincent-Grenadines', 'Trinidad-Tobago' => 'Trinidad/Tobago', 'Turks-Caicos' => 'Turks/Caicos', 'Belize' => 'Belize', 'Costa-Rica' => 'Costa Rica', 'El-Salvador' => 'El Salvador', 'Guatemala' => 'Guatemala', 'Honduras' => 'Honduras', 'Nicaragua' => 'Nicaragua', 'Panama' => 'Panama', 'Albania' => 'Albania', 'Andorra' => 'Andorra', 'Austria' => 'Austria', 'Belarus' => 'Belarus', 'Belgium' => 'Belgium', 'Bosnia-Herzegovina' => 'Bosnia/Herzegovina', 'Bulgaria' => 'Bulgaria', 'Croatia' => 'Croatia', 'Czech-Republic' => 'Czech Republic', 'Denmark' => 'Denmark', 'Estonia' => 'Estonia', 'Finland' => 'Finland', 'France' => 'France', 'Georgia' => 'Georgia', 'Germany' => 'Germany', 'Greece' => 'Greece', 'Hungary' => 'Hungary', 'Iceland' => 'Iceland', 'Ireland' => 'Ireland', 'Italy' => 'Italy', 'Latvia' => 'Latvia', 'Liechtenstein' => 'Liechtenstein', 'Lithuania' => 'Lithuania', 'Luxembourg' => 'Luxembourg', 'Macedonia' => 'Macedonia', 'Malta' => 'Malta', 'Moldova' => 'Moldova', 'Monaco' => 'Monaco', 'Netherlands' => 'Netherlands', 'northern-ireland' => 'Northern Ireland in United Kingdom', 'Norway' => 'Norway', 'Poland' => 'Poland', 'Portugal' => 'Portugal', 'Romania' => 'Romania', 'San-Marino' => 'San Marino', 'scotland' => 'Scotland in United Kingdom', 'Serbia' => 'Serbia', 'Slovakia' => 'Slovakia', 'Slovenia' => 'Slovenia', 'Spain' => 'Spain', 'Sweden' => 'Sweden', 'Switzerland' => 'Switzerland', 'Ukraine' => 'Ukraine', 'wales' => 'Wales', 'United-Kingdom' => 'United Kingdom', 'Arctic-Ocean' => 'Arctic Ocean', 'Atlantic-Ocean-North' => 'Atlantic Ocean (North)', 'Atlantic-Ocean-South' => 'Atlantic Ocean (South)', 'Assorted' => 'Assorted', 'Caribbean-Sea' => 'Caribbean Sea', 'Greek-Isles' => 'Greek Isles', 'Indian-Ocean' => 'Indian Ocean', 'Mediterranean-Sea' => 'Mediterranean Sea', 'Oceania' => 'Oceania', 'Pacific-Ocean-North' => 'Pacific Ocean (North)', 'Afghanistan' => 'Afghanistan', 'Armenia' => 'Armenia', 'Azerbaijan' => 'Azerbaijan', 'Bahrain' => 'Bahrain', 'Cyprus' => 'Cyprus', 'Iran' => 'Iran', 'Iraq' => 'Iraq', 'Israel' => 'Israel', 'Jordan' => 'Jordan', 'Kuwait' => 'Kuwait', 'Kyrgyzstan' => 'Kyrgyzstan', 'Lebanon' => 'Lebanon', 'macao' => 'Macao', 'Oman' => 'Oman', 'Pakistan' => 'Pakistan', 'Qatar' => 'Qatar', 'Saudi-Arabia' => 'Saudi Arabia', 'Syria' => 'Syria', 'Tajikistan' => 'Tajikistan', 'Turkey' => 'Turkey', 'Turkmenistan' => 'Turkmenistan', 'United-Arab-Emirates' => 'United Arab Emirates', 'Uzbekistan' => 'Uzbekistan', 'Yemen' => 'Yemen', 'Bermuda' => 'Bermuda', 'Canada' => 'Canada', 'cayman-islands' => 'Cayman Islands', 'Caribbean' => 'Caribbean', 'Greenland' => 'Greenland', 'Mexico' => 'Mexico', 'Brazil' => 'Brazil', 'United-States' => 'United States', 'us-virgin-islands' => 'U.S. Virgin Islands', 'Argentina' => 'Argentina', 'Bolivia' => 'Bolivia', 'Chile' => 'Chile', 'Colombia' => 'Colombia', 'Ecuador' => 'Ecuador', 'Guyana' => 'Guyana', 'Paraguay' => 'Paraguay', 'Peru' => 'Peru', 'Suriname' => 'Suriname', 'Uruguay' => 'Uruguay', 'Venezuela' => 'Venezuela'
			),
			'default'  => array('United-States')
		),
		$fields = array(
			'id' => 'custom_province',
			'required' => array('country-select', 'equals', 'tocustom'),
			'type' => 'textarea',
			'title' => __('Custom Provinces', 'framework'),
			'subtitle' => __('Enter comma "," separated state/provinces.', 'framework'),
			'default' => '',
		),
		$fields = array(
			'id'       => 'currency-select',
			'type'     => 'select',
			'title'    => __('Select Currency', 'framework'),
			'subtitle' => __('Select Currency for this site.', 'framework'),
			// Must provide key => value pairs for select options
			'options'  => array(
				'AED' => __('United Arab Emirates dirham', 'framework'),
				'AFN' => __('Afghan afghani', 'framework'),
				'ALL' => __('Albanian lek', 'framework'),
				'AMD' => __('Armenian dram', 'framework'),
				'ANG' => __('Netherlands Antillean guilder', 'framework'),
				'AOA' => __('Angolan kwanza', 'framework'),
				'ARS' => __('Argentine peso', 'framework'),
				'AUD' => __('Australian dollar', 'framework'),
				'AWG' => __('Aruban florin', 'framework'),
				'AZN' => __('Azerbaijani manat', 'framework'),
				'BAM' => __('Bosnia and Herzegovina convertible mark', 'framework'),
				'BBD' => __('Barbadian dollar', 'framework'),
				'BDT' => __('Bangladeshi taka', 'framework'),
				'BGN' => __('Bulgarian lev', 'framework'),
				'BHD' => __('Bahraini dinar', 'framework'),
				'BIF' => __('Burundian franc', 'framework'),
				'BMD' => __('Bermudian dollar', 'framework'),
				'BND' => __('Brunei dollar', 'framework'),
				'BOB' => __('Bolivian boliviano', 'framework'),
				'BRL' => __('Brazilian real', 'framework'),
				'BSD' => __('Bahamian dollar', 'framework'),
				'BTC' => __('Bitcoin', 'framework'),
				'BTN' => __('Bhutanese ngultrum', 'framework'),
				'BWP' => __('Botswana pula', 'framework'),
				'BYR' => __('Belarusian ruble', 'framework'),
				'BZD' => __('Belize dollar', 'framework'),
				'CAD' => __('Canadian dollar', 'framework'),
				'CDF' => __('Congolese franc', 'framework'),
				'CHF' => __('Swiss franc', 'framework'),
				'CLP' => __('Chilean peso', 'framework'),
				'CNY' => __('Chinese yuan', 'framework'),
				'COP' => __('Colombian peso', 'framework'),
				'CRC' => __('Costa Rican col&oacute;n', 'framework'),
				'CUC' => __('Cuban convertible peso', 'framework'),
				'CUP' => __('Cuban peso', 'framework'),
				'CVE' => __('Cape Verdean escudo', 'framework'),
				'CZK' => __('Czech koruna', 'framework'),
				'DJF' => __('Djiboutian franc', 'framework'),
				'DKK' => __('Danish krone', 'framework'),
				'DOP' => __('Dominican peso', 'framework'),
				'DZD' => __('Algerian dinar', 'framework'),
				'EGP' => __('Egyptian pound', 'framework'),
				'ERN' => __('Eritrean nakfa', 'framework'),
				'ETB' => __('Ethiopian birr', 'framework'),
				'EUR' => __('Euro', 'framework'),
				'FJD' => __('Fijian dollar', 'framework'),
				'FKP' => __('Falkland Islands pound', 'framework'),
				'GBP' => __('Pound sterling', 'framework'),
				'GEL' => __('Georgian lari', 'framework'),
				'GGP' => __('Guernsey pound', 'framework'),
				'GHS' => __('Ghana cedi', 'framework'),
				'GIP' => __('Gibraltar pound', 'framework'),
				'GMD' => __('Gambian dalasi', 'framework'),
				'GNF' => __('Guinean franc', 'framework'),
				'GTQ' => __('Guatemalan quetzal', 'framework'),
				'GYD' => __('Guyanese dollar', 'framework'),
				'HKD' => __('Hong Kong dollar', 'framework'),
				'HNL' => __('Honduran lempira', 'framework'),
				'HRK' => __('Croatian kuna', 'framework'),
				'HTG' => __('Haitian gourde', 'framework'),
				'HUF' => __('Hungarian forint', 'framework'),
				'IDR' => __('Indonesian rupiah', 'framework'),
				'ILS' => __('Israeli new shekel', 'framework'),
				'IMP' => __('Manx pound', 'framework'),
				'INR' => __('Indian rupee', 'framework'),
				'IQD' => __('Iraqi dinar', 'framework'),
				'IRR' => __('Iranian rial', 'framework'),
				'IRT' => __('Iranian toman', 'framework'),
				'ISK' => __('Icelandic kr&oacute;na', 'framework'),
				'JEP' => __('Jersey pound', 'framework'),
				'JMD' => __('Jamaican dollar', 'framework'),
				'JOD' => __('Jordanian dinar', 'framework'),
				'JPY' => __('Japanese yen', 'framework'),
				'KES' => __('Kenyan shilling', 'framework'),
				'KGS' => __('Kyrgyzstani som', 'framework'),
				'KHR' => __('Cambodian riel', 'framework'),
				'KMF' => __('Comorian franc', 'framework'),
				'KPW' => __('North Korean won', 'framework'),
				'KRW' => __('South Korean won', 'framework'),
				'KWD' => __('Kuwaiti dinar', 'framework'),
				'KYD' => __('Cayman Islands dollar', 'framework'),
				'KZT' => __('Kazakhstani tenge', 'framework'),
				'LAK' => __('Lao kip', 'framework'),
				'LBP' => __('Lebanese pound', 'framework'),
				'LKR' => __('Sri Lankan rupee', 'framework'),
				'LRD' => __('Liberian dollar', 'framework'),
				'LSL' => __('Lesotho loti', 'framework'),
				'LYD' => __('Libyan dinar', 'framework'),
				'MAD' => __('Moroccan dirham', 'framework'),
				'MDL' => __('Moldovan leu', 'framework'),
				'MGA' => __('Malagasy ariary', 'framework'),
				'MKD' => __('Macedonian denar', 'framework'),
				'MMK' => __('Burmese kyat', 'framework'),
				'MNT' => __('Mongolian t&ouml;gr&ouml;g', 'framework'),
				'MOP' => __('Macanese pataca', 'framework'),
				'MRO' => __('Mauritanian ouguiya', 'framework'),
				'MUR' => __('Mauritian rupee', 'framework'),
				'MVR' => __('Maldivian rufiyaa', 'framework'),
				'MWK' => __('Malawian kwacha', 'framework'),
				'MXN' => __('Mexican peso', 'framework'),
				'MYR' => __('Malaysian ringgit', 'framework'),
				'MZN' => __('Mozambican metical', 'framework'),
				'NAD' => __('Namibian dollar', 'framework'),
				'NGN' => __('Nigerian naira', 'framework'),
				'NIO' => __('Nicaraguan c&oacute;rdoba', 'framework'),
				'NOK' => __('Norwegian krone', 'framework'),
				'NPR' => __('Nepalese rupee', 'framework'),
				'NZD' => __('New Zealand dollar', 'framework'),
				'OMR' => __('Omani rial', 'framework'),
				'PAB' => __('Panamanian balboa', 'framework'),
				'PEN' => __('Peruvian nuevo sol', 'framework'),
				'PGK' => __('Papua New Guinean kina', 'framework'),
				'PHP' => __('Philippine peso', 'framework'),
				'PKR' => __('Pakistani rupee', 'framework'),
				'PLN' => __('Polish z&#x142;oty', 'framework'),
				'PRB' => __('Transnistrian ruble', 'framework'),
				'PYG' => __('Paraguayan guaran&iacute;', 'framework'),
				'QAR' => __('Qatari riyal', 'framework'),
				'RON' => __('Romanian leu', 'framework'),
				'RSD' => __('Serbian dinar', 'framework'),
				'RUB' => __('Russian ruble', 'framework'),
				'RWF' => __('Rwandan franc', 'framework'),
				'SAR' => __('Saudi riyal', 'framework'),
				'SBD' => __('Solomon Islands dollar', 'framework'),
				'SCR' => __('Seychellois rupee', 'framework'),
				'SDG' => __('Sudanese pound', 'framework'),
				'SEK' => __('Swedish krona', 'framework'),
				'SGD' => __('Singapore dollar', 'framework'),
				'SHP' => __('Saint Helena pound', 'framework'),
				'SLL' => __('Sierra Leonean leone', 'framework'),
				'SOS' => __('Somali shilling', 'framework'),
				'SRD' => __('Surinamese dollar', 'framework'),
				'SSP' => __('South Sudanese pound', 'framework'),
				'STD' => __('S&atilde;o Tom&eacute; and Pr&iacute;ncipe dobra', 'framework'),
				'SYP' => __('Syrian pound', 'framework'),
				'SZL' => __('Swazi lilangeni', 'framework'),
				'THB' => __('Thai baht', 'framework'),
				'TJS' => __('Tajikistani somoni', 'framework'),
				'TMT' => __('Turkmenistan manat', 'framework'),
				'TND' => __('Tunisian dinar', 'framework'),
				'TOP' => __('Tongan pa&#x2bb;anga', 'framework'),
				'TRY' => __('Turkish lira', 'framework'),
				'TTD' => __('Trinidad and Tobago dollar', 'framework'),
				'TWD' => __('New Taiwan dollar', 'framework'),
				'TZS' => __('Tanzanian shilling', 'framework'),
				'UAH' => __('Ukrainian hryvnia', 'framework'),
				'UGX' => __('Ugandan shilling', 'framework'),
				'USD' => __('United States dollar', 'framework'),
				'UYU' => __('Uruguayan peso', 'framework'),
				'UZS' => __('Uzbekistani som', 'framework'),
				'VEF' => __('Venezuelan bol&iacute;var', 'framework'),
				'VND' => __('Vietnamese &#x111;&#x1ed3;ng', 'framework'),
				'VUV' => __('Vanuatu vatu', 'framework'),
				'WST' => __('Samoan t&#x101;l&#x101;', 'framework'),
				'XAF' => __('Central African CFA franc', 'framework'),
				'XCD' => __('East Caribbean dollar', 'framework'),
				'XOF' => __('West African CFA franc', 'framework'),
				'XPF' => __('CFP franc', 'framework'),
				'YER' => __('Yemeni rial', 'framework'),
				'ZAR' => __('South African rand', 'framework'),
				'ZMW' => __('Zambian kwacha', 'framework'),
			),
			'default'  => 'USD',
		),
		array(
			'id' => 'enable_maintenance',
			'type' => 'switch',
			'title' => __('Enable Maintenance', 'framework'),
			'subtitle' => __('Enable the themes in maintenance mode.', 'framework'),
			'default' => 0,
			'on' => __('Enabled', 'framework'),
			'off' => __('Disabled', 'framework'),
		),
		array(
			'id' => 'enable_rtl',
			'type' => 'switch',
			'title' => __('Enable RTL', 'framework'),
			'subtitle' => __('If you are using wordpress for RTL languages then you should enable this option.', 'framework'),
			"default" => 0,
		),
		array(
			'id' => 'enable_backtotop',
			'type' => 'switch',
			'title' => __('Enable Back To Top', 'framework'),
			'subtitle' => __('Enable the back to top button that appears in the bottom right corner of the screen.', 'framework'),
			'default' => 0,
		),
		array(
			'id' => 'space-before-head',
			'type' => 'ace_editor',
			'title' => esc_html__('Space before closing head tag', 'framework'),
			'subtitle' => esc_html__('Add your code before closing head tag', 'framework'),
			'default' => '',
		),
		array(
			'id' => 'space-before-body',
			'type' => 'ace_editor',
			'title' => esc_html__('Space before closing body tag', 'framework'),
			'subtitle' => esc_html__('Add your code before closing body tag', 'framework'),
			'default' => '',
		),
		array(
			'id' => 'tracking-code',
			'type' => 'textarea',
			'title' => esc_html__('Tracking Code', 'framework'),
			'subtitle' => esc_html__('Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.', 'framework'),
			'default'   => ''
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-website',
	'title' => esc_html__('Responsive', 'framework'),
	'fields' => array(
		array(
			'id' => 'switch-responsive',
			'type' => 'switch',
			'title' => esc_html__('Enable Responsive', 'framework'),
			'subtitle' => esc_html__('Enable/Disable the responsive behaviour of the theme', 'framework'),
			'default' => 1,
		),
		array(
			'id' => 'switch-zoom-pinch',
			'type' => 'switch',
			'title' => esc_html__('Enable Zoom on mobile devices', 'framework'),
			'subtitle' => esc_html__('Enable/Disable zoom pinch behaviour on touch devices', 'framework'),
			"default" => 0,
		),
	),
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-screen',
	'title' => __('Layout', 'framework'),
	'fields' => array(
		array(
			'id' => 'site_width',
			'type' => 'text',
			'compiler' => true,
			'title' => esc_html__('Site Width', 'framework'),
			'subtitle' => esc_html__('Controls the overall site width. Without px, ex: 1080(Default). Recommended maximum width is 1170 to maintain the theme structure.', 'framework'),
			'default' => '',
		),
		array(
			'id' => 'site_layout',
			'type' => 'image_select',
			'compiler' => true,
			'title' => __('Page Layout', 'framework'),
			'subtitle' => __('Select the page layout type', 'framework'),
			'options' => array(
				'wide' => array('alt' => 'Wide', 'img' => get_template_directory_uri() . '/assets/images/admin/wide.png'),
				'boxed' => array('alt' => 'Boxed', 'img' => get_template_directory_uri() . '/assets/images/admin/boxed.png')
			),
			'default' => 'wide',
		),
		array(
			'id' => 'repeatable-bg-image',
			'type' => 'image_select',
			'required' => array('site_layout', 'equals', 'boxed'),
			'title' => __('Repeatable Background Images', 'framework'),
			'subtitle' => __('Select image to set in background.', 'framework'),
			'options' => array(
				'pt1.png' => array('alt' => 'pt1', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt1.png'),
				'pt2.png' => array('alt' => 'pt2', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt2.png'),
				'pt3.png' => array('alt' => 'pt3', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt3.png'),
				'pt4.png' => array('alt' => 'pt4', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt4.png'),
				'pt5.png' => array('alt' => 'pt5', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt5.png'),
				'pt6.png' => array('alt' => 'pt6', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt6.png'),
				'pt7.png' => array('alt' => 'pt7', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt7.png'),
				'pt8.png' => array('alt' => 'pt8', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt8.png'),
				'pt9.png' => array('alt' => 'pt9', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt9.png'),
				'pt10.png' => array('alt' => 'pt10', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt10.png'),
				'pt11.jpg' => array('alt' => 'pt11', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt11.png'),
				'pt12.jpg' => array('alt' => 'pt12', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt12.png'),
				'pt13.jpg' => array('alt' => 'pt13', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt13.png'),
				'pt14.jpg' => array('alt' => 'pt14', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt14.png'),
				'pt15.jpg' => array('alt' => 'pt15', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt15.png'),
				'pt17.png' => array('alt' => 'pt17', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt17.png'),
				'pt18.png' => array('alt' => 'pt18', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt18.png'),
				'pt19.png' => array('alt' => 'pt19', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt19.png'),
				'pt20.png' => array('alt' => 'pt20', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt20.png'),
				'pt21.png' => array('alt' => 'pt21', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt21.png'),
				'pt22.png' => array('alt' => 'pt22', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt22.png'),
				'pt23.png' => array('alt' => 'pt23', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt23.png'),
				'pt24.png' => array('alt' => 'pt24', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt24.png'),
				'pt25.png' => array('alt' => 'pt25', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt25.png'),
				'pt26.png' => array('alt' => 'pt26', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt26.png'),
				'pt27.png' => array('alt' => 'pt27', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt27.png'),
				'pt28.png' => array('alt' => 'pt28', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt28.png'),
				'pt29.png' => array('alt' => 'pt29', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt29.png'),
				'pt30.png' => array('alt' => 'pt30', 'img' => get_template_directory_uri() . '/assets/images/admin/patterns-t/pt30.png')
			)
		),
		array(
			'id' => 'upload-repeatable-bg-image',
			'compiler' => true,
			'required' => array('site_layout', 'equals', 'boxed'),
			'type' => 'media',
			'url' => true,
			'title' => __('Upload Repeatable Background Image', 'framework')
		),
		array(
			'id' => 'full-screen-bg-image',
			'compiler' => true,
			'required' => array('site_layout', 'equals', 'boxed'),
			'type' => 'media',
			'url' => true,
			'title' => __('Upload Full Screen Background Image', 'framework')
		),
	),
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-ok',
	'title' => __('Content', 'framework'),
	'subsection' => true,
	'fields' => array(
		array(
			'id' => 'content_background',
			'type' => 'background',
			'background-color' => true,
			'output' => array('.content'),
			'title' => __('Content area Background', 'framework'),
			'subtitle' => __('Background color or image for the content area. This works for both boxed or wide layouts.', 'framework'),
		),
		array(
			'id'       => 'content_padding',
			'type'     => 'spacing',
			'units'    => array('px'),
			'mode'	   => 'padding',
			'left'	   => false,
			'right'	   => false,
			'output'   => array('.content'),
			'title'    => esc_html__('Top and Bottom padding for content area', 'framework'),
			'subtitle' => esc_html__('Enter top and bottom padding for content area. Default is 50px/50px', 'framework'),
			'default'  => array(),
		),
		array(
			'id'       => 'content_min_height',
			'type'     => 'text',
			'title'    => esc_html__('Minimum Height for Content area', 'framework'),
			'subtitle' => esc_html__('Enter minimum height for the page content area. DO NOT PUT px HERE. Default is 400', 'framework'),
			'default'  => ''
		),
		array(
			'id' => 'content_wide_width',
			'type' => 'checkbox',
			'compiler' => true,
			'title' => esc_html__('100% Content Width', 'framework'),
			'subtitle' => esc_html__('Check this box to set the content area to 100% of the browser width. Uncheck to follow site width.', 'framework'),
			'default' => '0',
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-chevron-up',
	'title' => __('Header', 'framework'),
	'desc' => __('These are the options for the header.', 'framework'),
	'fields' => array(
		array(
			'id' => 'header_wide_width',
			'type' => 'checkbox',
			'compiler' => true,
			'title' => esc_html__('100% Header Width', 'framework'),
			'subtitle' => esc_html__('Check this box to set the Header topbar, logo area and navigation to have 100% of the browser width. Uncheck to follow site width.', 'framework'),
			'default' => 0,
		),
		array(
			'id' => 'header_background_color',
			'type' => 'color',
			'title' => esc_html__('Header Background Color', 'framework'),
			'subtitle' => esc_html__('Pick a color for Header Background.', 'framework'),
			'validate' => 'color',
		),
		array(
			'id' => 'header_background_image',
			'type' => 'background',
			'background-color' => false,
			'output' => array('.middle-header'),
			'title' => esc_html__('Header Background Image', 'framework'),
			'subtitle' => esc_html__('Setup background image for the website header(Logo Area).', 'framework'),
		),
		array(
			'id' => 'enable-header-stick',
			'type' => 'switch',
			'title' => esc_html__('Enable Sticky Header', 'framework'),
			'subtitle' => esc_html__('Enable/Disable header sticky behaviour', 'framework'),
			'default' => 1,
		),
		array(
			'id' => 'header_free_line_title',
			'type' => 'text',
			'title' => esc_html__('Header Info 1 Title', 'framework'),
			'subtitle' => esc_html__('Enter your header info 1 title', 'framework'),
			'default' => 'Free Line For You',
		),
		array(
			'id' => 'header_free_line_icon',
			'type' => 'text',
			'title' => esc_html__('Header Info 1 Icon', 'framework'),
			'subtitle' => __('Enter your info 1 icon name. <a href="http://fontawesome.io/icons/" target="_blank">Icon names</a>', 'framework'),
			'default' => 'phone',
		),
		array(
			'id' => 'header_free_line',
			'type' => 'text',
			'title' => esc_html__('Header Info 1', 'framework'),
			'subtitle' => esc_html__('Enter your header info 1 information', 'framework'),
			'default' => '08037867890',
		),
		array(
			'id' => 'header_email_us_title',
			'type' => 'text',
			'title' => esc_html__('Header Info 2 Title', 'framework'),
			'subtitle' => esc_html__('Enter your header info 2 title', 'framework'),
			'default' => 'Email Us',
		),
		array(
			'id' => 'header_email_us_icon',
			'type' => 'text',
			'title' => esc_html__('Header Info 2 Icon', 'framework'),
			'subtitle' => __('Enter your info 2 icon name. <a href="http://fontawesome.io/icons/" target="_blank">Icon names</a>', 'framework'),
			'default' => 'envelope',
		),
		array(
			'id'        => 'header_email_us',
			'type'      => 'text',
			'title'     => esc_html__('Header Info 2', 'framework'),
			'subtitle'  => esc_html__('Enter your header info 2 information', 'framework'),
			'default'   => 'sales@realspaces.com',
		),
		array(
			'id' => 'header_working_hours_title',
			'type' => 'text',
			'title' => esc_html__('Header Info 3 Title', 'framework'),
			'subtitle' => esc_html__('Enter your header info 3 title', 'framework'),
			'default' => 'Working Hours',
		),
		array(
			'id' => 'header_working_hours_icon',
			'type' => 'text',
			'title' => esc_html__('Header Info 3 Icon', 'framework'),
			'subtitle' => __('Enter your info 3 icon name. <a href="http://fontawesome.io/icons/" target="_blank">Icon names</a>', 'framework'),
			'default' => 'clock-o',
		),
		array(
			'id' => 'header_working_hours',
			'type' => 'text',
			'title' => esc_html__('Header Info 3', 'framework'),
			'subtitle' => esc_html__('Enter your header info 3 information', 'framework'),
			'default' => '09:00 to 17:00',
		),
		array(
			'id' => 'header_info_icon_typo',
			'type'        => 'typography',
			'title'       => esc_html__('Header info icons style', 'framework'),
			'google'      => false,
			'font-family' => false,
			'font-backup' => false,
			'subsets' 	  => false,
			'color' 		  => true,
			'text-align'  => false,
			'font-weight' => false,
			'font-style'  => false,
			'font-size'	  => true,
			'word-spacing' => false,
			'line-height' => false,
			'letter-spacing' => false,
			'output'      => array('.contact-info-blocks > div > i'),
			'units'       => 'px',
		),
		array(
			'id' => 'header_info_title_typo',
			'type'        => 'typography',
			'title'       => esc_html__('Header info title style', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'text-align'  => false,
			'font-weight' => true,
			'font-style'  => true,
			'font-size'	  => true,
			'word-spacing' => true,
			'line-height' => false,
			'letter-spacing' => true,
			'text-transform' => true,
			'output'      => array('.contact-info-blocks > div'),
			'units'       => 'px',
		),
		array(
			'id' => 'header_info_text_typo',
			'type'        => 'typography',
			'title'       => esc_html__('Header info text style', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'text-align'  => false,
			'font-weight' => true,
			'font-style'  => true,
			'font-size'	  => true,
			'word-spacing' => true,
			'line-height' => false,
			'letter-spacing' => true,
			'text-transform' => true,
			'output'      => array('.contact-info-blocks > div > span'),
			'units'       => 'px',
		),
	),
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-ok',
	'title' => __('Topbar', 'framework'),
	'subsection' => true,
	'fields' => array(
		array(
			'id' => 'show_topbar',
			'type' => 'checkbox',
			'title' => esc_html__('Show Topbar', 'framework'),
			'subtitle' => esc_html__(
				'Enable/Disable Topbar',
				'framework'
			),
			"default" => 1,
		),
		array(
			'id' => 'topbar_background',
			'type' => 'background',
			'background-color' => true,
			'background-image' => false,
			'background-repeat' => false,
			'background-attachment' => false,
			'background-size' => false,
			'background-position' => false,
			'preview' => false,
			'output' => array('.top-header'),
			'title' => esc_html__('Background Color', 'framework'),
			'subtitle' => esc_html__('Background color for the topbar.', 'framework'),
		),
		array(
			'id' => 'enable-top-header-login-dropdown',
			'type' => 'switch',
			'title' => __('Enable Top header login dropdown', 'framework'),
			'subtitle' => __('Enable/Disable Top header login dropdown behaviour of the theme', 'framework'),
			'default' => 1,
		),
		array(
			'id' => 'top_social_links',
			'type' => 'sortable',
			'label' => true,
			'compiler' => true,
			'title' => __('Social Links', 'framework'),
			'desc' => __('Enter the social links and sort to active and display according to sequence.', 'framework'),
			'options' => array(
				'fa-dribbble' => 'dribbble',
				'fa-dropbox' => 'dropbox',
				'fa-facebook' => 'facebook',
				'fa-flickr' => 'flickr',
				'fa-foursquare' => 'foursquare',
				'fa-github' => 'github',
				'fa-google-plus' => 'plus.google',
				'fa-instagram' => 'instagram',
				'fa-linkedin' => 'linkedin',
				'fa-pinterest' => 'pinterest',
				'fa-skype' => 'skype',
				'fa-stack-exchange' => 'stackexchange',
				'fa-stack-overflow' => 'stackoverflow',
				'fa-trello' => 'trello',
				'fa-tumblr' => 'tumblr',
				'fa-twitter' => 'twitter',
				'fa-vimeo-square' => 'vimeo',
				'fa-xing' => 'xing',
				'fa-youtube' => 'youtube',
				'fa-rss' => 'rss',
				'fa-skype' => 'Enter Skype ID',
				'fa-vk' => 'vk',
				'fa-envelope' => 'Enter Email Address'
			),
		),
		array(
			'id' => 'topbar_info_typography',
			'type'        => 'typography',
			'title'       => esc_html__('Topbar Typography', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'text-align'  => false,
			'font-weight' => true,
			'font-style'  => true,
			'font-size'	  => true,
			'word-spacing' => true,
			'line-height' => true,
			'letter-spacing' => true,
			'output'      => array('.horiz-nav > li > a'),
			'units'       => 'px',
		),
		array(
			'id'       => 'topbar_social_icon_color',
			'type'     => 'link_color',
			'hover' 	   => false,
			'active'    => false,
			'visited'  => false,
			'output'   => array('.horiz-nav > li > a'),
			'title'    => esc_html__('Topbar Link Color', 'framework'),
			'subtitle' => esc_html__('Set link color for Topbar Links', 'framework'),
		)
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-ok',
	'title' => __('Inner Page Header', 'framework'),
	'subsection' => true,
	'fields' => array(
		array(
			'id' => 'inner_page_header_display',
			'type' => 'checkbox',
			'compiler' => true,
			'title' => esc_html__('Hide page header', 'framework'),
			'subtitle' => esc_html__('Check this box to hide page header on the inner pages/posts/custom posts. This can be used as default for all inner pages and can override the individual page design options.', 'framework'),
			'default' => 0,
		),
		array(
			'id' => 'banner_image',
			'type' => 'media',
			'url' => true,
			'title' => __('Header Image', 'framework'),
			'desc' => __('Default header image for post types.', 'framework'),
			'subtitle' => __('Set this image as default header image for all Page/Post/Property/Agents/Gallery.', 'framework'),
			'default' => array('url' => $defaultBannerImages),
		),
		array(
			'id' => 'inner_page_header_background',
			'type' => 'background',
			'background-color' => true,
			'background-image' => false,
			'background-repeat' => false,
			'background-attachment' => false,
			'background-size' => false,
			'background-position' => false,
			'preview' => false,
			'output' => array('.page-header'),
			'title' => esc_html__('Default Banner Color', 'framework'),
			'subtitle' => esc_html__('Background color for the inner pages header.', 'framework'),
		),
		array(
			'id'       => 'page_header_padding',
			'type'     => 'spacing',
			'units'    => array('px'),
			'mode'	   => 'padding',
			'left'	   => false,
			'right'	   => false,
			'output'   => array('.page-header'),
			'title'    => esc_html__('Top and Bottom padding for inner pages header', 'framework'),
			'subtitle' => esc_html__('Enter top and bottom padding for inside pages header. Default is 40px/40px', 'framework'),
			'default'  => array(),
		),
		array(
			'id'       => 'page_header_banner_height',
			'type'     => 'dimensions',
			'units'    => array('px'),
			'width' 	   => false,
			'title'    => esc_html__('Default page banner height', 'framework'),
			'subtitle' => esc_html__('Set default height in px for the inner pages header banner image.', 'framework'),
			'output'   => array('.page-header .col-md-12'),
			'default'  => array(
				'height'  => '120px',
			),
		),
		array(
			'id'       => 'page_header_map_height',
			'type'     => 'dimensions',
			'units'    => array('px'),
			'width' 	   => false,
			'title'    => esc_html__('Default page map height', 'framework'),
			'subtitle' => esc_html__('Set default height in px for the property, contact pages header map.', 'framework'),
			'output'   => array('#onemap.map-single-page'),
			'default'  => array(
				'height'  => '200px'
			),
		),
		array(
			'id' => 'inner_page_header_title',
			'type' => 'checkbox',
			'compiler' => true,
			'title' => esc_html__('Hide page title', 'framework'),
			'subtitle' => esc_html__('Check this box to hide page title in the inner page header. This can be used as default for all inner pages and can override the individual page design options.', 'framework'),
			'default' => 0,
		),
		array(
			'id' => 'inner_page_header_title_typography',
			'type'        => 'typography',
			'title'       => esc_html__('Title Typography', 'framework'),
			'subtitle' => esc_html__('Typography options for inner page header title.', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'text-align'  => true,
			'font-weight' => true,
			'font-style'  => true,
			'font-size'	  => true,
			'word-spacing' => true,
			'line-height' => true,
			'letter-spacing' => true,
			'text-transform' => true,
			'output'      => array('.page-header h1'),
			'units'       => 'px',
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-upload',
	'title' => esc_html__('Logo', 'framework'),
	'fields' => array(
		array(
			'id' => 'logo_upload',
			'type' => 'media',
			'url' => true,
			'title' => esc_html__('Upload Logo', 'framework'),
			'subtitle' => esc_html__('Upload site logo to display in header.', 'framework'),
			'default' => array('url' => $defaultLogo),
		),
		array(
			'id' => 'retina_logo_upload',
			'type' => 'media',
			'url' => true,
			'title' => esc_html__('Upload Logo for Retina Devices', 'framework'),
			'desc' => esc_html__('Retina Display is a marketing term developed by Apple to refer to devices and monitors that have a resolution and pixel density so high – roughly 300 or more pixels per inch', 'framework'),
			'subtitle' => esc_html__('Upload site logo retina version to display in header.', 'framework'),
			'default' => array('url' => $default_retina_logo),
		),
		array(
			'id' => 'retina_logo_width',
			'type' => 'text',
			'title' => esc_html__('Standard Logo Width for Retina Logo', 'framework'),
			'subtitle' => esc_html__('If retina logo is uploaded, enter the standard logo (1x) version width, do not enter the retina logo width.', 'framework'),
			'default' => '161'
		),
		array(
			'id' => 'retina_logo_height',
			'type' => 'text',
			'title' => esc_html__('Standard Logo Height for Retina Logo', 'framework'),
			'subtitle' => esc_html__('If retina logo is uploaded, enter the standard logo (1x) version height, do not enter the retina logo height.', 'framework'),
			'default' => '18'
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-ok',
	'title' => esc_html__('Admin Logo', 'framework'),
	'subsection' => true,
	'fields' => array(
		array(
			'id' => 'custom_admin_login_logo',
			'type' => 'media',
			'url' => true,
			'title' => esc_html__('Custom admin login logo', 'framework'),
			'compiler' => 'true',
			'desc' => esc_html__('Upload a 254 x 95px image here to replace the admin login logo.', 'framework'),
			'subtitle' => '',
			'default' => array('url' => $defaultAdminLogo),
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-ok',
	'title' => esc_html__('Favicon Options', 'framework'),
	'desc' => esc_html__('These are optional fields and can be ignored if a single image is uploaded at Appearance > Customize > Site Identity > Site Icon', 'framework'),
	'subsection' => true,
	'fields' => array(
		array(
			'id' => 'custom_favicon',
			'type' => 'media',
			'compiler' => 'true',
			'title' => esc_html__('Custom favicon', 'framework'),
			'desc' => esc_html__('Upload a image that will represent your website favicon', 'framework'),
			'default' => array('url' => $default_favicon),
		),
		array(
			'id' => 'iphone_icon',
			'type' => 'media',
			'compiler' => 'true',
			'title' => esc_html__('Apple iPhone Icon', 'framework'),
			'desc' => esc_html__('Upload Favicon for Apple iPhone (57px x 57px)', 'framework'),
			'default' => array('url' => $default_iphone),
		),
		array(
			'id' => 'iphone_icon_retina',
			'type' => 'media',
			'compiler' => 'true',
			'title' => esc_html__('Apple iPhone Retina Icon', 'framework'),
			'desc' => esc_html__('Upload Favicon for Apple iPhone Retina Version (114px x 114px)', 'framework'),
			'default' => array('url' => $default_iphone_retina),
		),
		array(
			'id' => 'ipad_icon',
			'type' => 'media',
			'compiler' => 'true',
			'title' => esc_html__('Apple iPad Icon', 'framework'),
			'desc' => esc_html__('Upload Favicon for Apple iPad (72px x 72px)', 'framework'),
			'default' => array('url' => $default_ipad),
		),
		array(
			'id' => 'ipad_icon_retina',
			'type' => 'media',
			'compiler' => 'true',
			'title' => esc_html__('Apple iPad Retina Icon Upload', 'framework'),
			'desc' => esc_html__('Upload Favicon for Apple iPad Retina Version (144px x 144px)', 'framework'),
			'default' => array('url' => $default_ipad_retina),
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-lines',
	'title' => __('Menu', 'framework'),
	'fields' => array(
		array(
			'id' => 'menu_background',
			'type' => 'background',
			'background-color' => true,
			'output' => array('.main-menu-wrapper'),
			'title' => esc_html__('Menu row background', 'framework'),
			'subtitle' => esc_html__('Background options for the main navigation.', 'framework'),
		),
		array(
			'id' => 'menu_typo',
			'type'        => 'typography',
			'title'       => esc_html__('Menu Typography', 'framework'),
			'subtitle' => esc_html__('Typography options for inner page header title.', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => false,
			'text-align'  => false,
			'font-weight' => true,
			'font-style'  => true,
			'font-size'	  => true,
			'word-spacing' => true,
			'line-height' => true,
			'letter-spacing' => true,
			'output'      => array('.navigation > ul > li > a'),
			'units'       => 'px',
		),
		array(
			'id'       => 'menu_link_color',
			'type'     => 'link_color',
			'output'   => array('.navigation > ul > li > a'),
			'title'    => esc_html__('Menu Link Color', 'framework'),
			'subtitle' => esc_html__('Set link color for main navigation Links', 'framework'),
		),
		array(
			'id' => 'dd_background',
			'type' => 'background',
			'background-image' => false,
			'background-repeat' => false,
			'background-size' => false,
			'background-position' => false,
			'background-attachment' => false,
			'preview' => false,
			'transparent' => false,
			'output' => array('.navigation > ul > li ul, .navigation ul > li:hover > a'),
			'title' => esc_html__('Background color for dropdown menus', 'framework'),
			'desc' => esc_html__('Background color set for the dropdowns of main navigation.', 'framework'),
		),
		array(
			'id' => 'dd_dropshadow',
			'type' => 'checkbox',
			'title' => esc_html__('Dropdowns Drop-Shadow', 'framework'),
			'subtitle' => esc_html__('Uncheck to disable drop-shadow on dropdown div. Check to enable.', 'framework'),
			"default" => 1,
		),
		array(
			'id'       => 'dd_item_border',
			'type'     => 'border',
			'title'    => esc_html__('Dropdown links border bottom', 'framework'),
			'output'   => array('.navigation > ul > li > ul li > a'),
			'top' 	   => false,
			'left' 	   => false,
			'right' 	   => false,
			'bottom' 	=> true
		),
		array(
			'id'       => 'dd_item_link_typo',
			'type'     => 'typography',
			'text-transform' => true,
			'color' => false,
			'line-height' => false,
			'letter-spacing' => true,
			'word-spacing' => true,
			'text-align' => false,
			'title'    => esc_html__('Dropdown Links Typography', 'framework'),
			'output'   => array('.navigation > ul > li > ul li > a')
		),
		array(
			'id'       => 'dd_item_link_color',
			'type'     => 'link_color',
			'title'    => esc_html__('Dropdown links color', 'framework'),
			'output'   => array('.navigation > ul > li > ul li > a')
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-ok',
	'title' => esc_html__('Mobile Menu', 'framework'),
	'subsection' => true,
	'fields' => array(
		array(
			'id'       => 'menu_toggle_typo',
			'type'     => 'typography',
			'text-transform' => false,
			'font-family' => false,
			'font-weight' => false,
			'font-style' => false,
			'color' => false,
			'text-align' => false,
			'preview' => false,
			'title'    => esc_html__('Mobile Menu opener icon size', 'framework'),
			'output'   => array('.site-header .menu-toggle'),
		),
		array(
			'id'       => 'menu_toggle_color',
			'type'     => 'link_color',
			'title'    => esc_html__('Mobile Menu opener icon color', 'framework'),
			'output'   => array('.site-header .menu-toggle')
		),
		array(
			'id' => 'menu_toggle_spacing',
			'type' => 'spacing',
			'title' => esc_html__('Mobile Menu opener icon spacing', 'framework'),
			'desc' => esc_html__('', 'framework'),
			'mode' 	   => 'margin',
			'units'    => array('px'),
			'output'   => array('.site-header .menu-toggle'),
		),
		array(
			'id' => 'mm_background',
			'type' => 'background',
			'background-image' => false,
			'background-repeat' => false,
			'background-size' => false,
			'background-position' => false,
			'background-attachment' => false,
			'preview' => false,
			'transparent' => false,
			'title' => esc_html__('Mobile Menu background', 'framework'),
		),
		array(
			'id'       => 'mm_item_border',
			'type'     => 'border',
			'title'    => esc_html__('Mobile Menu links border bottom', 'framework'),
			'top' 	   => false,
			'left' 	   => false,
			'right' 	   => false,
			'bottom' 	=> true
		),
		array(
			'id'       => 'mm_item_link_color',
			'type'     => 'link_color',
			'title'    => esc_html__('Mobile Menu links color', 'framework')
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-chevron-down',
	'title' => esc_html__('Footer', 'framework'),
	'desc' => esc_html__('These are the options for the footer.', 'framework'),
	'fields' => array(
		array(
			'id' => 'full_width_footer',
			'type' => 'checkbox',
			'title' => esc_html__('100% Footer Width', 'framework'),
			'subtitle' => esc_html__('Check this box to set footer width to 100% of the browser width. Uncheck to follow site width. Only works with wide layout mode.', 'framework'),
			"default" => 0,
		),
		array(
			'id' => 'footer_top_sec',
			'type' => 'section',
			'indent' => true,
			'title' => esc_html__('Footer Widgets Area', 'framework'),
		),
		array(
			'id'        => 'footer_column',
			'type'      => 'image_select',
			'title'     => esc_html__('Footer Layout', 'framework'),
			'subtitle'      => esc_html__('Select the footer widgeted area layout', 'framework'),
			'options'   => array(
				'12' => array('alt' => 'One Column', 'img' => get_template_directory_uri() . '/assets/images/admin/footerColumns/footer-1.png'),
				'6' => array('alt' => 'One Half Column', 'img' => get_template_directory_uri() . '/assets/images/admin/footerColumns/footer-2.png'),
				'4' => array('alt' => 'One Third Column', 'img' => get_template_directory_uri() . '/assets/images/admin/footerColumns/footer-3.png'),
				'3' => array('alt' => 'One Fourth Column', 'img' => get_template_directory_uri() . '/assets/images/admin/footerColumns/footer-4.png'),
				'2' => array('alt' => 'One Fourth Column', 'img' => get_template_directory_uri() . '/assets/images/admin/footerColumns/footer-5.png'),
			),
			'default' => '3'
		),
		array(
			'id' => 'footer_sidebar_background_color',
			'type' => 'color',
			'title' => esc_html__('Footer widgets area Background Color', 'framework'),
			'subtitle' => esc_html__('Background color for the footer widgets area.', 'framework'),
			'validate' => 'color',
		),
		array(
			'id' => 'footer_background',
			'type' => 'background',
			'background-color' => false,
			'output' => array('.site-footer'),
			'title' => esc_html__('Footer widgets area Background Image', 'framework'),
			'subtitle' => esc_html__('Background image for the footer widgets area.', 'framework'),
		),
		array(
			'id' => 'footer_dropshadow',
			'type' => 'checkbox',
			'title' => esc_html__('Footer Drop-Shadow', 'framework'),
			'subtitle' => esc_html__('Uncheck to disable top drop-shadow on site footer. Check to enable.', 'framework'),
			"default" => 1,
		),
		array(
			'id'       => 'footer_border',
			'type'     => 'border',
			'title'    => esc_html__('Site Footer Border Top', 'framework'),
			'output' => array('.site-footer'),
			'top' 	   => true,
			'left' 	   => false,
			'right' 	   => false,
			'bottom' 	=> false
		),
		array(
			'id'       => 'footer_top_spacing',
			'type'     => 'spacing',
			'left' => false,
			'right' => false,
			'title'    => esc_html__('Footer widgets area Top/Bottom padding', 'framework'),
			'desc' => esc_html__('Enter top and bottom spacing for the footer widget area. DO NOT ENTER px HERE.', 'framework'),
			'mode' 	   => 'padding',
			'output' => array('.site-footer'),
			'units'    => array('px'),
		),
		array(
			'id'          => 'widgettitle_typo',
			'type'        => 'typography',
			'text-transform' => true,
			'word-spacing' => true,
			'letter-spacing' => true,
			'title'       => esc_html__('Footer widgets title typography', 'framework'),
			'output'      => array('.footer-widget .widgettitle, .footer-widget .widget-title'),
		),
		array(
			'id'          => 'tfwidget_typo',
			'type'        => 'typography',
			'text-transform' => true,
			'word-spacing' => true,
			'letter-spacing' => true,
			'title'       => esc_html__('Footer widgets area text typography', 'framework'),
			'output'      => array('.site-footer .footer-widget'),
		),
		array(
			'id'          => 'tfooter_link_color',
			'type'        => 'link_color',
			'title'       => esc_html__('Footer widgets area links color', 'framework'),
			'output'      => array('.body .site-footer .footer-widget a'),
		),
		array(
			'id' => 'footer_bottom_sec',
			'type' => 'section',
			'indent' => true,
			'title' => esc_html__('Footer Copyrights Area', 'framework'),
		),
		array(
			'id' => 'footer_bottom_enable',
			'type' => 'checkbox',
			'title' => esc_html__('Enable Footer copyrights area', 'framework'),
			'subtitle' => esc_html__('Uncheck to disable footer copyrights area that comes below the footer widgets area.', 'framework'),
			'default' => 1
		),
		array(
			'id' => 'footer_background_color',
			'type' => 'color',
			'title' => esc_html__('Footer copyrights area background', 'framework'),
			'subtitle' => esc_html__('Pick a color for Footer Background.', 'framework'),
			'validate' => 'color',
		),
		array(
			'id'       => 'footer_bottom_spacing',
			'type'     => 'spacing',
			'left' => false,
			'right' => false,
			'title'    => esc_html__('Footer copyrights area Top/Bottom padding', 'framework'),
			'desc' => esc_html__('Enter top and bottom spacing for the footer copyrights area. DO NOT ENTER px HERE.', 'framework'),
			'mode' 	   => 'padding',
			'output' => array('.site-footer-bottom'),
			'units'    => array('px'),
		),
		array(
			'id'          => 'bfooter_border',
			'type'        => 'border',
			'title'       => esc_html__('Footer copyrights area border top', 'framework'),
			'left' => false,
			'right' => false,
			'bottom' => false,
			'top' => true,
			'output'      => array('.site-footer-bottom'),
		),
		array(
			'id' => 'footer_copyright_text',
			'type' => 'text',
			'title' => esc_html__('Footer Copyright Text', 'framework'),
			'subtitle' => esc_html__(' Enter Copyright Text', 'framework'),
			'default' => esc_html__('All Rights Reserved', 'framework')
		),
		array(
			'id'          => 'bfwidget_typo',
			'type'        => 'typography',
			'text-transform' => true,
			'title'       => esc_html__('Footer copyrights area text typography', 'framework'),
			'output'      => array('.site-footer-bottom'),
		),
		array(
			'id'          => 'bfooter_link_color',
			'type'        => 'link_color',
			'title'       => esc_html__('Footer copyrights area links color', 'framework'),
			'output'      => array('.site-footer-bottom a'),
		),
		array(
			'id' => 'footer_social_links',
			'type' => 'sortable',
			'label' => true,
			'compiler' => true,
			'title' => esc_html__('Social Links', 'framework'),
			'desc' => esc_html__('Enter the social links and sort to active and display according to sequence in footer.', 'framework'),
			'options' => array(
				'fa-dribbble' => 'dribbble',
				'fa-dropbox' => 'dropbox',
				'fa-envelope' => 'Enter Email Address',
				'fa-facebook' => 'facebook',
				'fa-flickr' => 'flickr',
				'fa-foursquare' => 'foursquare',
				'fa-github' => 'github',
				'fa-google-plus' => 'plus.google',
				'fa-instagram' => 'instagram',
				'fa-linkedin' => 'linkedin',
				'fa-pinterest' => 'pinterest',
				'fa-rss' => 'rss',
				'fa-skype' => 'Enter Skype ID',
				'fa-stack-exchange' => 'stackexchange',
				'fa-stack-overflow' => 'stackoverflow',
				'fa-trello' => 'trello',
				'fa-tumblr' => 'tumblr',
				'fa-twitter' => 'twitter',
				'fa-vimeo-square' => 'vimeo',
				'fa-xing' => 'xing',
				'fa-vk' => 'vk',
				'fa-youtube' => 'youtube',
			),
		),
		array(
			'id' => 'footer_bottom_icons',
			'type' => 'typography',
			'google'      => false,
			'font-family'      => false,
			'font-backup' => false,
			'subsets' 	  => false,
			'color' 		  => false,
			'text-align'	  => false,
			'font-weight' => false,
			'font-style' => false,
			'font-size'	  => true,
			'word-spacing' => false,
			'line-height' => true,
			'letter-spacing' => false,
			'text-transform' => false,
			'preview' => false,
			'output' => array('.site-footer-bottom .social-icons a'),
			'title' => esc_html__('Social icons size and color for Site Footer Bottom Social icons', 'framework'),
		),
		array(
			'id' => 'footer_bottom_icons_link_color',
			'compiler' => true,
			'type' => 'link_color',
			'hover' => false,
			'active' => false,
			'output' => array('.site-footer-bottom .social-icons a'),
			'title' => esc_html__('Link color for Site Footer Bottom Social icons', 'framework'),
		),
		array(
			'id' => 'footer_bottom_icons_bg',
			'compiler' => true,
			'type' => 'background',
			'background-image' => false,
			'background-repeat' => false,
			'background-position' => false,
			'background-attachment' => false,
			'background-size' => false,
			'preview' => false,
			'output' => array('.site-footer-bottom .social-icons a'),
			'title' => esc_html__('Background color for Site Footer Bottom Social icons', 'framework'),
		),
		array(
			'id'       => 'footer_bottom_icons_dimension',
			'type'     => 'dimensions',
			'units'    => 'px',
			'output' => array('.site-footer-bottom .social-icons a'),
			'title'    => __('Width/Height for Site Footer Bottom Social icons', 'framework'),
		),
	),
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-indent-left',
	'title' => __('Sidebars', 'framework'),
	'fields' => array(
		array(
			'id' => 'sidebar_position',
			'type' => 'image_select',
			'compiler' => true,
			'title' => __('Sidebar position', 'framework'),
			'subtitle' => __('Select the Global Sidebar Position. Can be overridden by page sidebar settings.', 'framework'),
			'options' => array(
				'2' => array('title' => 'Left', 'img' => ReduxFramework::$_url . 'assets/img/2cl.png'),
				'1' => array('title' => 'Right', 'img' => ReduxFramework::$_url . 'assets/img/2cr.png')
			),
			'default' => '1'
		),
		array(
			'id' => 'sidebar_width',
			'type' => 'button_set',
			'title' => __('Sidebar Width', 'framework'),
			'subtitle' => __('Select global width for sidebars.', 'framework'),
			'desc' => __('Width of sidebars from the total site width.', 'framework'),
			'options' => array(
				'3' => __('One Fourth', 'framework'),
				'4' => __('One Third', 'framework'),
				'6' => __('One Half', 'framework')
			),
			'default' => '3'
		),
		array(
			'id'       => 'page_sidebar',
			'type'     => 'select',
			'title'    => __('Pages Sidebar', 'framework'),
			'desc'     => __('Select sidebar that will display by default on all pages(Using default page template).', 'framework'),
			'data'  => 'sidebars',
		),
		array(
			'id'       => 'post_sidebar',
			'type'     => 'select',
			'title'    => __('Posts Sidebar', 'framework'),
			'desc'     => __('Select sidebar that will display by default on all blog posts.', 'framework'),
			'data'  => 'sidebars',
		),
		array(
			'id'       => 'property_sidebar',
			'type'     => 'select',
			'title'    => __('Property Pages Sidebar', 'framework'),
			'desc'     => __('Select sidebar that will display by default on all single property pages.', 'framework'),
			'data'  => 'sidebars',
		),
		array(
			'id'       => 'taxonomy_sidebar',
			'type'     => 'select',
			'title'    => __('Property Taxonomies Sidebar', 'framework'),
			'desc'     => __('Select sidebar that will display by default on all archive pages of property contract types, property types, city.', 'framework'),
			'data'  => 'sidebars',
		),
		array(
			'id'       => 'agent_sidebar',
			'type'     => 'select',
			'title'    => __('Agent Pages Sidebar', 'framework'),
			'desc'     => __('Select sidebar that will display by default on all agent profile pages.', 'framework'),
			'data'  => 'sidebars',
		),
		array(
			'id'       => 'search_sidebar',
			'type'     => 'select',
			'title'    => __('Search Page Sidebar', 'framework'),
			'desc'     => __('Select sidebar that will display on search result page.', 'framework'),
			'data'  => 'sidebars',
			'default'  => 'main-sidebar',
		),
		array(
			'id' => 'sidebar_widget_styling',
			'type' => 'section',
			'indent' => true,
			'title' => __('Sidebar Widget Styling', 'framework'),
		),
		array(
			'id'       => 'swidget_bg',
			'type'     => 'background',
			'background-image' => false,
			'preview' => false,
			'title'    => __('Sidebar widgets background', 'framework'),
			'output' => array('.sidebar .widget'),
		),
		array(
			'id'       => 'swidget_padding',
			'type'     => 'spacing',
			'title'    => __('Sidebar widgets padding', 'framework'),
			'mode' 	   => 'padding',
			'output' => array('.sidebar .widget'),
		),
		array(
			'id'          => 'swidget_border',
			'type'        => 'border',
			'title'       => __('Sidebar widgets border', 'framework'),
			'all' => true,
			'output'      => array('.sidebar .widget'),
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-info-circle',
	'title' => __('Featured Blocks', 'framework'),
	'desc' => __('Add featured blocks area on for homepage template.', 'framework'),
	'fields' => array(
		$fields = array(
			'id'          => 'opt-slides',
			'type'        => 'slides',
			'title'       => __('Featured Block', 'framework'),
			'subtitle'    => __('Add more using "Add Slide" button to the right. Delete using the delete button that is inside each block.', 'framework'),
			'desc'        => '',
			'placeholder' => array(
				'title'           => __('Enter title for featured block', 'framework'),
				'description'     => __('Enter description for featured block', 'framework'),
				'url'             => __('Enter URL for featured block', 'framework'),
			),
		),
	),
));
Redux::setSection($opt_name, array(
	'icon'      => 'el-icon-brush',
	'title'     => __('Color Scheme', 'framework'),
	'fields'    => array(
		array(
			'id' => 'theme_color_type',
			'type' => 'button_set',
			'compiler' => true,
			'title' => __('Color Scheme', 'framework'),
			'subtitle' => __('Select between premade schemes or custom color options', 'framework'),
			'options' => array(
				'0' => __('Pre-Defined Color Schemes', 'framework'),
				'1' => __('Custom Color', 'framework')
			),
			'default' => '0',
		),
		array(
			'id' => 'theme_color_scheme',
			'type' => 'select',
			'required' => array('theme_color_type', 'equals', '0'),
			'title' => __('Theme Color Scheme', 'framework'),
			'subtitle' => __('Select the prebuilt color scheme', 'framework'),
			'options' => array('color1.css' => 'color1.css', 'color2.css' => 'color2.css', 'color3.css' => 'color3.css', 'color4.css' => 'color4.css', 'color5.css' => 'color5.css', 'color6.css' => 'color6.css', 'color7.css' => 'color7.css', 'color8.css' => 'color8.css', 'color9.css' => 'color9.css', 'color10.css' => 'color10.css'),
			'default' => 'color1.css',
		),
		array(
			'id' => 'custom_theme_color',
			'type' => 'color',
			'required' => array('theme_color_type', 'equals', '1'),
			'title' => __('Custom Theme Color', 'framework'),
			'subtitle' => __('Pick a color for the template.', 'framework'),
			'validate' => 'color',
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-font',
	'title' => __('Typography', 'framework'),
	'fields' => array(
		array(
			'id'          => 'body_font_typo',
			'type'        => 'typography',
			'title'       => __('Body text default typography', 'framework'),
			'subtitle'       => __('<strong>Defaults:</strong><br>Font Family - Open Sans<br>Font weight - 400(normal)<br>Font Size - 13px<br>Line Height - 20px<br>Letter Spacing - 0px<br>Color - #666666<br>Text transform - none', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'font-family' => true,
			'font-style'  => true,
			'font-weight' => true,
			'preview' 	  => true,
			'text-align'	  => false,
			'font-size'	  => true,
			'line-height' => true,
			'letter-spacing' => true,
			'text-transform' => true,
			'output'      => array('body'),
			'units'       => 'px',
			'default'     => array(
				'font-family' => 'Open Sans'
			),
		),
		array(
			'id'          => 'body_h1_font_typo',
			'type'        => 'typography',
			'title'       => __('H1 heading typography', 'framework'),
			'subtitle'       => __('<strong>Defaults:</strong><br>Font Family - Montserrat<br>Font weight - Normal<br>Font Size - 36px<br>Line Height - 42px<br>Letter Spacing - 0px<br>Color - #333333<br>Text transform - none', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'font-family' => true,
			'font-style'  => true,
			'font-weight' => true,
			'preview' 	  => true,
			'text-align'	  => false,
			'font-size'	  => true,
			'line-height' => true,
			'text-transform' => true,
			'letter-spacing' => true,
			'output'      => array('h1'),
			'units'       => 'px',
			'default'     => array(
				'font-family' => 'Montserrat'
			),
		),
		array(
			'id'          => 'body_h2_font_typo',
			'type'        => 'typography',
			'title'       => __('H2 heading typography', 'framework'),
			'subtitle'       => __('<strong>Defaults:</strong><br>Font Family - Montserrat<br>Font weight - Normal<br>Font Size - 30px<br>Line Height - 36px<br>Letter Spacing - 0px<br>Color - #333333<br>Text transform - none', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'font-family' => true,
			'font-style'  => true,
			'font-weight' => true,
			'preview' 	  => true,
			'text-align'	  => false,
			'font-size'	  => true,
			'line-height' => true,
			'text-transform' => true,
			'letter-spacing' => true,
			'output'      => array('h2'),
			'units'       => 'px',
			'default'     => array(),
		),
		array(
			'id'          => 'body_h3_font_typo',
			'type'        => 'typography',
			'title'       => __('H3 heading typography', 'framework'),
			'subtitle'       => __('<strong>Defaults:</strong><br>Font Family - Montserrat<br>Font weight - Normal<br>Font Size - 24px<br>Line Height - 30px<br>Letter Spacing - 0px<br>Color - #333333<br>Text transform - none', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'font-family' => true,
			'font-style'  => true,
			'font-weight' => true,
			'preview' 	  => true,
			'text-align'	  => false,
			'font-size'	  => true,
			'line-height' => true,
			'text-transform' => true,
			'letter-spacing' => true,
			'output'      => array('h3'),
			'units'       => 'px',
			'default'     => array(),
		),
		array(
			'id'          => 'body_h4_font_typo',
			'type'        => 'typography',
			'title'       => __('H4 heading typography', 'framework'),
			'subtitle'       => __('<strong>Defaults:</strong><br>Font Family - Montserrat Condensed<br>Font weight - Bold<br>Font Size - 16px<br>Line Height - 22px<br>Letter Spacing - 2px<br>Color - #333333<br>Text transform - Uppercase', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'font-family' => true,
			'font-style'  => true,
			'font-weight' => true,
			'preview' 	  => true,
			'text-align'	  => false,
			'font-size'	  => true,
			'line-height' => true,
			'text-transform' => true,
			'letter-spacing' => true,
			'output'      => array('h4'),
			'units'       => 'px',
			'default'     => array(),
		),
		array(
			'id'          => 'body_h5_font_typo',
			'type'        => 'typography',
			'title'       => __('H5 heading typography', 'framework'),
			'subtitle'       => __('<strong>Defaults:</strong><br>Font Family - Montserrat<br>Font weight - Bold<br>Font Size - 14px<br>Line Height - 22px<br>Letter Spacing - 0px<br>Color - #333333<br>Text transform - none', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'font-family' => true,
			'font-style'  => true,
			'font-weight' => true,
			'preview' 	  => true,
			'text-align'	  => false,
			'font-size'	  => true,
			'line-height' => true,
			'text-transform' => true,
			'letter-spacing' => true,
			'output'      => array('h5'),
			'units'       => 'px',
			'default'     => array(),
		),
		array(
			'id'          => 'body_h6_font_typo',
			'type'        => 'typography',
			'title'       => __('H6 heading typography', 'framework'),
			'subtitle'       => __('<strong>Defaults:</strong><br>Font Family - Montserrat<br>Font weight - Normal<br>Font Size - 12px<br>Line Height - 18px<br>Letter Spacing - 0px<br>Color - #333333<br>Text transform - none', 'framework'),
			'google'      => true,
			'font-backup' => true,
			'subsets' 	  => true,
			'color' 		  => true,
			'font-family' => true,
			'font-style'  => true,
			'font-weight' => true,
			'preview' 	  => true,
			'text-align'	  => false,
			'font-size'	  => true,
			'line-height' => true,
			'text-transform' => true,
			'letter-spacing' => true,
			'output'      => array('h6'),
			'units'       => 'px',
			'default'     => array(),
		),
	),
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-share',
	'title' => __('Share Options', 'framework'),
	'fields' => array(
		array(
			'id' => 'switch_sharing',
			'type' => 'switch',
			'title' => __('Social Sharing', 'framework'),
			'subtitle' => __(
				'Enable/Disable theme default social sharing buttons for posts/events/sermons/causes single pages',
				'framework'
			),
			"default" => 1,
		),
		array(
			'id' => 'sharing_style',
			'type' => 'button_set',
			'compiler' => true,
			'title' => __('Share Buttons Style', 'framework'),
			'subtitle' => __('Choose the style of share button icons', 'framework'),
			'options' => array(
				'0' => __('Rounded', 'framework'),
				'1' => __('Squared', 'framework')
			),
			'default' => '0',
		),
		array(
			'id' => 'sharing_color',
			'type' => 'button_set',
			'compiler' => true,
			'title' => __('Share Buttons Color', 'framework'),
			'subtitle' => __('Choose the color scheme of the share button icons', 'framework'),
			'options' => array(
				'0' => __('Brand Colors', 'framework'),
				'1' => __('Theme Color', 'framework'),
				'2' => __('GrayScale', 'framework')
			),
			'default' => '0',
		),
		array(
			'id'       => 'share_icon',
			'type'     => 'checkbox',
			'required' => array('switch_sharing', 'equals', '1'),
			'title'    => __('Social share options', 'framework'),
			'subtitle' => __('Click on the buttons to disable/enable share buttons', 'framework'),
			'options'  => array(
				'1' => 'Facebook',
				'2' => 'Twitter',
				'3' => 'Google',
				'4' => 'Tumblr',
				'5' => 'Pinterest',
				'6' => 'Reddit',
				'7' => 'Linkedin',
				'8' => 'Email',
				'9' => 'VKontakte'
			),
			'default' => array(
				'1' => '1',
				'2' => '1',
				'3' => '1',
				'4' => '1',
				'5' => '1',
				'6' => '1',
				'7' => '1',
				'8' => '1',
				'9' => '0'
			)
		),
		array(
			'id'       => 'share_post_types',
			'type'     => 'checkbox',
			'required' => array('switch_sharing', 'equals', '1'),
			'title'    => __('Select share buttons for post types', 'framework'),
			'subtitle'     => __('Uncheck to disable for any type', 'framework'),
			'options'  => array(
				'1' => 'Posts',
				'2' => 'Pages',
				'3' => 'Properties'
			),
			'default' => array(
				'1' => '1',
				'2' => '1',
				'3' => '1'
			)
		),
		array(
			'id'       => 'share_links_alt',
			'type'     => 'section',
			'indent' => true,
			'title'    => esc_html__('Sharing links alt/title text', 'framework'),
		),
		array(
			'id' => 'facebook_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Facebook share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Facebook share icon browser tooltip.', 'framework'),
			'default' => 'Share on Facebook'
		),
		array(
			'id' => 'twitter_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Twitter share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Twitter share icon browser tooltip.', 'framework'),
			'default' => 'Tweet'
		),
		array(
			'id' => 'google_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Google Plus share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Google Plus share icon browser tooltip.', 'framework'),
			'default' => 'Share on Google+'
		),
		array(
			'id' => 'tumblr_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Tumblr share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Tumblr share icon browser tooltip.', 'framework'),
			'default' => 'Post to Tumblr'
		),
		array(
			'id' => 'pinterest_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Pinterest share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Pinterest share icon browser tooltip.', 'framework'),
			'default' => 'Pin it'
		),
		array(
			'id' => 'reddit_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Reddit share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Reddit share icon browser tooltip.', 'framework'),
			'default' => 'Submit to Reddit'
		),
		array(
			'id' => 'linkedin_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Linkedin share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Linkedin share icon browser tooltip.', 'framework'),
			'default' => 'Share on Linkedin'
		),
		array(
			'id' => 'email_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for Email share icon', 'framework'),
			'subtitle' => esc_html__('Text for the Email share icon browser tooltip.', 'framework'),
			'default' => 'Email'
		),
		array(
			'id' => 'vk_share_alt',
			'type' => 'text',
			'title' => esc_html__('Tooltip text for vk share icon', 'framework'),
			'subtitle' => esc_html__('Text for the vk share icon browser tooltip.', 'framework'),
			'default' => 'Share on vk'
		),
		array(
			'id'       => 'share_links_styling',
			'type'     => 'section',
			'indent' => true,
			'title'    => esc_html__('Sharing icons styling', 'framework'),
		),
		array(
			'id'       => 'share_before_icon',
			'type'     => 'checkbox',
			'title'    => esc_html__('Show sharing icon before the sharing icons', 'framework'),
			'default' => 1
		),
		array(
			'id'       => 'share_before_text',
			'type'     => 'text',
			'title'    => esc_html__('Enter title to show before the sharing icons', 'framework'),
			'default' => ''
		),
		array(
			'id'       => 'share_before_typo',
			'type'     => 'typography',
			'text-transform' => true,
			'title'    => esc_html__('Share before text/icon typography', 'framework'),
			'output'   => array('.share-buttons .share-title'),
			'default' => array(
				'font-size' => '26px',
				'line-height' => '28px'
			)
		),
		array(
			'id'       => 'share_icons_box_size',
			'type'     => 'dimensions',
			'title'    => esc_html__('Share icons box size', 'framework'),
			'output'   => array('.share-buttons > li > a'),
			'default' => array(
				'height' => '28px',
				'width' => '28px'
			)
		),
		array(
			'id'       => 'share_icons_font_size',
			'type'     => 'typography',
			'title'    => esc_html__('Share icons font size', 'framework'),
			'desc'    => esc_html__('Keep line height same as height of icon boxes set above', 'framework'),
			'font-weight' => false,
			'font-family' => false,
			'font-style' => false,
			'text-align' => false,
			'preview' => false,
			'color' => false,
			'output'   => array('.share-buttons > li > a'),
			'default' => array(
				'line-height' => '28px',
				'font-size' => '13px'
			)
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-envelope',
	'title' => esc_html__('Custom Messages', 'framework'),
	'desc' => esc_html__('Custom messages for various actions.', 'framework'),
	'fields' => array(
		array(
			'id' => 'logged_out_msg',
			'type' => 'textarea',
			'title' => esc_html__('Logged out message', 'framework'),
			'subtitle' => esc_html__('Enter message to show when user logged out.', 'framework'),
			'default' => esc_html__('<h2>You must have Agents rights to view this page.</h2>', 'framework'),
		),
		array(
			'id' => 'no_agents_msg',
			'type' => 'textarea',
			'title' => esc_html__('No Agent Message', 'framework'),
			'subtitle' => esc_html__('Enter message to show when no agents were found on the page using "Agents Template"', 'framework'),
			'default' => esc_html__('<h2>No Agents has been registered for this website.</h2>', 'framework'),
		),
		array(
			'id' => 'paypal_thanks',
			'type' => 'textarea',
			'title' => esc_html__('Successful payment message', 'framework'),
			'subtitle' => esc_html__('Enter message to show when user gets redirected from PayPal website after successful payment.', 'framework'),
			'default' => esc_html__('Your Payment has been made successfully, you can now start adding property.', 'framework'),
		),
		array(
			'id' => 'publish_property_email',
			'type' => 'ace_editor',
			'title' => esc_html__('On Publish Property Mail Content', 'framework'),
			'subtitle' => esc_html__('Paste your HTML email code here.', 'framework'),
			'mode' => 'html',
			'theme' => 'chrome',
			'desc' => esc_html__('You can use these default shortcodes to send dynamic data in email sent to users.<br />[title] = Property name<br /> [url] = Property URL', 'framework'),
			'default' => "Your property [title] listing is now live on website. Click to see property details [url]"
		),
		array(
			'id' => 'favorite_property_email',
			'type' => 'ace_editor',
			'title' => esc_html__('Favorite Property Mail Content', 'framework'),
			'subtitle' => esc_html__('Paste your HTML email code here.', 'framework'),
			'mode' => 'html',
			'theme' => 'chrome',
			'desc' => esc_html__('You can use these default shortcodes to send dynamic data in email sent to users.<br />[title] = Property name<br /> [url] = Property URL', 'framework'),
			'default' => "You added [title]  to your favorite.Click here to see property detail [url]"
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-search-alt',
	'title' => esc_html__('Home Search Options', 'framework'),
	'desc' => esc_html__('These are the options for Search form on homepage.', 'framework'),
	'fields' => array(
		array(
			'id' => 'search-home-blocks',
			'type' => 'sorter',
			'title' => 'Search Home Layout Manager',
			'desc' => esc_html__('Organize search fields how you want the layout to appear on the Home search form. Field at top will appear first in the form and the very bottom one will appear last.', 'framework'),
			'options' => array(
				'Enabled' => array(
					'price' => 'Price',
					'area' => 'Area',
					'property_type' => 'Property Type',
					'contract' => 'Contract',
					'location' => 'Location',
					'city' => 'City',
					'beds' => 'Beds',
					'baths' => 'Baths',
					'search_by' => 'Search By'
				),
				'Disabled' => array()
			),
		),
		array(
			'id' => 'enable_multiple_city',
			'type' => 'button_set',
			'compiler' => true,
			'title' => esc_html__('Ajax based city field', 'framework'),
			'subtitle' => esc_html__('Enable ajax based city field at home search form, field will support upto 3 child fields only.', 'framework'),
			'options' => array(
				'0' => esc_html__('Disable', 'framework'),
				'1' => esc_html__('Enable', 'framework')
			),
			'default' => '0',
		),
		array(
			'id' => 'sub_city1',
			'required' => array('enable_multiple_city', 'equals', '1'),
			'type' => 'text',
			'title' => esc_html__('Sub Area 1', 'framework'),
			'subtitle' => esc_html__('Enter label for sub area 1.', 'framework'),
			'default' => esc_html__('Sub Area', 'framework'),
		),
		array(
			'id' => 'sub_city2',
			'required' => array('enable_multiple_city', 'equals', '1'),
			'type' => 'text',
			'title' => esc_html__('Sub Area 2', 'framework'),
			'subtitle' => esc_html__('Enter label for sub area 2.', 'framework'),
			'default' => esc_html__('Sub Area', 'framework'),
		),
		array(
			'id' => 'sub_city3',
			'required' => array('enable_multiple_city', 'equals', '1'),
			'type' => 'text',
			'title' => esc_html__('Sub Area 3', 'framework'),
			'subtitle' => esc_html__('Enter label for sub area 3.', 'framework'),
			'default' => esc_html__('Sub Area', 'framework'),
		),
		array(
			'id' => 'disabled_mobile_search',
			'type' => 'button_set',
			'compiler' => true,
			'title' => esc_html__('Hide search form on mobile devices', 'framework'),
			'subtitle' => esc_html__('Choose Yes to hide the homepage search form on mobile devices.', 'framework'),
			'options' => array(
				'0' => esc_html__('No', 'framework'),
				'1' => esc_html__('Yes', 'framework')
			),
			'default' => '0',
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-search',
	'title' => esc_html__('Search Widget Options', 'framework'),
	'desc' => esc_html__('These are the options for Search Widget.', 'framework'),
	'fields' => array(
		array(
			'id' => 'search-widget-blocks',
			'type' => 'sorter',
			'title' => 'Search Widget Layout Manager',
			'desc' => esc_html__('Organize search fields how you want the layout to appear on the Search Widget', 'framework'),
			'options' => array(
				'Enabled' => array(
					'property_type' => 'Property Type',
					'contract' => 'Contract',
					'location' => 'Location',
					'city' => 'City',
					'beds' => 'Beds',
					'baths' => 'Baths',
					'price' => 'Price',
					'area' => 'Area',
					'search_by' => 'Search By'
				),
				'Disabled' => array()
			),
		)
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-home',
	'title' => esc_html__('Property Options', 'framework'),
	'desc' => esc_html__('These are the options for Property.', 'framework'),
	'fields' => array(
		array(
			'id' => 'default_agent_image',
			'type' => 'media',
			'url' => true,
			'title' => esc_html__('Default Image for Agent', 'framework'),
			'subtitle' => esc_html__('Upload default image for agent.', 'framework'),
			'default' => array('url' => $default_agent_image),
		),
		array(
			'id' => 'currency_symbol_position',
			'type' => 'switch',
			'title' => esc_html__('Currency Symbol Position', 'framework'),
			'subtitle' => esc_html__('Set currency symbol position, prefix will show the symbol before the amount and postfix will show the symbol after amount.', 'framework'),
			'default' => 1,
			'on' => esc_html__('Prefix', 'framework'),
			'off' => esc_html__('Postfix', 'framework'),
		),
		array(
			'id' => 'currency_decimal_point',
			'type' => 'select',
			'title' => esc_html__('Currency Decimals', 'framework'),
			'subtitle' => esc_html__('Choose currency decimals.', 'framework'),
			'options' => array('1' => '1', '2' => '2', '3' => '3', '4' => '4'),
			'default' => '',
		),
		array(
			'id' => 'currency_thousand_separator',
			'type' => 'select',
			'title' => esc_html__('Currency Thousand Separator', 'framework'),
			'subtitle' => esc_html__('Choose currency thousand separator.', 'framework'),
			'options' => array(',' => 'Comma', '.' => 'Decimal'),
			'default' => '',
		),
		array(
			'id' => 'currency_decimal_separator',
			'type' => 'select',
			'title' => esc_html__('Currency Decimal Separator', 'framework'),
			'subtitle' => esc_html__('Choose currency decimal separator.', 'framework'),
			'options' => array(',' => 'Comma', '.' => 'Decimal'),
			'default' => '',
		),
		array(
			'id' => 'submit_post_status',
			'type' => 'select',
			'title' => esc_html__('New Property Post Status', 'framework'),
			'subtitle' => esc_html__('Choose how you want the newly added property to be stored in your WP Dashboard.', 'framework'),
			'options' => array('draft' => 'draft', 'publish' => 'publish'),
			'default' => 'draft',
		),
		array(
			'id' => 'buyer_rights',
			'type' => 'select',
			'title' => esc_html__('Buyer Properties submission', 'framework'),
			'subtitle' => esc_html__('Choose property submission rights for buyer', 'framework'),
			'options' => array('0' => 'Disable', '1' => 'Enable'),
			'default' => '0',
		),
		array(
			'id' => 'property_id_wording',
			'type' => 'text',
			'title' => esc_html__('Property ID initial', 'framework'),
			'subtitle' => esc_html__('Enter initial wording for the dynamically generated property IDs.', 'framework'),
			'default' => esc_html__('rs-', 'framework'),
		),
		array(
			'id' => 'custom_property_id',
			'type' => 'switch',
			'title' => esc_html__('Custom Property ID', 'framework'),
			'subtitle' => esc_html__('If you set to enabled then you can change property ID while creating/editing any property.', 'framework'),
			'default' => 'off',
			'on' => esc_html__('Enabled', 'framework'),
			'off' => esc_html__('Disabled', 'framework'),
		),
		array(
			'id' => 'enable_property_id',
			'type' => 'switch',
			'title' => esc_html__('Show Property ID', 'framework'),
			'subtitle' => esc_html__('Show/Hide Property ID on property listings.', 'framework'),
			'default' => 1,
			'on' => esc_html__('Enabled', 'framework'),
			'off' => esc_html__('Disabled', 'framework'),
		),
		// Start new code for submit property                    
		array(
			'id' => 'property_details_option_enable',
			'type' => 'checkbox',
			'title' => esc_html__('Add property form fields', 'framework'),
			'subtitle' => esc_html__('Choose options for fields that will be shown on the add new property front end form.', 'framework'),
			'options' => array(
				'1' => 'Property name',
				'2' => 'Address',
				'3' => 'Area',
				'4' => 'Province',
				'5' => 'Property Pin Code',
				'6' => 'Propery Description'
			),
			'default' => array(
				'1' => '1',
				'2' => '1',
				'3' => '1',
				'4' => '1',
				'5' => '1',
				'6' => '1'
			)
		),
		array(
			'id' => 'property_details_option_required',
			'type' => 'checkbox',
			'title' => esc_html__('Add property form required fields', 'framework'),
			'subtitle' => esc_html__('Choose options that you want the users to fill in mandatorily while adding a new property using the front end listing form.', 'framework'),
			'options' => array(
				'1' => 'Property name',
				'2' => 'Address',
				'3' => 'Area',
				'4' => 'Province',
				'6' => 'Propery Description'
			),
			'default' => array(
				'1' => '1',
				'2' => '1',
				'3' => '1',
				'4' => '1',
				'6' => '1'
			)
		),
		array(
			'id' => 'additional_info_option_enable',
			'type' => 'checkbox',
			'title' => esc_html__('Additional info fields', 'framework'),
			'subtitle' => esc_html__('Choose options for fields that will be shown on the add new property front end form additional info section.', 'framework'),
			'options' => array(
				'1' => 'Price',
				'2' => 'Property Type',
				'3' => 'Contract Type',
				'4' => 'Beds',
				'5' => 'Baths',
				'6' => 'Parking'
			),
			'default' => array(
				'1' => '1',
				'2' => '1',
				'3' => '1',
				'4' => '1',
				'5' => '1',
				'6' => '1'
			)
		),
		array(
			'id' => 'additional_info_option_required',
			'type' => 'checkbox',
			'title' => esc_html__('Additional info required fields', 'framework'),
			'subtitle' => esc_html__('Choose options for additional info section that you want the users to fill in mandatorily while adding a new property using the front end listing form', 'framework'),
			'options' => array(
				'1' => 'Price',
				'2' => 'Property Type',
				'3' => 'Contract Type',
				'4' => 'Beds',
				'5' => 'Baths',
				'6' => 'Parking'
			),
			'default' => array(
				'1' => '1',
				'2' => '1',
				'3' => '1',
				'4' => '1',
				'5' => '1',
				'6' => '1'
			)
		),
		// End new code for submit property  
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-home-alt',
	'title' => esc_html__('Single Property', 'framework'),
	'fields' => array(
		array(
			'id' => 'enable_agent_details',
			'type' => 'switch',
			'title' => esc_html__('Enable Agent details', 'framework'),
			'subtitle' => __('Enable/Disable Agent details on single property page.', 'framework'),
			'default' => 1,
			'on' => esc_html__('Enabled', 'framework'),
			'off' => esc_html__('Disabled', 'framework'),
		),
		array(
			'id'        => 'property_map_zoom',
			'type'      => 'slider',
			'title'     => esc_html__('Default Map Zoom', 'framework'),
			'subtitle'  => esc_html__('Select default zoom level for map on single property page', 'framework'),
			"default"   => 4,
			"min"       => 4,
			"step"      => 1,
			"max"       => 25,
			'display_value' => 'label'
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-star',
	'title' => esc_html__('Property Amenities', 'framework'),
	'fields' => array(
		array(
			'id' => 'properties_amenities',
			'type' => 'multi_text',
			'title' => esc_html__("Enter Property amenities", "framework"),
			'default' => array(esc_html__('Air Conditioning', 'framework'), esc_html__('Heating', 'framework'), esc_html__('Balcony', 'framework'), esc_html__('Dishwasher', 'framework'), esc_html__('Pool', 'framework'), esc_html__('Internet', 'framework'), esc_html__('Terrace', 'framework'), esc_html__('Microwave', 'framework'), esc_html__('Fridge', 'framework'), esc_html__('Cable TV', 'framework'), esc_html__('Security Camera', 'framework'), esc_html__('Toaster', 'framework'), esc_html__('Grill', 'framework'), esc_html__('Oven', 'framework'), esc_html__('Fans', 'framework'), esc_html__('Servants', 'framework'), esc_html__('Furnished', 'framework'), esc_html__('Cupboards', 'framework')),
		),
		array(
			'id' => 'properties_beds',
			'type' => 'multi_text',
			'title' => esc_html__("Property Bed values", "framework"),
			'default' => 							array(esc_html__('1', 'framework'), esc_html__('2', 'framework'), esc_html__('3', 'framework'), esc_html__('4', 'framework'), esc_html__('5', 'framework'), esc_html__('6', 'framework'), esc_html__('7', 'framework'), esc_html__('8', 'framework'), esc_html__('9', 'framework'), esc_html__('10', 'framework')),
		),
		array(
			'id' => 'properties_baths',
			'type' => 'multi_text',
			'title' => esc_html__("Property Bath values", "framework"),
			'default' => array(esc_html__('1', 'framework'), esc_html__('2', 'framework'), esc_html__('3', 'framework'), esc_html__('4', 'framework'), esc_html__('5', 'framework'), esc_html__('6', 'framework'), esc_html__('7', 'framework'), esc_html__('8', 'framework'), esc_html__('9', 'framework'), esc_html__('10', 'framework')),
		),
		array(
			'id' => 'properties_parking',
			'type' => 'multi_text',
			'title' => esc_html__("Property Parking values", "framework"),
			'default' => array(esc_html__('1', 'framework'), esc_html__('2', 'framework'), esc_html__('3', 'framework'), esc_html__('4', 'framework'), esc_html__('5', 'framework')),
		),
		array(
			'id' => 'properties_price_range',
			'type' => 'multi_text',
			'title' => esc_html__("Property Price range", "framework"),
			'subtitle' => esc_html__("Enter Property's price range for search", "framework"),
			'default' => array(esc_html__('1000', 'framework'), esc_html__('5000', 'framework'), esc_html__('10000', 'framework'), esc_html__('50000', 'framework'), esc_html__('100000', 'framework'), esc_html__('3000000', 'framework'), esc_html__('5000000', 'framework'), esc_html__('10000000', 'framework')),
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-credit-card',
	'title' => esc_html__('Payment Plans', 'framework'),
	'desc' => esc_html__('These are the options for property listing payment plans.', 'framework'),
	'fields' => array(
		array(
			'id' => 'plan_show_option',
			'type' => 'switch',
			'compiler' => true,
			'title' => esc_html__('Paid Properties', 'framework'),
			'subtitle' => esc_html__('Enable or disable paid property listing option', 'framework'),
			'desc' => esc_html__('Make sure you have "Paid Property imithemes" plugin activated before you enable this option.', 'framework'),
			'default' => false,
			'on' => esc_html__('Enabled', 'framework'),
			'off' => esc_html__('Disabled', 'framework'),
		),
		array(
			'id' => 'plan_group',
			'type' => 'text_group',
			'required' => array('plan_show_option', 'equals', '1'),
			'title' => esc_html__('Payment Plans', 'framework'),
			'subtitle' => esc_html__('Add Plans for paid property listing.', 'framework'),
			'placeholder' => array(
				'title' => esc_html__('Enter Plan Name', 'framework'),
				'description' => esc_html__('Enter number of properties available to list with this plan', 'framework'),
				'url' => esc_html__("Enter plan price", 'framework'),
			),
		),
		array(
			'id' => 'free_plan_scheme',
			'type' => 'text',
			'required' => array('plan_show_option', 'equals', '1'),
			'title' => esc_html__('Free Plan Scheme', 'framework'),
			'subtitle' => esc_html__('Enter the number of times a user can register for free plan(if have any). Enter 0 for none', 'framework'),
			'default' => 1,
		),
		array(
			'id' => 'popular_plan',
			'type' => 'text',
			'required' => array('plan_show_option', 'equals', '1'),
			'title' => esc_html__('Popular plan', 'framework'),
			'subtitle' => esc_html__('Enter the name of the plan to make it popular plan in the pricing table.', 'framework'),
			'desc' => esc_html__('Copy/Paste the plan name from your plan blocks above.', 'framework'),
		),
		array(
			'id' => 'popular_plan_text',
			'type' => 'text',
			'required' => array('plan_show_option', 'equals', '1'),
			'title' => esc_html__('Popular plan text', 'framework'),
			'subtitle' => esc_html__('Enter text that should be shown on the popular plan block.', 'framework'),
			'default' => 'Popular',
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-map-marker',
	'title' => esc_html__('Map API', 'framework'),
	'fields' => array(
		array(
			'id'       => 'google_map_api',
			'type'     => 'text',
			'title'    => esc_html__('Google Maps API Key', 'framework'),
			'desc'     => __('Enter your Google Maps API key in here. This will be used for all maps in the theme i.e. Map banner, Property maps. <a href="https://support.imithemes.com/knowledgebase/get-google-maps-api/" target="_blank">See Guide about how to get your API Key</a>', 'framework'),
		),
	)
));
Redux::setSection($opt_name, array(
	'icon' => 'el-icon-css',
	'title' => esc_html__('Custom CSS/JS', 'framework'),
	'fields' => array(
		array(
			'id' => 'custom_css',
			'type' => 'ace_editor',
			'title' => esc_html__('CSS Code', 'framework'),
			'subtitle' => esc_html__('Paste your CSS code here.', 'framework'),
			'mode' => 'css',
			'theme' => 'monokai',
			'desc' => '',
			'default' => ""
		),
		array(
			'id' => 'custom_js',
			'type' => 'ace_editor',
			'title' => esc_html__('JS Code', 'framework'),
			'subtitle' => esc_html__('Paste your JS code here.', 'framework'),
			'mode' => 'javascript',
			'theme' => 'chrome',
			'desc' => '',
			'default' => ""
		)
	),
));

/*
 * <--- END SECTIONS
 */
