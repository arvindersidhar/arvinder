<?php
/* * ** Meta Box Functions **** */
$prefix = 'imic_';
global $meta_boxes;
$imic_options = get_option('imic_options');
$gmap_api_key = (isset($imic_options['google_map_api']))?$imic_options['google_map_api']:'';
$meta_boxes = array();
/* Post/Page Title and Banner Meta Box
=========================================== */
$meta_boxes[] = array(
    'id' => 'post_page_meta_box',
    'title' => esc_html__('Page/Post Header Options', 'framework'),
    'pages' => array('post','page'),
	'hide' => array(
		'relation' => 'OR',
		'template' => array( 'template-home.php','template-home-second.php' ),
	),
    'fields' => array(
		array(
            'name' => esc_html__('Page Header Show/Hide', 'framework'),
            'id' => $prefix . 'page_header_show_hide',
            'type' => 'select',
            'options' => array(
                1 => esc_html__('Show', 'framework'),
                2 => esc_html__('Hide', 'framework'),
            ),
            'std' => 1,
        ),
		array(
            'name' => esc_html__('Page Header Title Show/Hide', 'framework'),
            'id' => $prefix . 'pages_title_show',
            'type' => 'select',
            'options' => array(
                1 => esc_html__('Show', 'framework'),
                2 => esc_html__('Hide', 'framework'),
            ),
            'std' => 1,
			'visible' => array('imic_page_header_show_hide','=','1')
        ),
        // Custom title
        array(
            'name' => esc_html__('Custom Title', 'framework'),
            'id' => $prefix . 'post_page_custom_title',
            'desc' => esc_html__("Enter Custom Title.", 'framework'),
            'type' => 'text',
			'visible' => array('imic_page_header_show_hide','=','1')
        ),
		//Map Display
        array(
            'name' => esc_html__('Banner Type', 'framework'),
            'id' => $prefix . 'banner_type',
            'desc' => esc_html__("Select banner type to display on page.", 'framework'),
            'type' => 'select',
            'options' => array(
                'no' => esc_html__('Default', 'framework'),
                'banner' => esc_html__('Image Banner', 'framework'),
                'map' => esc_html__('Map', 'framework'),
            ),
			'visible' => array('imic_page_header_show_hide','=','1')
        ),
        array(
            'name' => esc_html__('Banner Image', 'framework'),
            'id' => $prefix . 'banner_image',
            'desc' => esc_html__("Upload banner image for this Page/Post.", 'framework'),
            'type' => 'image_advanced',
            'max_file_uploads' => 1,
			'visible' => array('imic_banner_type','=','banner')
        ),
	)
);
/* Post Page Background Meta Box
  ================================================== */
$meta_boxes[] = array(
    'id' => 'post_page_bg_meta_box',
    'title' => esc_html__('Background Options', 'framework'),
   	'pages' => array('post', 'page', 'property'),
    'fields' => array(
		array(
            'name' => esc_html__('Below options work only in Boxed Layout', 'framework'),
            'id' => $prefix . 'boxed_option_heading',
            'type' => 'heading',
		),
		array(
            'name' => esc_html__('Background Color', 'framework'),
            'id' => $prefix . 'pages_body_bg_color',
            'desc' => esc_html__("Choose background color for the outer area", 'framework'),
            'type' => 'color',
        ),
		array(
            'name' => esc_html__('Background Image', 'framework'),
            'id' => $prefix . 'pages_body_bg_image',
            'desc' => esc_html__("Choose background image for the outer area", 'framework'),
            'type' => 'image_advanced',
            'max_file_uploads' => 1
        ),
		array(
            'name' => esc_html__('100% Background Image', 'framework'),
            'id' => $prefix . 'pages_body_bg_wide',
            'desc' => esc_html__("Choose to have the background image display at 100%.", 'framework'),
            'type' => 'select',
            'options' => array(
                '1' => esc_html__('Yes', 'framework'),
                '0' => esc_html__('No', 'framework'),
            ),
            'std' => 0,
        ),
		array(
            'name' => esc_html__('Background Repeat', 'framework'),
            'id' => $prefix . 'pages_body_bg_repeat',
            'desc' => esc_html__("Select how the background image repeats.", 'framework'),
            'type' => 'select',
            'options' => array(
                'repeat' => esc_html__('Repeat', 'framework'),
                'repeat-x' => esc_html__('Repeat Horizontally', 'framework'),
                'repeat-y' => esc_html__('Repeat Vertically', 'framework'),
                'no-repeat' => esc_html__('No Repeat', 'framework'),
            ),
            'std' => 'repeat',
        ),
		array(
            'id' => $prefix . 'wide_option_divider',
            'type' => 'divider',
		),
		array(
            'name' => esc_html__('Below options work in boxed and wide mode:', 'framework'),
            'id' => $prefix . 'wide_option_heading',
            'type' => 'heading',
		),
		array(
            'name' => esc_html__('Background Color', 'framework'),
            'id' => $prefix . 'pages_content_bg_color',
            'desc' => esc_html__("Choose background color for the Content area", 'framework'),
            'type' => 'color',
        ),
		array(
            'name' => esc_html__('Background Image', 'framework'),
            'id' => $prefix . 'pages_content_bg_image',
            'desc' => esc_html__("Choose background image for the Content area", 'framework'),
            'type' => 'image_advanced',
            'max_file_uploads' => 1
        ),
		array(
            'name' => esc_html__('100% Background Image', 'framework'),
            'id' => $prefix . 'pages_content_bg_wide',
            'desc' => esc_html__("Choose to have the background image display at 100%.", 'framework'),
            'type' => 'select',
            'options' => array(
                '1' => esc_html__('Yes', 'framework'),
                '0' => esc_html__('No', 'framework'),
            ),
            'std' => 0,
        ),
		array(
            'name' => esc_html__('Background Repeat', 'framework'),
            'id' => $prefix . 'pages_content_bg_repeat',
            'desc' => esc_html__("Select how the background image repeats.", 'framework'),
            'type' => 'select',
            'options' => array(
                'repeat' => esc_html__('Repeat', 'framework'),
                'repeat-x' => esc_html__('Repeat Horizontally', 'framework'),
                'repeat-y' => esc_html__('Repeat Vertically', 'framework'),
                'no-repeat' => esc_html__('No Repeat', 'framework'),
            ),
            'std' => 'repeat',
        ),
	)
);
/* Post Page Social Meta Box
  ================================================== */
$meta_boxes[] = array(
    'id' => 'post_page_design_meta_box',
    'title' => esc_html__('Page Design Options', 'framework'),
   	'pages' => array('post', 'page', 'property'),
    'fields' => array(
		array(
            'name' => esc_html__('Content Width', 'framework'),
            'desc' => esc_html__("Enter width of content in px or %", 'framework'),
            'id' => $prefix . 'content_width',
            'type' => 'text',
		),
		array(
            'name' => esc_html__('Content Padding Top', 'framework'),
            'desc' => esc_html__("Do not include px or % here", 'framework'),
            'id' => $prefix . 'content_padding_top',
            'type' => 'number',
		),
		array(
            'name' => esc_html__('Content Padding Bottom', 'framework'),
            'desc' => esc_html__("Do not include px or % here", 'framework'),
            'id' => $prefix . 'content_padding_bottom',
            'type' => 'number',
		),
		array(
            'name' => esc_html__('Show social sharing buttons', 'framework'),
            'id' => $prefix . 'pages_social_show',
            'type' => 'select',
            'options' => array(
                '1' => esc_html__('Show', 'framework'),
                '2' => esc_html__('Hide', 'framework'),
            ),
            'std' => '1',
        ),
	)
);
/* Home Page Slider Options (Home Meta Box 2)
=============================================================*/
$meta_boxes[] = array(
    'id' => 'template-home2',
    'title' => esc_html__('Home Page Slider Options', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-home.php','template-home-second.php' ),
	),
    'show_names' => true,
    'fields' => array(
		array(
            'name' => esc_html__('Page Header Show/Hide', 'framework'),
            'id' => $prefix . 'page_header_show_hide1',
            'type' => 'select',
            'options' => array(
                1 => esc_html__('Show', 'framework'),
                2 => esc_html__('Hide', 'framework'),
            ),
            'std' => 1,
        ),
		//Slider auto slide
        array(
            'name' => esc_html__('Choose Slider', 'framework'),
            'id' => $prefix . 'slider_with_property',
            'desc' => esc_html__("Select Slider Display.", 'framework'),
            'type' => 'select',
            'options' => array(
                '0' => esc_html__('Slider With Property', 'framework'),
                '1' => esc_html__('Slider Without Property', 'framework'),
                '2' => esc_html__('Revolution Slider', 'framework'),
            ),
			'visible' => array('imic_page_header_show_hide1','=','1')
        ),
        //Slider Image
        array(
            'name' => esc_html__('Slider Images', 'framework'),
            'id' => $prefix . 'slider_image',
            'desc' => esc_html__("Select/Upload slider images.", 'framework'),
            'type' => 'image_advanced',
			'visible' => array('imic_slider_with_property','=','1')
        ),
        array(
            'name' => esc_html__('Slider Autoplay', 'framework'),
            'id' => $prefix . 'slider_auto_slide',
            'desc' => esc_html__("Select Yes to slide automatically.", 'framework'),
            'type' => 'select',
            'options' => array(
                'yes' => esc_html__('Yes', 'framework'),
                'no' => esc_html__('No', 'framework'),
            ),
			'visible' => array('imic_slider_with_property','=','1')
        ),
		//Slider arrows
		array(
            'name' => esc_html__('Slider Direction Arrows', 'framework'),
            'id' => $prefix . 'slider_direction_arrows',
            'desc' => esc_html__("Select Yes to show slider direction arrows.", 'framework'),
            'type' => 'select',
            'options' => array(
                'yes' => esc_html__('Yes', 'framework'),
                'no' => esc_html__('No', 'framework'),
            ),
			'visible' => array('imic_slider_with_property','=','1')
        ),
		//Slider effects
		array(
            'name' => esc_html__('Slider Effects', 'framework'),
            'id' => $prefix . 'slider_effects',
            'desc' => esc_html__("Select effects for slider.", 'framework'),
            'type' => 'select',
            'options' => array(
                'fade' => esc_html__('Fade', 'framework'),
                'slide' => esc_html__('Slide', 'framework'),
            ),
			'visible' => array('imic_slider_with_property','=','1')
        ),
        array(
		   	'name' => esc_html__('Select Revolution Slider from list','framework'),
			'id' => $prefix . 'pages_select_revolution_from_list',
			'desc' => esc_html__("Select Revolution Slider from the list", 'framework'),
			'type' => 'select',
			'options' => imicRevSliderShortCode(),
			'visible' => array('imic_slider_with_property','=','2')
        ),
));
/* Home Page Recent Listed Section Options (Home Meta Box 3)
=============================================================*/
$meta_boxes[] = array(
    'id' => 'template-home3',
    'title' => esc_html__('Recent Properties', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-home.php','template-home-second.php' ),
	),
    'show_names' => true,
    'fields' => array(
		//Enable/Disable Recent Listed Section
		array(
            'name' => esc_html__('Recent Listed Section', 'framework'),
            'id' => $prefix . 'home_recent_section',
            'desc' => esc_html__('Enable/Disable Recent Listed Section on Home Page.', 'framework'),
            'type' => 'select',
            'options' => array(
                '1' => esc_html__('Enable', 'framework'),
                '0' => esc_html__('Disable', 'framework'),
            ),
			'std' => 1,
        ),
		//Recent Listed Section Heading
        array(
            'name' => esc_html__('Recent Listed Section Heading', 'framework'),
            'id' => $prefix . 'home_recent_heading',
            'desc' => esc_html__("Enter Recent Listed Section Heading text to show on Home page", 'framework'),
            'type' => 'text',
            'std' => 'Recent Listed',
			'visible' => array('imic_home_recent_section','=','1')
        ),
		//Recent Listed Section more link
        array(
            'name' => esc_html__('View more properties URL', 'framework'),
            'id' => $prefix . 'home_recent_more',
            'desc' => esc_html__("Enter Recent Listed Section's view more properties URL to redirect link", 'framework'),
            'type' => 'url',
			'visible' => array('imic_home_recent_section','=','1')
        ),
		//Number of Recent Listed Property
        array(
            'name' => esc_html__('Number of Properties', 'framework'),
            'id' => $prefix . 'home_recent_property_no',
            'desc' => esc_html__("Enter number of Recent Listed property to show on Home page", 'framework'),
            'type' => 'number',
            'std' => 3,
			'visible' => array('imic_home_recent_section','=','1')
        ),
));
/* Home Page Featured Properties Section Options (Home Meta Box 4)
=============================================================*/
$meta_boxes[] = array(
    'id' => 'template-home4',
    'title' => esc_html__('Featured Properties', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-home.php','template-home-second.php' ),
	),
    'show_names' => true,
    'fields' => array(
		//Enable/Disable Featured properties Section
		array(
            'name' => esc_html__('Featured properties Section', 'framework'),
            'id' => $prefix . 'home_featured_section',
            'desc' => esc_html__('Enable/Disable Featured Properties Section on Home Page.', 'framework'),
            'type' => 'select',
            'options' => array(
                '1' => esc_html__('Enable', 'framework'),
                '0' => esc_html__('Disable', 'framework'),
            ),
			'std' => 1,
        ),
		//Featured Section Heading
        array(
            'name' => esc_html__('Featured Section Heading', 'framework'),
            'id' => $prefix . 'home_featured_heading',
            'desc' => esc_html__("Enter Featured Properties Section Heading text to show on Home page", 'framework'),
            'type' => 'text',
            'std' => 'Featured Properties',
			'visible' => array('imic_home_featured_section','=','1')
        ),
));
/* Partners Meta Box
======================= */
$meta_boxes[] = array(
    'id' => 'partners_meta_box',
    'title' => esc_html__('Partners Meta Box', 'framework'),
    'pages' => array('partner'),
    'fields' => array(
        
        array(
            'name' => esc_html__('Display on Home page', 'framework'),
            'id' => $prefix . 'partner_home',
            'desc' => esc_html__("Check for display on site index(home) page.", 'framework'),
            'type' => 'checkbox',
			'std'  => 1,
        ),
		//Partner Image
		array(
            'name' => esc_html__('Partner Logo', 'framework'),
            'id' => $prefix . 'partner_logo',
            'desc' => esc_html__("Upload Partner's Logo.", 'framework'),
            'type' => 'image_advanced',
            'max_file_uploads' => 1
        ),
		//Partner URL
		array(
            'name' => esc_html__('URL', 'framework'),
            'id' => $prefix . 'partner_url',
            'desc' => esc_html__("Enter partner logo url.", 'framework'),
            'type' => 'text',
        ),
		array(
            'name' => esc_html__('Target Blank', 'framework'),
            'id' => $prefix . 'partner_target',
            'desc' => esc_html__("Open partner link target to blank page.", 'framework'),
            'type' => 'checkbox',
			'std'  => 1,
        ),
     )
);
/* Home Page Partner Meta Box (Home Meta Box 6)
=============================================================*/
$meta_boxes[] = array(
    'id' => 'template-home6',
    'title' => esc_html__('Partner Section', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-home.php','template-home-second.php' ),
	),
    'show_names' => true,
    'fields' => array(
		array(
            'name' => esc_html__('Partners', 'framework'),
            'id' => $prefix . 'home_partners_section',
            'desc' => esc_html__('Enable/Disable Partners Section on Home Page.', 'framework'),
            'type' => 'select',
            'options' => array(
                '1' => esc_html__('Enable', 'framework'),
                '0' => esc_html__('Disable', 'framework'),
            ),
			'std' => 1,
        ),
		//Partner Title
		 array(
            'name' => esc_html__('Partner Heading', 'framework'),
            'id' => $prefix . 'home_partner_heading',
            'desc' => esc_html__("Enter heading for partner section.", 'framework'),
            'type' => 'text',
            'std' => '',
			'visible' => array('imic_home_partners_section','=','1')
        ),
		//All Partner URL
        array(
            'name' => esc_html__('All Partner URL', 'framework'),
            'id' => $prefix . 'home_partner_url',
            'desc' => esc_html__("Enter URL for all partner.", 'framework'),
            'type' => 'text',
            'std' => '',
			'visible' => array('imic_home_partners_section','=','1')
        ),
));
/* Property Page Layout (Home Meta Box 1)
=============================================================*/
$meta_boxes[] = array(
    'id' => 'template-property-listing1',
    'title' => esc_html__('Properties Listing Layout', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-property-listing.php' ),
	),
    'show_names' => true,
    'fields' => array(
		//Design Layout
        array(
            'name' => esc_html__('Design Layout', 'framework'),
            'id' => $prefix . 'property_design_layout',
            'desc' => esc_html__("Select design layout to change property page design.", 'framework'),
            'type' => 'select',
            'options' => array(
                'listing' => esc_html__('Listing', 'framework'),
                'grid' => esc_html__('Grid', 'framework'),
            ),
			'std' => 'listing',
        ),
		array(
            'name' => esc_html__('Listing Layout URL', 'framework'),
            'id' => $prefix . 'property_listing_url',
            'desc' => esc_html__("Enter Recent Listed Section Heading text to show on Home page", 'framework'),
            'type' => 'text',
        ),
		array(
            'name' => esc_html__('Grid Layout URL', 'framework'),
            'id' => $prefix . 'property_grid_url',
            'desc' => esc_html__("Enter Recent Listed Section Heading text to show on Home page", 'framework'),
            'type' => 'text',
        ),
));
/* Register Agent Page Layout Options (Register Agent Meta Box 1)
========================================================= */
$meta_boxes[] = array(
    'id' => 'template-register1',
    'title' => esc_html__('Login/Register Page Layout Options', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-register.php' ),
	),
    'show_names' => true,
    'fields' => array(
		//Layout options
		array(
            'name' => esc_html__('Page Layout', 'framework'),
            'id' => $prefix . 'register_layout',
            'desc' => esc_html__("Select login/register page layout as per requirement.", 'framework'),
            'type' => 'select',
            'options' => array(
                '1' => esc_html__('Text + Login + Register', 'framework'),
                '2' => esc_html__('Text + Login', 'framework'),
                '3' => esc_html__('Text + Register', 'framework'),
            ),
        ),       
    )
);
/* Redirect after Registration Agent Page  Options (Register Agent Meta Box 2)
========================================================= */
$meta_boxes[] = array(
    'id' => 'template-register2',
    'title' => esc_html__('Login/Register Redirect Options', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-register.php' ),
	),
    'show_names' => true,
    'fields' => array(
		//Layout options
            array(
            'name' => esc_html__('Login Redirect', 'framework'),
            'id' => $prefix . 'login_redirect_options',
            'desc' => esc_html__("Enter URL to which user will be redirected after successful login.", 'framework'),
            'type' => 'url',
            ), 
          array(
            'name' => esc_html__('Register Redirect Option', 'framework'),
            'id' => $prefix . 'register_redirect_options',
            'desc' => esc_html__("Enter URL to which user will be redirected once registered.", 'framework'),
            'type' => 'url',
            ), 
    )
);
/* Contact Page Form Details (Contact Meta Box 1)
========================================================= */
$meta_boxes[] = array(
    'id' => 'template-contact1',
    'title' => esc_html__('Contact Form Meta Box', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-contact.php' ),
	),
    'show_names' => true,
    'fields' => array(
		//Email
        array(
            'name' => esc_html__('Email Us', 'framework'),
            'id' => $prefix . 'contact_email_us',
            'desc' => esc_html__("Enter email address where you want the email to be sent on form submission.", 'framework'),
            'type' => 'text',
            'std' => get_option('admin_email')
        ),
        //Subject
        array(
            'name' => esc_html__('Subject', 'framework'),
            'id' => $prefix . 'contact_subject',
            'desc' => esc_html__("Enter subject to use in contact form.", 'framework'),
            'type' => 'text',
        ),
        //Contact Form Shortcode
        array(
            'name' => esc_html__('Form Shortcode', 'framework'),
            'id' => $prefix . 'form_shortcode',
            'desc' => esc_html__("Enter shortcode for the form if using any plugin generated form like Contact Form 7. If this field is used then the above subject and email field will not be used.", 'framework'),
            'type' => 'text',
        ),
    )
);
/* Contact Page Details (Contact Meta Box 2)
========================================================= */
$meta_boxes[] = array(
    'id' => 'template-contact2',
    'title' => esc_html__('Contact Map Meta Box', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-contact.php' ),
	),
    'show_names' => true,
    'fields' => array(
        //Our Location Text
        array(
            'name' => esc_html__('Our Location Address', 'framework'),
            'id' => $prefix . 'our_location_address',
            'desc' => esc_html__("Enter the Our Location Address to display on contact page.", 'framework'),
            'type' => 'text',
			'std' => '',
        ),
        array(
             'id' => $prefix . 'contact_lat_long',
			'name' => esc_html__( 'Location', 'framework' ),
			'type' => 'map',
			'api_key' => $gmap_api_key,
			'std' => '-6.233406,-35.049906,15', // 'latitude,longitude[,zoom]' (zoom is optional)
			'style' => 'width: 500px; height: 400px',
			'address_field' => 'imic_our_location_address', // Name of text field where address is entered. Can be list of text fields, separated by commas (for ex. city, state)
		),
         // Contact Zoom
       	array(
            'name' => esc_html__('Map zoom level', 'framework'),
            'id' => $prefix . 'contact_zoom_option',
            'desc' => esc_html__('Enter the zoom level for contact page map', 'framework'),
            'type' => 'text',
      	),
	)
);
/* Our Agent Page Become an Agent Details (Our Agent Meta Box 1)
========================================================= */
$meta_boxes[] = array(
    'id' => 'template-our-agents1',
    'title' => esc_html__('Become an Agent Options', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-our-agents.php' ),
	),
    'show_names' => true,
    'fields' => array(
        //Button Text
        array(
            'name' => esc_html__('Become an Agent Button Text', 'framework'),
            'id' => $prefix . 'agent_become_agent_text',
            'desc' => esc_html__("Enter Become an Agent text to display on button.", 'framework'),
            'type' => 'text',
            'std' => 'Become an agent',
        ),
        //Button Link
        array(
            'name' => esc_html__('Become an Agent Button URL', 'framework'),
            'id' => $prefix . 'agent_become_agent_url',
            'desc' => esc_html__("Enter Become an Agent URL to redirect.", 'framework'),
            'type' => 'url',
        ),
    )
);
/* Property Submit Template
========================================================= */
$meta_boxes[] = array(
    'id' => 'template-blog1',
    'title' => esc_html__('Blog Type', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-blog.php' ),
	),
    'show_names' => true,
    'fields' => array(
        //PROPERTY STATUS
        array(
            'name' => esc_html__('Blog Type', 'framework'),
            'id' => $prefix . 'blog_type',
            'desc' => esc_html__("Select layout style for blog.", 'framework'),
            'type' => 'select',
            'options' => array(
                'masonry' => esc_html__('Masonry Grid', 'framework'),
                'timeline' => esc_html__('Timeline', 'framework'),
            ),
			'std' => 'masonry',
        ),
    )
);
/* Property Submit Template
========================================================= */
$meta_boxes[] = array(
    'id' => 'template-submit-property1',
    'title' => esc_html__('Property Status', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-submit-property.php' ),
	),
    'show_names' => true,
    'fields' => array(
        //PROPERTY STATUS
        array(
            'name' => esc_html__('Property Status', 'framework'),
            'id' => $prefix . 'property_status',
            'desc' => esc_html__("Select Status for Property.", 'framework'),
            'type' => 'select',
            'options' => array(
                'draft' => esc_html__('Pending Review', 'framework'),
                'publish' => esc_html__('Publish', 'framework'),
            ),
			'std' => 'draft',
        ),
    )
);
/* Slide Meta Box
  ================================================== */
$meta_boxes[] = array(
    'id' => 'slide_meta_box',
    'title' => esc_html__('Properties', 'framework'),
    'pages' => array('slide'),
    'fields' => array(
		array(
			'name' => esc_html__( 'Property list', 'framework' ),
			'id' => $prefix . "property_listing",
			'type' => 'post',
			'post_type' => 'property',
			'field_type' => 'select_advanced',
			'query_args' => array(
				'post_status' => 'publish',
				'posts_per_page' => '-1',
			)
		),
    )
);
$meta_boxes[] = array(
    'id' => 'property_banner_meta_box',
    'title' => esc_html__('Page Header', 'framework'),
    'pages' => array('property'),
    'fields' => array(
		array(
            'name' => esc_html__('Page Header Show/Hide', 'framework'),
            'id' => $prefix . 'page_header_show_hide2',
            'type' => 'select',
            'options' => array(
                1 => esc_html__('Show', 'framework'),
                2 => esc_html__('Hide', 'framework'),
            ),
            'std' => 1,
        ),
        array(
            'name' => esc_html__('Page Header Type', 'framework'),
            'id' => $prefix . 'property_banner_type',
            'desc' => esc_html__('Select page header type for the property.', 'framework'),
            'type' => 'select',
            'options' => array(
                'featured_image' => esc_html__('Featured Image', 'framework'),
                'map' => esc_html__('Map', 'framework'),
                'default_image' => esc_html__('Default Image', 'framework'),
            ),
			'visible' => array('imic_page_header_show_hide2','=','1')
        ),
      )
);
/* Property Meta Box
  ================================================== */
$meta_boxes[] = array(
    'id' => 'slide_meta_box',
    'title' => esc_html__('Property Details', 'framework'),
    'pages' => array('property'),
    'fields' => array(
		array(
			'name' => esc_html__('Property ID', 'framework'),
			'id' => $prefix . 'property_site_id',
			'desc' => esc_html__("This field will automatically fill, do not edit until required.", 'framework'),
			'clone' => false,
			'type' => 'text',
			'std' => '',
			),
		array(
            'name' => esc_html__('Property Address', 'framework'),
            'id' => $prefix . 'property_site_address',
            'desc' => esc_html__("Enter the Property Address.", 'framework'),
            'clone' => false,
            'type' => 'text',
            'std' => '',
        ),
		array(
			'id' => $prefix . 'lat_long',
			'name' => esc_html__( 'Location', 'framework' ),
			'type' => 'map',
			'api_key' => $gmap_api_key,
			'std' => '-6.233406,-35.049906,15', // 'latitude,longitude[,zoom]' (zoom is optional)
			'style' => 'width: 500px; height: 400px',
			'address_field' => 'imic_property_site_address', // Name of text field where address is entered. Can be list of text fields, separated by commas (for ex. city, state)
			),
        // Property Zoom
            array(
            'name' => esc_html__('Map Zoom Level', 'framework'),
            'id' => $prefix . 'property_zoom_option',
            'desc' => esc_html__('Enter the zoom level for property map', 'framework'),
            'type' => 'text',
            ),
		array(
            'name' => esc_html__('Province', 'framework'),
            'id' => $prefix . 'property_site_city',
            'desc' => esc_html__('Select State/City for property.', 'framework'),
            'type' => 'select',
            'options' => imic_get_multiple_city()
            ),
        array(
            'name' => esc_html__('Property Value', 'framework'),
            'id' => $prefix . 'property_price',
            'desc' => esc_html__("Enter the Property Value.", 'framework'),
            'clone' => false,
            'type' => 'text',
            'std' => '',
        ),
        // AREA
        array(
            'name' => esc_html__('Property Area', 'framework'),
            'id' => $prefix . 'property_area',
            'desc' => esc_html__("Enter the Property Area.", 'framework'),
            'clone' => false,
            'type' => 'text',
            'std' => '',
        ),
        // BATHS
        array(
            'name' => esc_html__('Baths', 'framework'),
            'id' => $prefix . 'property_baths',
            'desc' => esc_html__("Enter the Number of Baths.", 'framework'),
            'type' => 'text',
            'std' => '',
        ),
        // BEDS
        array(
            'name' => esc_html__('Beds', 'framework'),
            'id' => $prefix . 'property_beds',
            'desc' => esc_html__("Enter the Number of Bedrooms.", 'framework'),
            'type' => 'text',
            'std' => '',
        ),
      // PARKING
         array(
            'name' => esc_html__('Parking', 'framework'),
            'id' => $prefix . 'property_parking',
            'desc' => esc_html__("Enter the Number of Parkings.", 'framework'),
            'type' => 'text',
            'std' => '',
        ),
		// IMAGES
		array(
            'name' => esc_html__('Property Sights', 'framework'),
            'id' => $prefix . 'property_sights',
            'desc' => esc_html__("Upload Property sights.", 'framework'),
            'type' => 'image_advanced',
            'max_file_uploads' => 30
        ),
		// AMENITIES
         array(
            'name' => esc_html__('Amenities', 'framework'),
            'id' => $prefix . 'property_amenities',
            'desc' => esc_html__("Enter the Amenities of Parkings.", 'framework'),
            'type' => 'text',
			'clone' => true,
            'std' => '',
        ),
		// FEATURED
		array(
            'name' => esc_html__('Featured Property', 'framework'),
            'id' => $prefix . 'featured_property',
            'desc' => esc_html__('Select Yes to make this property featured.', 'framework'),
            'type' => 'select',
            'options' => array(
                '0' => esc_html__('No', 'framework'),
                '1' => esc_html__('Yes', 'framework'),
            ),
			'std' => 0,
        ),
		// Property Under Slider
		array(
            'name' => esc_html__('Property Slide', 'framework'),
            'id' => $prefix . 'slide_property',
            'desc' => esc_html__('Select Yes to display this property in homepage slider.', 'framework'),
            'type' => 'select',
            'options' => array(
                '0' => esc_html__('No', 'framework'),
                '1' => esc_html__('Yes', 'framework'),
            ),
			'std' => 0,
        ),
        // Property Pincode
            array(
            'name' => esc_html__('Property Pincode', 'framework'),
            'id' => $prefix . 'property_pincode',
            'desc' => esc_html__('Enter the Pincode of Property', 'framework'),
            'type' => 'text',
            ),
        // Property Custom City
            array(
            'name' => esc_html__('Property Custom City', 'framework'),
            'id' => $prefix . 'property_custom_city',
            'desc' => esc_html__('Do not Delete this field', 'framework'),
            'type' => 'hidden',
            ),
         // Property Email Status
          array(
            'name' => esc_html__('Property Email Status', 'framework'),
            'id' => $prefix . 'property_email_status',
            'desc' => esc_html__('Do not Delete this field', 'framework'),
            'type' => 'hidden',
            ),
      )
);
/* Testimonial Meta Box
===================================================*/
$meta_boxes[] = array(
    'id' => 'testimonial_meta_box',
    'title' => esc_html__('Testimonial  Meta Box', 'framework'),
    'pages' => array('testimonials'),
    'fields' => array(
	//Company Name
		array(
            'name' => esc_html__('Company Name', 'framework'),
            'id' => $prefix . 'client_company',
            'desc' => esc_html__("Enter the Company for Client.", 'framework'),
            'type' => 'text',
			'clone' => false,
            'std' => '',
        ),
		 array(
            'name' => esc_html__('Client URL', 'framework'),
            'id' => $prefix . 'client_co_url',
            'desc' => esc_html__("Enter the client website URL.", 'framework'),
            'type' => 'url',
        ),
		));
/* * ** Gallery  Pagination Meta Box 1 *** */
$meta_boxes[] = array(
    'id' => 'template-gallery1',
    'title' => esc_html__('Gallery Layout', 'framework'),
    'pages' => array('page'),
	'show' => array(
		'relation' => 'OR',
		'template' => array( 'template-gallery.php' ),
	),
    'show_names' => true,
    'fields' => array(
		// Gallery Images
        array(
            'name' => esc_html__('Images', 'framework'),
            'id' => $prefix . 'gallery_images',
            'desc' => esc_html__("Select/Upload Gallery Images.", 'framework'),
            'type' => 'image_advanced',
        ),
		array(
            'name' => esc_html__('Layout', 'framework'),
            'id' => $prefix . 'gallery_type',
            'desc' => esc_html__('Select gallery type.', 'framework'),
            'type' => 'select',
            'options' => array(
                '0' => esc_html__('Grid', 'framework'),
                '1' => esc_html__('Masonry', 'framework'),
            ),
			'std' => 0,
        ),
        //Number of Gallery to show
        array(
            'name' => esc_html__('Number of items to show', 'framework'),
            'id' => $prefix . 'gallery_pagination_to_show_on',
            'desc' => esc_html__("Enter number of images to show on a page.", 'framework'),
            'type' => 'text',
            'std' => ''
        ),
         array(
            'name' => esc_html__('Columns', 'framework'),
            'id' => $prefix . 'gallery_pagination_columns_layout',
            'desc' => esc_html__("Choose columns layout.", 'framework'),
            'type' => 'select',
            'options' => array(
                '2' => esc_html__('2 Columns', 'framework'),
                '3' => esc_html__('3 Columns', 'framework'),
				'4' => esc_html__('4 Columns', 'framework'),
            ),
			'std' => '3',
        ),
    )
);
/* Gallery Meta Box
  ================================================== */
$meta_boxes[] = array(
    'id' => 'gallery_meta_box',
    'title' => esc_html__('Post Media', 'framework'),
    'pages' => array('post'),
    'fields' => array(
        // Gallery Link Url
        array(
            'name' => esc_html__('Link Format URL', 'framework'),
            'id' => $prefix . 'gallery_link_url',
            'desc' => esc_html__("Enter the Link URL.", 'framework'),
            'type' => 'url',
			'visible' => array('post_format','link')
        ),
        // Gallery Images
        array(
            'name' => esc_html__('Gallery Images', 'framework'),
            'id' => $prefix . 'gallery_images',
            'desc' => esc_html__("Select/Upload Gallery Images.", 'framework'),
            'type' => 'image_advanced',
			'visible' => array('post_format','gallery')
        ),
       array(
            'name' => esc_html__('Slider Pagination', 'framework'),
            'id' => $prefix . 'gallery_slider_pagination',
            'desc' => esc_html__("Enable to show pagination for slider.", 'framework'),
            'type' => 'select',
            'options' => array(
                'yes' => esc_html__('Enable', 'framework'),
                'no' => esc_html__('Disable', 'framework'),
            ),
			'visible' => array('post_format','gallery')
        ),
		array(
            'name' => esc_html__('Slider Autoplay', 'framework'),
            'id' => $prefix . 'gallery_slider_auto_slide',
            'desc' => esc_html__("Select Yes to slide automatically.", 'framework'),
            'type' => 'select',
            'options' => array(
                'yes' => esc_html__('Yes', 'framework'),
                'no' => esc_html__('No', 'framework'),
            ),
			'visible' => array('post_format','gallery')
        ),
		array(
            'name' => esc_html__('Slider Direction Arrows', 'framework'),
            'id' => $prefix . 'gallery_slider_direction_arrows',
            'desc' => esc_html__("Select Yes to show slider direction arrows.", 'framework'),
            'type' => 'select',
            'options' => array(
                'yes' => esc_html__('Yes', 'framework'),
                'no' => esc_html__('No', 'framework'),
            ),
			'visible' => array('post_format','gallery')
        ),
		array(
            'name' => esc_html__('Slider Effects', 'framework'),
            'id' => $prefix . 'gallery_slider_effects',
            'desc' => esc_html__("Select effects for slider.", 'framework'),
            'type' => 'select',
            'options' => array(
                'fade' => esc_html__('Fade', 'framework'),
                'slide' => esc_html__('Slide', 'framework'),
            ),
			'visible' => array('post_format','gallery')
        ),
    )
);
/* * ******************* META BOX REGISTERING ********************** */
/**
 * Register meta boxes
 *
 * @return void
 */
function imic_register_meta_boxes() {
    global $meta_boxes;
    // Make sure there's no errors when the plugin is deactivated or during upgrade
    if (class_exists('RW_Meta_Box')) {
        foreach ($meta_boxes as $meta_box) {
            new RW_Meta_Box($meta_box);
        }
    }
}
// Hook to 'admin_init' to make sure the meta box class is loaded before
// (in case using the meta box class in another plugin)
// This is also helpful for some conditionals like checking Page template, categories, etc.
add_action('admin_init', 'imic_register_meta_boxes');
/* * ******************* META BOX CHECK ********************** */
/**
 * Check if meta boxes is included
 *
 * @return bool
 */
function rw_maybe_include($template_file) {
    // Include in back-end only
    if (!defined('WP_ADMIN') || !WP_ADMIN)
        return false;
    // Always include for ajax
    if (defined('DOING_AJAX') && DOING_AJAX)
        return true;
    // Check for post IDs
    $checked_post_IDs = array();
    if (isset($_GET['post']))
        $post_id = $_GET['post'];
    elseif (isset($_POST['post_ID']))
        $post_id = $_POST['post_ID'];
    else
        $post_id = false;
    $post_id = (int) $post_id;
    if (in_array($post_id, $checked_post_IDs))
        return true;
    // Check for Page template
    $checked_templates = array($template_file);
    $template = get_post_meta($post_id, '_wp_page_template', true);
    if (in_array($template, $checked_templates))
        return true;
// If no condition matched
    return false;
}
?>