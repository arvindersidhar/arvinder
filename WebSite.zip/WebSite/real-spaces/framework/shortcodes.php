<?php
/* ==================================================
	
	SHORTCODES OUTPUT
	
	================================================== */

/* AGENTS SHORTCODE
	================================================== */

function imic_agents($atts, $content = null)
{
	extract(shortcode_atts(array(
		"number"			=> "",
	), $atts));

	$output = '';
	$user_number = 1;
	$imic_options = get_option('imic_options');
	$users = get_users(array('meta_key' => 'popular', 'meta_value' => 'Popular', 'orderby' => 'display_name'));
	if (!empty($users)) {
		foreach ($users as $user) {
			$User_Phone = get_user_meta($user->ID, 'mobile-phone', true);
			$User_Pic = get_user_meta($user->ID, 'agent-image', true);
			if (!empty($User_Pic)) {
				$output .= '<a href="' . get_author_posts_url($user->ID) . '"><img src="' . $User_Pic . '" alt="Image" class="img-thumbnail"></a>';
			} else {
				$default_image_agent = (isset($imic_options['default_agent_image'])) ? $imic_options['default_agent_image'] : '';
				$output .= '<a href="' . get_author_posts_url($user->ID) . '"><img src="' . $default_image_agent['url'] . '" alt="Image" class="img-thumbnail"></a>';
			}
			$output .= '<div class="row">
                      <div class="col-md-6 col-sm-6 col-xs-6">
                          <h4><a href="' . get_author_posts_url($user->ID) . '">' . $user->display_name . '</a></h4>
                              <a href="' . get_author_posts_url($user->ID) . '" class="btn btn-sm btn-primary">' . esc_html__('more details', 'framework') . '</a>
                       </div>
                       <div class="col-md-6 col-sm-6 col-xs-6">
                              <ul class="contact-info">
                                  <li><i class="fa fa-phone"></i> ' . $User_Phone . '</li>
                               <li><i class="fa fa-envelope"></i> ' . $user->user_email . '</li>
                           </ul>
                       </div>
                    </div>';
			if (++$user_number > $number)
				break;
		}
	} else {
		$output .= '<div class="row">
                      <div class="col-md-6 col-sm-6 col-xs-6">
                          <h4>' . esc_html__('There is no popular agent.', 'framework') . '</h4></div></div>';
	}
	return $output;
}
add_shortcode('agents', 'imic_agents');

/* TESTIMONIALS SHORTCODE
	================================================== */

function imic_testimonial($atts, $content = null)
{
	extract(shortcode_atts(array(
		"number"			=> "",
		"slider" => "no",
		"pagination" => "yes",
		"scroll" => "yes"
	), $atts));

	$output = '';
	$owl = ($slider == "yes") ? 'owl-carousel' : '';
	$pagination = ($pagination == "yes") ? 'data-pagination="yes"' : '';
	$auto_scroll = ($scroll == "yes") ? 'data-autoplay="5000"' : '';
	$output .= '<ul class="testimonials ' . $owl . '" ' . $pagination . ' ' . $auto_scroll . ' data-items-desktop="1" data-items-desktop-small="1" data-items-tablet="1" data-items-mobile="1">';
	query_posts(array('post_type' => 'testimonials', 'posts_per_page' => $number));
	if (have_posts()) : while (have_posts()) : the_post();
			$company = get_post_meta(get_the_ID(), 'imic_client_company', true);
			$Client_Url = get_post_meta(get_the_ID(), 'imic_client_co_url', true);
			$domain_url = $url_html = '';
			if (filter_var($Client_Url, FILTER_VALIDATE_URL)) {
				$domain_url = parse_url($Client_Url);
				$domain_url = $domain_url['host'];
				$url_html = '<br><a href="' . $Client_Url . '">' . $domain_url . '</a>';
			}
			$output .= '<li>
                              ' . imic_excerpt(50) . get_the_post_thumbnail(get_the_ID(), 'full', array('class' => 'testimonial-sender')) . '
                              <cite>' . get_the_title() . ' - <strong>' . $company . '</strong>' . $url_html . '
                           </cite>
                        </li>';
		endwhile;
	endif;
	wp_reset_query();
	$output .= '</ul>';
	return $output;
}
add_shortcode('testimonial', 'imic_testimonial');
/* 
	/* PRICING TABLE SHORTCODE
	================================================== */
function imic_pricing_table($atts, $content = null)
{
	extract(shortcode_atts(array(
		'column' => '',
	), $atts));
	$output = '';
	$column = ($column == 4) ? 'four' : 'three';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<div class="pricing-table ' . $column . '-cols margin-40">' . $shortcode_content . '</div>';
	return $output;
}
add_shortcode('pricingtable', 'imic_pricing_table');

function imic_pricing_table_heading($atts, $content = null)
{
	extract(shortcode_atts(array(
		'active' => '',
	), $atts));
	$output = '';
	$active_class = '';
	if ($active != '') {
		$active_class = ' highlight accent-color';
	}
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<div class="pricing-column ' . $active_class . '"><h3>' . $shortcode_content;
	return $output;
}
add_shortcode('headingss', 'imic_pricing_table_heading');
function imic_pricing_table_reason($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<span class="highlight-reason">' . $shortcode_content . '</span>';
	return $output;
}
add_shortcode('reason', 'imic_pricing_table_reason');
function imic_pricing_table_price($atts, $content = null)
{
	extract(shortcode_atts(array(
		'currency' => '',
	), $atts));
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '</h3><div class="pricing-column-content"><h4> <span class="dollar-sign">' . $currency . ' </span> ' . $shortcode_content;
	return $output;
}
add_shortcode('price', 'imic_pricing_table_price');

function imic_pricing_table_interval($atts, $content = null)
{
	$output = '</h4><span class="interval">';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output .= $shortcode_content . '</span><ul class="features" style="height: 157px;">';

	return $output;
}
add_shortcode('interval', 'imic_pricing_table_interval');
function imic_pricing_table_row($atts, $content = null)
{
	$output = '<li>';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output .= $shortcode_content . '</li>';

	return $output;
}
add_shortcode('row', 'imic_pricing_table_row');
function imic_pricing_table_url($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '</ul><a class="btn btn-primary" href="' . $shortcode_content . '">' . esc_html__('Sign up now!', 'framework') . '</a></div></div>';

	return $output;
}
add_shortcode('url', 'imic_pricing_table_url');

/* BUTTON SHORTCODE
	================================================== */

function imic_button($atts, $content = null)
{
	extract(shortcode_atts(array(
		"colour"		=> "",
		"type"			=> "",
		"link" 			=> "#",
		"target"		=> '_self',
		"size"		=> '',
		"extraclass"   => ''
	), $atts));

	$button_output = "";
	$button_class = 'btn ' . $colour . ' ' . $extraclass . ' ' . $size;
	$buttonType = ($type == 'disabled') ? 'disabled="disabled"' : '';

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$button_output .= '<a class="' . $button_class . '" href="' . $link . '" target="' . $target . '" ' . $buttonType . '>' . $shortcode_content . '</a>';
	return $button_output;
}
add_shortcode('imic_button', 'imic_button');

/* PROPERTIES SHORTCODE
	================================================== */

function imic_properties($atts, $content = null)
{
	extract(shortcode_atts(array(
		"number"		=> "4",
		"column"			=> "4",
		"type" 			=> "",
		"ctype"		=> '',
	), $atts));
	$imic_options = get_option('imic_options');
	$currency_decimal_point = (isset($imic_options['currency_decimal_point'])) ? $imic_options['currency_decimal_point'] : '';
	$currency_decimal_point = ($currency_decimal_point == '') ? 0 : $currency_decimal_point;
	$currency_thousand_separator = (isset($imic_options['currency_thousand_separator'])) ? $imic_options['currency_thousand_separator'] : '';
	$currency_decimal_separator = (isset($imic_options['currency_decimal_separator'])) ? $imic_options['currency_decimal_separator'] : '';
	$properties_output = "";
	$properties_output .= '<div class="property-grid"><ul id="property_grid_holder" class="grid-holder col-' . $column . '">';
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	query_posts(array('post_type' => 'property', 'property-type' => $type, 'property-contract-type' => $ctype, 'post_status' => 'publish', 'paged' => $paged, 'posts_per_page' => $number));
	if (have_posts()) : while (have_posts()) : the_post();
			$property_images = get_post_meta(get_the_ID(), 'imic_property_sights', false);
			$total_images = count($property_images);
			$property_term_type = '';
			$property_area = get_post_meta(get_the_ID(), 'imic_property_area', true);
			$property_baths = get_post_meta(get_the_ID(), 'imic_property_baths', true);
			$property_beds = get_post_meta(get_the_ID(), 'imic_property_beds', true);
			$property_parking = get_post_meta(get_the_ID(), 'imic_property_parking', true);
			$property_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
			$property_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
			$property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
			$property_price = number_format(intval($property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
			$contract = wp_get_object_terms(get_the_ID(), 'property-contract-type', array('fields' => 'ids'));
			$property_id = get_post_meta(get_the_ID(), 'imic_property_site_id', true);
			$property_area_location = wp_get_object_terms(get_the_ID(), 'city-type');
			$sl = '';
			$total_area_location = count($property_area_location);
			$num = 1;
			foreach ($property_area_location as $sa) {
				$conc = ($num != $total_area_location) ? '->' : '';
				$sl .= $sa->name . $conc;
				$num++;
			}
			// We get Longitude & Latitude By Property Address
			$property_longitude_and_latitude = get_post_meta(get_the_ID(), 'imic_lat_long', true);
			if (!empty($property_longitude_and_latitude)) {
				$property_longitude_and_latitude = explode(',', $property_longitude_and_latitude);
			} else {
				$property_longitude_and_latitude = getLongitudeLatitudeByAddress($property_address);
			}
			$currency_symbol = (isset($imic_options['currency-select'])) ? imic_get_currency_symbol($imic_options['currency-select']) : '';
			$src = wp_get_attachment_image_src(get_post_thumbnail_id(), '150-100-size');
			if (!empty($src)) :
				$image_container = '<span class ="property_image_map">' . $src[0] . '</span>';
			else :
				$image_container = '';
			endif;
			if (!empty($contract)) {
				$term = get_term($contract[0], 'property-contract-type');
				$property_term_type = $term->name;
			}
			$properties_output .= '<li id="' . get_the_ID() . '" class="grid-item type-rent">';
			$properties_output .= '<div id="property' . get_the_ID() . '" style="display:none;"><span class ="property_address">' . $property_address . '</span><span class ="property_price"><strong>' . $currency_symbol . '</strong> <span> ' . $property_price . '</span></span><span class ="latitude">' . $property_longitude_and_latitude[0] . '</span><span class ="longitude">' . $property_longitude_and_latitude[1] . '</span>' . $image_container . '<span class ="property_url">' . get_permalink(get_the_ID()) . '</span><span class ="property_image_url">' . IMIC_THEME_PATH . '/assets/images/map-marker.png</span></div>';
			$properties_output .= '<div class="property-block"> <a href="' . get_permalink() . '" class="property-featured-image">';
			$properties_output .= get_the_post_thumbnail(get_the_ID(), '600-400-size');
			$properties_output .= '<span class="images-count"><i class="fa fa-picture-o"></i> ' . $total_images . '</span> <span class="badges badge-' . $term->slug . '">' . $property_term_type . '</span> </a>';
			$properties_output .= '<div class="property-info">';
			$properties_output .= '<h4><a href="' . get_permalink() . '">' . get_the_title() . '</a>' . imicPropertyId(get_the_ID()) . '</h4>';
			if (!empty($property_city)) :
				$properties_output .= '<a class="accent-color" data-original-title="' . $sl . '" data-toggle="tooltip" style="cursor:default; text-decoration:none;" href="javascript:void(0);"><span class="location">' . $property_city . '</span></a><br>';
			endif;
			if (!empty($property_price)) {
				$properties_output .= '<div class="price"><strong>' . $currency_symbol . '</strong><span>' . $property_price . '</span></div>';
			}
			$properties_output .= '</div>';
			if (!empty($property_area) || !empty($property_baths) || !empty($property_beds) || !empty($property_parking)) {
				$properties_output .= '<div class="property-amenities clearfix">';
				if (!empty($property_area)) {
					$properties_output .= '<span class="area"><strong>' . $property_area . '</strong>' . esc_html__('Area', 'framework') . '</span>';
				}
				if (!empty($property_baths)) {
					$properties_output .= '<span class="baths"><strong>' . $property_baths . '</strong>' . esc_html__('Baths', 'framework') . '</span>';
				}
				if (!empty($property_beds)) :
					$properties_output .= '<span class="beds"><strong>' . $property_beds . '</strong>' . esc_html__('Beds', 'framework') . '</span>';
				endif;
				if (!empty($property_parking)) :
					$properties_output .= '<span class="parking"><strong>' . $property_parking . '</strong>' . esc_html__('Parking', 'framework') . '</span>';
				endif;
				$properties_output .= '</div>';
			}
			$properties_output .= '</div>';
			$properties_output .= '</li>';
		endwhile;
	endif;
	$properties_output .= '</ul>';
	$properties_output .= '</div>';
	$properties_output .= get_imic_pagination();
	wp_reset_query();
	return $properties_output;
}
add_shortcode('imic_properties', 'imic_properties');


/* ICON SHORTCODE
	================================================== */

function imic_icon($atts, $content = null)
{
	extract(shortcode_atts(array(
		"image"			=> ""
	), $atts));

	return '<i class="fa ' . $image . '"></i>';
}
add_shortcode('icon', 'imic_icon');

/* ICON BOX SHORTCODE
	================================================== */

function imic_icon_box($atts, $content = null)
{
	extract(shortcode_atts(array(
		"icon_image"	=> "",
		"title"			=> "",
		"description"	=> "",
		"start"			=> "",
		"end"			=> ""
	), $atts));
	$start = ($start != '') ? '<ul>' : '';
	$end = ($end != '') ? '</ul>' : '';
	return $start . '<li class="cust-icon-box">
			<div class="icon">
			<i class="fa ' . $icon_image . '"></i>
			</div>
			<div class="text">
			<h4>' . $title . '</h4>
			<p>' . $description . '</p>
			</div>
			</li>' . $end;
}
add_shortcode('icon_box', 'imic_icon_box');
/* COLUMN SHORTCODES
	================================================== */
function imic_one_full($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
		"anim" => '',
	), $atts));
	$animation = (!empty($anim)) ? 'data-appear-animation="' . $anim . '"' : '';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="col-md-12 ' . $extra . '" ' . $animation . '>' . $shortcode_content . '</div>';
}
add_shortcode('one_full', 'imic_one_full');

function imic_one_half($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
		"anim" => '',
	), $atts));
	$animation = ($anim != 0) ? 'data-appear-animation="bounceInRight"' : '';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="col-md-6 ' . $extra . '" ' . $animation . '>' . $shortcode_content . '</div>';
}
add_shortcode('one_half', 'imic_one_half');

function imic_one_third($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
		"anim" => ''
	), $atts));
	$animation = ($anim != 0) ? 'data-appear-animation="bounceInRight"' : '';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="col-md-4 ' . $extra . '" ' . $animation . '>' . $shortcode_content . '</div>';
}
add_shortcode('one_third', 'imic_one_third');
function imic_one_fourth($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
		"anim" => ''
	), $atts));
	$animation = ($anim != 0) ? 'data-appear-animation="bounceInRight"' : '';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="col-md-3 ' . $extra . '" ' . $animation . '>' . $shortcode_content . '</div>';
}
add_shortcode('one_fourth', 'imic_one_fourth');
function imic_one_sixth($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
		"anim" => ''
	), $atts));
	$animation = ($anim != 0) ? 'data-appear-animation="bounceInRight"' : '';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="col-md-2 ' . $extra . '" ' . $animation . '>' . $shortcode_content . '</div>';
}
add_shortcode('one_sixth', 'imic_one_sixth');

function imic_two_third($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
		"anim" => ''
	), $atts));
	$animation = ($anim != 0) ? 'data-appear-animation="bounceInRight"' : '';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="col-md-8 ' . $extra . '" ' . $animation . '>' . $shortcode_content . '</div>';
}
add_shortcode('two_third', 'imic_two_third');
/* TABLE SHORTCODES
	================================================= */
function imic_table_wrap($atts, $content = null)
{
	extract(shortcode_atts(array(
		"type" => ''
	), $atts));
	$output = '<table class="table ' . $type . '">';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output .= $shortcode_content . '</table>';

	return $output;
}
add_shortcode('htable', 'imic_table_wrap');
function imic_table_headtag($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<thead>' . $shortcode_content . '</thead>';
	return $output;
}
add_shortcode('thead', 'imic_table_headtag');
function imic_table_body($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<tbody>' . $shortcode_content . '</tbody>';
	return $output;
}
add_shortcode('tbody', 'imic_table_body');

function imic_table_row($atts, $content = null)
{
	$output = '<tr>';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output .= $shortcode_content . '</tr>';

	return $output;
}
add_shortcode('trow', 'imic_table_row');

function imic_table_column($atts, $content = null)
{

	$output = '<td>';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output .= $shortcode_content . '</td>';

	return $output;
}
add_shortcode('tcol', 'imic_table_column');
function imic_table_head($atts, $content = null)
{
	$output = '<th>';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output .= $shortcode_content . '</th>';

	return $output;
}
add_shortcode('thcol', 'imic_table_head');

/* TYPOGRAPHY SHORTCODES
	================================================= */
// Anchor tag
function imic_anchor($atts, $content = null)
{
	extract(shortcode_atts(array(
		"href"			=> '',
		"extra"			=> ''
	), $atts));
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<a href="' . $href . '" class="' . $extra . '" >' . $shortcode_content . ' </a>';
}
add_shortcode('anchor', 'imic_anchor');
// Alert tag
function imic_alert($atts, $content = null)
{
	extract(shortcode_atts(array(
		"type"			=> '',
		"close"			=> ''
	), $atts));
	$closeButton = ($close == 'true') ? '<a class="close" data-dismiss="alert" href="#">&times;</a>' : '';
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="alert ' . $type . ' fade in">  ' . $closeButton . $shortcode_content . ' </div>';
}
add_shortcode('alert', 'imic_alert');

// Heading Tag
function imic_heading_tag($atts, $content = null)
{
	extract(shortcode_atts(array(
		"size" => '',
		"extra" => '',
		"icon" => '',
		"type" => ''
	), $atts));
	if ($type == 'block') {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		$output = '<div class="block-heading"><' . $size . ' class="' . $extra . '"><span class="heading-icon"><i class="fa ' . $icon . '"></i></span>' . $shortcode_content . '</' . $size . '></div>';
	} else {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		$output = '<' . $size . ' class="' . $extra . '">' . $shortcode_content . '</' . $size . '>';
	}
	return $output;
}
add_shortcode("heading", "imic_heading_tag");

// Divider Tag
function imic_divider_tag($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
	), $atts));

	return '<hr class="' . $extra . '">';
}
add_shortcode("divider", "imic_divider_tag");

// Paragraph type 
function imic_paragraph($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<p class="' . $extra . '">' . $shortcode_content . '</p>';
}
add_shortcode("paragraph", "imic_paragraph");

// Span type 
function imic_span($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<span class="' . $extra . '">' . $shortcode_content . '</span>';
}
add_shortcode("span", "imic_span");

// Container type 
function imic_container($atts, $content = null)
{
	extract(shortcode_atts(array(
		"extra" => '',
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="' . $extra . '">' . $shortcode_content . '</div>';
}
add_shortcode("container", "imic_container");

// Dropcap type 
function imic_dropcap($atts, $content = null)
{
	extract(shortcode_atts(array(
		"type" => '',
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<p class="drop-caps ' . $type . '">' . $shortcode_content . '</p>';
}
add_shortcode("dropcap", "imic_dropcap");

// Blockquote type
function imic_blockquote($atts, $content = null)
{
	extract(shortcode_atts(array(
		"name" => '',
	), $atts));
	if (!empty($name)) {
		$authorName = '<cite>- ' . $name . '</cite>';
	} else {
		$authorName = '';
	}
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<blockquote><p>' . $shortcode_content . '</p>' . $authorName . '</blockquote>';
}
add_shortcode("blockquote", "imic_blockquote");

// Code type
function imic_code($atts, $content = null)
{
	extract(shortcode_atts(array(
		"type" => '',
	), $atts));

	if ($type == 'inline') {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		return '<code>' . $shortcode_content . '</code>';
	} else {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		return '<pre>' . $shortcode_content . '</pre>';
	}
}
add_shortcode("code", "imic_code");

// Label Tag
function imic_label_tag($atts, $content = null)
{
	extract(shortcode_atts(array(
		"type" => '',
	), $atts));
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<span class="label ' . $type . '">' . $shortcode_content . '</span>';

	return $output;
}
add_shortcode("label", "imic_label_tag");


/* LISTS SHORTCODES
	================================================= */
function imic_list($atts, $content = null)
{
	extract(shortcode_atts(array(
		"type" => '',
		"extra" => '',
		"icon" => ''
	), $atts));

	if ($type == 'ordered') {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		$output = '<ol>' . $shortcode_content . '</ol>';
	} else if ($type == 'desc') {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		$output = '<dl>' . $shortcode_content . '</dl>';
	} else {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		$output = '<ul class="chevrons ' . $type . ' ' . $extra . '">' . $shortcode_content . '</ul>';
	}

	return $output;
}
add_shortcode('list', 'imic_list');

function imic_list_item($atts, $content = null)
{
	extract(shortcode_atts(array(
		"icon" => '',
		"type" => ''
	), $atts));

	if (($type == 'icon') || ($type == 'inline')) {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		$output = '<li><i class="fa ' . $icon . '"></i> ' . $shortcode_content . '</li>';
	} else {
		$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
		$output = '<li>' . $shortcode_content . '</li>';
	}
	return $output;
}
add_shortcode('list_item', 'imic_list_item');

function imic_list_item_dt($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<dt>' . $shortcode_content . '</dt>';

	return $output;
}
add_shortcode('list_item_dt', 'imic_list_item_dt');

function imic_list_item_dd($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<dd>' . $shortcode_content . '</dd>';

	return $output;
}
add_shortcode('list_item_dd', 'imic_list_item_dd');
function imic_page_first($atts, $content = null)
{
	return '<li><a href="#"><i class="fa fa-chevron-left"></i></a></li>';
}
add_shortcode('page_first', 'imic_page_first');

function imic_page_last($atts, $content = null)
{
	return '<li><a href="#"><i class="fa fa-chevron-right"></i></a></li>';
}
add_shortcode('page_last', 'imic_page_last');

function imic_page($atts, $content = null)
{
	extract(shortcode_atts(array(
		"class" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<li class="' . $class . '"><a href="#">' . $shortcode_content . ' </a></li>';
}
add_shortcode('page', 'imic_page');

/* TABS SHORTCODES
	================================================= */
function imic_tabs($atts, $content = null)
{
	return '<div class="tabs">' . do_shortcode($content) . '</div>';
}
add_shortcode('tabs', 'imic_tabs');

function imic_tabh($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<ul class="nav nav-tabs">' . $shortcode_content . '</ul>';
}
add_shortcode('tabh', 'imic_tabh');

function imic_tab($atts, $content = null)
{
	extract(shortcode_atts(array(
		"id" => '',
		"class" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<li class="' . $class . '"> <a data-toggle="tab" href="#' . $id . '"> ' . $shortcode_content . ' </a> </li>';
}
add_shortcode('tab', 'imic_tab');

function imic_tabc($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="tab-content">' . $shortcode_content . '</div>';
}
add_shortcode('tabc', 'imic_tabc');

function imic_tabrow($atts, $content = null)
{
	extract(shortcode_atts(array(
		"id" => '',
		"class" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<div id="' . $id . '" class="tab-pane ' . $class . '">' . $shortcode_content . '</div>';

	return $output;
}
add_shortcode('tabrow', 'imic_tabrow');
/* ACCORDION SHORTCODES
	================================================= */
function imic_accordions($atts, $content = null)
{
	extract(shortcode_atts(array(
		"id" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="accordion" id="accordion' . $id . '">' . $shortcode_content . '</div>';
}
add_shortcode('accordions', 'imic_accordions');

function imic_accgroup($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="accordion-group panel">' . $shortcode_content . '</div>';
}
add_shortcode('accgroup', 'imic_accgroup');

function imic_acchead($atts, $content = null)
{
	extract(shortcode_atts(array(
		"id" => '',
		"class" => '',
		"tab_id" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<div class="accordion-heading accordionize"> <a class="accordion-toggle ' . $class . '" data-toggle="collapse" data-parent="#accordion' . $id . '" href="#' . $tab_id . '"> ' . $shortcode_content . ' <i class="fa fa-angle-down"></i> </a> </div>';

	return $output;
}
add_shortcode('acchead', 'imic_acchead');

function imic_accbody($atts, $content = null)
{
	extract(shortcode_atts(array(
		"tab_id" => '',
		"in" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<div id="' . $tab_id . '" class="accordion-body ' . $in . ' collapse">
					  <div class="accordion-inner"> ' . $shortcode_content . ' </div>
					</div>';

	return $output;
}
add_shortcode('accbody', 'imic_accbody');
/* TOGGLE SHORTCODES
	================================================= */
function imic_toggles($atts, $content = null)
{
	extract(shortcode_atts(array(
		"id" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="accordion" id="toggle' . $id . '">' . $shortcode_content . '</div>';
}
add_shortcode('toggles', 'imic_toggles');

function imic_togglegroup($atts, $content = null)
{
	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	return '<div class="accordion-group panel">' . $shortcode_content . '</div>';
}
add_shortcode('togglegroup', 'imic_togglegroup');

function imic_togglehead($atts, $content = null)
{
	extract(shortcode_atts(array(
		"id" => '',
		"tab_id" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<div class="accordion-heading togglize"> <a class="accordion-toggle" data-toggle="collapse" data-parent="#" href="#' . $tab_id . '"> ' . $shortcode_content . ' <i class="fa fa-plus-circle"></i> <i class="fa fa-minus-circle"></i> </a> </div>';

	return $output;
}
add_shortcode('togglehead', 'imic_togglehead');

function imic_togglebody($atts, $content = null)
{
	extract(shortcode_atts(array(
		"tab_id" => ''
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$output = '<div id="' . $tab_id . '" class="accordion-body collapse">
              <div class="accordion-inner"> ' . $shortcode_content . '  </div>
            </div>';

	return $output;
}
add_shortcode('togglebody', 'imic_togglebody');
/* PROGRESS BAR SHORTCODE
	================================================= */
function imic_progress_bar($atts)
{
	extract(shortcode_atts(array(
		"percentage" => '',
		"name" => '',
		"type" => '',
		"value" => '',
		"colour" => ''
	), $atts));

	if ($type == 'progress-striped') {
		$typeClass = $type;
	} else {
		$typeClass = "";
	}
	if ($colour == 'progress-bar-warning') {
		$warningText = '(warning)';
	} else {
		$warningText = "";
	}

	$service_bar_output = '';
	$progress_text = '';
	if ($name != '') {
		$service_bar_output = '<div class="progress-label"> <span>' . $name . '</span> </div>';
	}
	$service_bar_output .= '<div class="progress ' . $typeClass . '">';

	if ($type == 'progress-striped') {
		$service_bar_output .= '<div class="progress-bar ' . $colour . '" style="width: ' . $value . '%">';
		$service_bar_output .= '<span class="sr-only">' . $value . '% Complete (success)</span>';
		$service_bar_output .= '</div>';
	} else if ($type == 'colored') {
		if (!empty($warningText)) {
			$spanClass = '';
			$progress_text = $value . '% Complete ' . $warningText;
		} else {
			$spanClass = 'sr-only';
			$progress_text = '';
		}
		$service_bar_output .= '<div class="progress-bar ' . $colour . '" style="width: ' . $value . '%"> <span class="' . $spanClass . '">' . $progress_text . '</span> </div>';
	} else {
		$service_bar_output .= '<div class="progress-bar progress-bar-primary" data-appear-progress-animation="' . $value . '%"> <span class="progress-bar-tooltip">' . $value . '%</span> </div>';
	}
	$service_bar_output .= '</div>';

	return $service_bar_output;
}

add_shortcode('progress_bar', 'imic_progress_bar');


/* TOOLTIP SHORTCODE
	================================================= */
function imic_tooltip($atts, $content = null)
{
	extract(shortcode_atts(array(
		"title" => '',
		"link" => '#',
		"direction" => 'top'
	), $atts));

	$shortcode_content = preg_replace("/(<br\s\/>)/", "", do_shortcode($content));
	$tooltip_output = '<a href="' . $link . '" rel="tooltip" data-toggle="tooltip" data-original-title="' . $title . '" data-placement="' . $direction . '">' . $shortcode_content . '</a>';
	return $tooltip_output;
}

add_shortcode('imic_tooltip', 'imic_tooltip');
/* WORDPRESS LINK SHORTCODE
	================================================= */
function imic_wordpress_link()
{
	return '<a href="http://wordpress.org/" target="_blank">WordPress</a>';
}
add_shortcode('wp-link', 'imic_wordpress_link');

/* COUNT SHORTCODE
	================================================= */
function imic_count($atts)
{
	extract(shortcode_atts(array(
		"speed" => '2000',
		"to" => '',
		"icon" => '',
		"subject" => '',
		"textstyle" => ''
	), $atts));

	$count_output = '';
	if ($speed == "") {
		$speed = '2000';
	}
	$count_output .= '<div class="col-lg-3 col-md-3 col-sm-3 cust-counter">';
	$count_output .= '<div class="fact-ico"> <i class="fa ' . $icon . ' fa-4x"></i> </div>';
	$count_output .= '<div class="clearfix"></div>';
	$count_output .= '<div class="timer" data-perc="' . $speed . '"> <span class="count">' . $to . '</span></div>';
	$count_output .= '<div class="clearfix"></div>';
	if ($textstyle == "h3") {
		$count_output .= '<h3>' . $subject . '</h3></div>';
	} else if ($textstyle == "h6") {
		$count_output .= '<h6>' . $subject . '</h6></div>';
	} else {
		$count_output .= '<span class="fact">' . $subject . '</span></div>';
	}

	return $count_output;
}

add_shortcode('imic_count', 'imic_count');

/* MODAL BOX SHORTCODE
	================================================== */
function imic_modal_box($atts, $content = null)
{
	extract(shortcode_atts(array(
		"id"			=> "",
		"title" 	=> "",
		"text"	=> "",
		"button" => ""
	), $atts));

	$modalBox = '<button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#' . $id . '">' . $button . '</button>
            <div class="modal fade" id="' . $id . '" tabindex="-1" role="dialog" aria-labelledby="' . $id . 'Label" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="' . $id . 'Label">' . $title . '</h4>
                  </div>
                  <div class="modal-body"> ' . $text . ' </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default inverted" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>';

	return $modalBox;
}
add_shortcode('modal_box', 'imic_modal_box');

/* FORM SHORTCODE
	================================================== */
function imic_form_code($atts, $content = null)
{
	$admin_email = get_option('admin_email');
	$subject_email = esc_html__('Contact Form', 'framework');
	$formCode = '<form action="' . get_template_directory_uri() . '/mail/contact.php" type="post" class="contact-form">
					  <div class="row">
						<div class="form-group">
						  <div class="col-md-6">
							<label>' . esc_html__('Your name', 'framework') . ' *</label>
							<input type="text" value="" maxlength="100" class="form-control" name="name" id="name">
						  </div>
						  <div class="col-md-6">
							<label>' . esc_html__('Your email address', 'framework') . ' *</label>
							<input type="email" value="" maxlength="100" class="form-control" name="email" id="email">
						  </div>
                                                  <div class="col-md-12">
							<label>' . esc_html__('Your Phone Number', 'framework') . '</label>
							<input type="text" id="phone" name="phone" class="form-control input-lg">
						  </div>
						</div>
					  </div>
					  <div class="row">
                                          <input type ="hidden" name ="image_path" id="image_path" value ="' . IMIC_THEME_PATH . '/">
                                          <input type="hidden" id="phone" name="phone" class="form-control input-lg">
                                          <input id="admin_email" name="admin_email" type="hidden" value ="' . $admin_email . '">
                                              <input id="subject" name="subject" type="hidden" value ="' . $subject_email . '">
						<div class="form-group">
						  <div class="col-md-12">
							<label>' . esc_html__('Comment', 'framework') . '</label>
							<textarea maxlength="5000" rows="10" class="form-control" name="comments" id="comments" style="height: 138px;"></textarea>
						  </div>
						</div>
					  </div>
					  <div class="row">
						<div class="col-md-12">
						  <input type="submit" name ="submit" id ="submit" value="' . esc_html__('Submit', 'framework') . '" class="btn btn-primary" data-loading-text="' . esc_html__('Loading...', 'framework') . '">
						</div>
					  </div>
					</form><div class="clearfix"></div>
                    <div id="message"></div>';
	return $formCode;
}
add_shortcode('imic_form', 'imic_form_code');
