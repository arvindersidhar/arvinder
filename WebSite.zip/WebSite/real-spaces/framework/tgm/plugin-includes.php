<?php
require_once get_template_directory() . '/framework/tgm/class-tgm-plugin-activation.php';
add_action('tgmpa_register', 'realspaces_register_required_plugins');
function realspaces_register_required_plugins()
{
	$plugins_path = get_template_directory() . '/framework/tgm/plugins/';
	$plugins = array(
		array(
			'name'             	=> esc_html__('Favorite Property', 'framework'),
			'slug'              => 'favorite_property',
			'source'           	=> $plugins_path . 'favorite_property.zip',
			'required'          => true,
			'version'          	=> '1.4',
			'force_activation'  => false,
			'force_deactivation' => false,
			'external_url'     	=> '',
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-favorite.png',
		),
		array(
			'name'        		=> esc_html__('A Core Plugin', 'framework'),
			'slug'         		=> 'realspaces-core',
			'source'       		=> get_template_directory_uri() . '/framework/tgm/plugins/realspaces-core.zip',
			'required'       	=> false,
			'version'     		=> '1.1',
			'force_activation'	=> false,
			'force_deactivation' => false,
			'external_url'      => '',
			'type'				=> 'Required',
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-screen-core.png',
		),
		array(
			'name'              => esc_html__('Paid Property imithemes', 'framework'),
			'slug'              => 'Paid-Property-Imithemes',
			'source'            => $plugins_path . 'Paid-Property-Imithemes.zip',
			'required'         	=> true,
			'version'           => '1.4',
			'force_activation'  => false,
			'force_deactivation' => false,
			'external_url'      => '',
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-paid.png',
		),
		array(
			'name'				=> esc_html__('Revolution Slider', 'framework'),
			'slug'             	=> 'revslider',
			'source'           	=> $plugins_path . 'revslider.zip',
			'required'         	=> false,
			'version'          	=> '5.4.8.3',
			'force_activation' 	=> false,
			'force_deactivation' => false,
			'external_url'    	=> '',
			'type'				=> 'Required',
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-revslider.png',
		),
		array(
			'name'				=> esc_html__('Image Watermark', 'framework'),
			'slug'				=> 'image-watermark',
			'required'			=> false,
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-watermark.png',
		),
		array(
			'name' 				=> esc_html__('The GDPR Framework', 'framework'),
			'slug' 				=> 'gdpr-framework',
			'required' 			=> false,
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-gdpr.png',
		),
		array(
			'name' 				=> esc_html__('Pojo Sidebars', 'framework'),
			'slug' 				=> 'pojo-sidebars',
			'required' 			=> false,
			'type'				=> 'Required',
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-pojo.png',
		),
		array(
			'name' 				=> esc_html__('Contact Form 7', 'framework'),
			'slug' 				=> 'contact-form-7',
			'required' 			=> true,
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-cf7.png',
		),
		array(
			'name' 				=> esc_html__('Regenerate Thumbnails', 'framework'),
			'slug' 				=> 'regenerate-thumbnails',
			'required' 			=> false,
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-regen.png',
		),
		array(
			'name' 				=> esc_html__('Loco Translate', 'framework'),
			'slug' 				=> 'loco-translate',
			'required' 			=> false,
			'image_src'			=> get_template_directory_uri() . '/framework/tgm/images/plugin-loco.png',
		),
        array(
			'name' 					=> esc_html__('Best Contact Forms', 'framework'),
			'slug' 					=> 'wpforms-lite',
			'required' 				=> false,
			'image_src'				=> get_template_directory_uri() . '/framework/tgm/images/plugin-wpforms.png',
		),

	);
	$config = array(
		'id'			=> 'tgmpa',
		'default_path'	=> '',
		'menu'			=> 'tgmpa-install-plugins',
		'parent_slug'	=> 'themes.php',
		'capability'	=> 'edit_theme_options',
		'has_notices'	=> false,
		'dismissable'	=> true,
		'dismiss_msg'	=> '',
		'is_automatic'	=> true,
		'message'		=> '',
	);

	tgmpa($plugins, $config);
}
