<?php
/* ==================================================
  Partner Post Type Functions
  ================================================== */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
add_action('init', 'partner_register');
function partner_register() {
    $labels = array(
        'name' => esc_html__('Partners', 'framework'),
        'singular_name' => esc_html__('Partner', 'framework'),
        'all_items'=> esc_html__('Partners', 'framework'),
        'add_new' => esc_html__('Add New', 'framework'),
        'add_new_item' => esc_html__('Add New Partner', 'framework'),
        'edit_item' => esc_html__('Edit Partner', 'framework'),
        'new_item' => esc_html__('New Partner', 'framework'),
        'view_item' => esc_html__('View Partner', 'framework'),
        'search_items' => esc_html__('Search Partner', 'framework'),
        'not_found' => esc_html__('No partner have been added yet', 'framework'),
        'not_found_in_trash' => esc_html__('Nothing found in Trash', 'framework'),
        'parent_item_colon' => ''
    );
    $args = array(
        'labels' => $labels,
		'menu_icon' => 'dashicons-groups',
		'capability_type' => 'page',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => false,
        'rewrite' => false,
        'supports' => array('title'),
        'has_archive' => true,
    );
    register_post_type('partner', $args);
}
?>