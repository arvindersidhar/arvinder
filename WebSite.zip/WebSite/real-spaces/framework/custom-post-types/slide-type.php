<?php
/* ==================================================
  Agent Post Type Functions
  ================================================== */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
add_action('init', 'slide_register');
function slide_register() {
    $labels = array(
        'name' => esc_html__('Slides', 'framework'),
        'singular_name' => esc_html__('Slide', 'framework'),
        'all_items'=> esc_html__('Slides', 'framework'),
        'add_new' => esc_html__('Add New', 'framework'),
        'add_new_item' => esc_html__('Add New Slide', 'framework'),
        'edit_item' => esc_html__('Edit Slide', 'framework'),
        'new_item' => esc_html__('New Slide', 'framework'),
        'view_item' => esc_html__('View Slide', 'framework'),
        'search_items' => esc_html__('Search Slide', 'framework'),
        'not_found' => esc_html__('No slide have been added yet', 'framework'),
        'not_found_in_trash' => esc_html__('Nothing found in Trash', 'framework'),
        'parent_item_colon' => ''
    );
    $args = array(
        'labels' => $labels,
		'menu_icon' => 'dashicons-format-gallery',
		'capability_type' => 'page',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'rewrite' => false,
        'supports' => array('title'),
        'has_archive' => true,
    );
    register_post_type('slide', $args);
}
?>