<?php
/* ==================================================
  Properties Post Type Functions
  ================================================== */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

add_action('init', 'property_register');

function property_register()
{
	$labels = array(
		'name' => esc_html__('Properties', 'framework'),
		'singular_name' => esc_html__('Property', 'framework'),
		'add_new' => esc_html__('Add New', 'framework'),
		'add_new_item' => esc_html__('Add New Property', 'framework'),
		'edit_item' => esc_html__('Edit Property', 'framework'),
		'new_item' => esc_html__('New Property', 'framework'),
		'view_item' => esc_html__('View Property', 'framework'),
		'search_items' => esc_html__('Search Properties', 'framework'),
		'not_found' =>  esc_html__('No Properties have been added yet', 'framework'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'framework'),
		'parent_item_colon' => ''
	);
	$args = array(
		'labels' => $labels,
		'menu_icon' => 'dashicons-location-alt',
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => true,
		'rewrite' => true,
		'supports' => array('title', 'editor', 'thumbnail', 'author'),
		'has_archive' => true,
		'taxonomies' => array('property-type', 'property-contract-type')
	);

	register_post_type('property', $args);
	$args = array(
		"label" 			=> esc_html__('Types', 'framework'),
		"singular_label" 	=> esc_html__('Type', 'framework'),
		'public'            => true,
		'hierarchical'      => true,
		'show_ui'           => true,
		'show_in_nav_menus' => true,
		'args'              => array('orderby' => 'term_order'),
		'rewrite'           => false,
		'query_var'         => true,
		'show_admin_column' => true,
	);
	register_taxonomy('property-type', 'property', $args);
	$args = array(
		"label" 			=> esc_html__('Contract Types', 'framework'),
		"singular_label" 	=> esc_html__('Contract Type', 'framework'),
		'public'            => true,
		'hierarchical'      => true,
		'show_ui'           => true,
		'show_in_nav_menus' => true,
		'args'              => array('orderby' => 'term_order'),
		'rewrite'           => false,
		'query_var'         => true,
		'show_admin_column' => true,
	);
	register_taxonomy('property-contract-type', 'property', $args);
	$args_c = array(
		"label" 			=> esc_html__('Cities', 'framework'),
		"singular_label" 	=> esc_html__('City', 'framework'),
		'public'            => true,
		'hierarchical'      => true,
		'show_ui'           => true,
		'show_in_nav_menus' => true,
		'args'              => array('orderby' => 'term_order'),
		'rewrite'           => false,
		'query_var'         => true,
		'show_admin_column' => true,
	);
	register_taxonomy('city-type', 'property', $args_c);
}
