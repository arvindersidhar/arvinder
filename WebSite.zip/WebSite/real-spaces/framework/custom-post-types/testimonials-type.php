<?php
/* ==================================================
   Testimonials Post Type Functions
================================================== */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
    add_action('init', 'testimonials_register');  
  function testimonials_register() {  
	$labels = array(
		'name' => esc_html__('Testimonials', 'framework'),
		'singular_name' => esc_html__('Testimonial', 'framework'),
		'add_new' => esc_html__('Add New', 'framework'),
		'add_new_item' => esc_html__('Add New Testimonial', 'framework'),
		'edit_item' => esc_html__('Edit Testimonial', 'framework'),
		'new_item' => esc_html__('New Testimonial', 'framework'),
		'view_item' => esc_html__('View Testimonial', 'framework'),
		'search_items' => esc_html__('Search Testimonials', 'framework'),
		'not_found' =>  esc_html__('No testimonials have been added yet', 'framework'),
		'not_found_in_trash' => esc_html__('Nothing found in Trash', 'framework'),
		'parent_item_colon' => ''
	);
	$args = array(  
		'labels' => $labels, 
		'menu_icon' => 'dashicons-format-quote', 
		'public' => true,  
		'show_ui' => true,
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
		'rewrite' => false,
		'supports' => array('title', 'editor', 'thumbnail'),
		'has_archive' => true
	   );  
  
	register_post_type( 'testimonials' , $args );  
}  
?>