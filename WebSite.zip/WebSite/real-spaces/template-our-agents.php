<?php
/* Template Name: Agent */
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
/* Site Showcase */
imic_page_banner($pageID = get_the_ID());
/* End Site Showcase */
if (is_home() && !empty($page_for_posts)) {
	$blog_id = $page_for_posts;
} else {
	$blog_id = get_the_ID();
}
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
	$ContentWidth = 12 - $imic_options['sidebar_width'];
	$SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($blog_id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
	$ContentWidth = 12 - $pageSidebarWidth;
	$SidebarWidth = $pageSidebarWidth;
}
$pageSidebar = get_post_meta($blog_id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
	$class = $ContentWidth;
} else {
	$class = 12;
}
//-- Start Content --
echo '<div class="main" role="main">
<div id="content" class="content full">
<div class="container">
<div class="row">';
echo '<div class="col-md-' . $class . '" id="content-col">'; ?>

<?php if (have_posts()) : while (have_posts()) : the_post();
		the_content();
	endwhile;
endif; ?>

<?php echo '<div class="block-heading">';
/* Become an agent details
================================ */
$becomeAgentText = get_post_meta(get_the_ID(), 'imic_agent_become_agent_text', true);
$becomeAgentURL = get_post_meta(get_the_ID(), 'imic_agent_become_agent_url', true);
if (!empty($becomeAgentText) && !empty($becomeAgentURL) && (!is_user_logged_in())) {
	echo '<a href="' . $becomeAgentURL . '" class="btn btn-sm btn-primary pull-right">' . $becomeAgentText . ' <i class="fa fa-long-arrow-right"></i></a>';
}
echo '<h4><span class="heading-icon"><i class="fa fa-users"></i></span>' . esc_html__('All Agents', 'framework') . '</h4>';
echo '</div>';
echo '<div class="agents-listing">';
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$per_page = get_option('posts_per_page');
$pages = $paged - 1;
$args = array(
	'blog_id' => $GLOBALS['blog_id'],
	'role' => 'agent',
	'order' => 'ASC',
	'orderby' => 'registered',
	'number' => $per_page,
	'offset' => $pages * $per_page
);
$blogusers = new WP_User_Query($args);
$Count_Agent = count(get_users(array('role' => 'agent')));
if (!empty($blogusers->results)) {
	echo '<ul>';
	foreach ($blogusers->results as $user) {
		echo '<li class="col-md-12">';
		/* Agent's Image
	======================= */
		$userImageID = get_the_author_meta('agent-image', $user->ID);
		$userDescClass = 12;
		if (!empty($userImageID)) {
			$image_id = imic_get_src_image_id($userImageID);
			$userImage = wp_get_attachment_image_src($image_id, '150-150-size');
			echo '<div class="col-md-4">
			<a href="' . get_author_posts_url($user->ID) . '" class="agent-featured-image"> <img src="' . $userImage[0] . '" alt="agent"></a>
			</div>';
			$userDescClass = 8;
		} else {
			$default_image_agent = (isset($imic_options['default_agent_image'])) ? $imic_options['default_agent_image'] : '';
			echo '<div class="col-md-4">
			<a href="' . get_author_posts_url($user->ID) . '" class="agent-featured-image"> <img src="' . $default_image_agent['url'] . '" alt="agent"></a>
			</div>';
			$userDescClass = 8;
		}
		echo '<div class="col-md-' . $userDescClass . '">';
		echo '<div class="agent-info">';
		echo '<div class="counts">';
		echo '<strong>';
		/* Display Agent's Total Properties
		======================================== */
		echo imic_count_user_posts_by_type($user->ID, 'property');
		echo '</strong>';
		echo '<span>' . esc_html__('Properties', 'framework') . '</span>';
		echo '</div>';
		echo '<h3 class="margin-0"><a href="' . get_author_posts_url($user->ID) . '">';
		/* Display Agent Name
		========================== */
		$user_position = get_user_meta($user->ID, 'imic_user_position', true);
		$userFirstName = get_the_author_meta('first_name', $user->ID);
		$userLastName = get_the_author_meta('last_name', $user->ID);
		$userName = $user->display_name;
		if (!empty($userFirstName) || !empty($userLastName)) {
			$userName = $userFirstName . ' ' . $userLastName;
		}
		echo esc_attr($userName);
		echo '</a></h3>';
		if ($user_position != '') {
			echo '<h4>' . $user_position . '</h4><div class="margin-20"></div>';
		}
		/* Display Agent Description
		================================== */
		imic_agent_excerpt($user->ID);
		echo '<div class="margin-20"></div></div>';
		/* Display Agent Social Links
		=================================== */
		$userFB = get_the_author_meta('fb-link', $user->ID);
		$userTWT = get_the_author_meta('twt-link', $user->ID);
		$userGP = get_the_author_meta('gp-link', $user->ID);
		$userMSG = get_the_author_meta('msg-link', $user->ID);
		$userLINKEDIN = get_the_author_meta('linkedin-link', $user->ID);
		$userSocialArray = array_filter(array($userFB, $userTWT, $userGP, $userMSG, $userLINKEDIN));
		$userSocialClass = array('fa-facebook', 'fa-twitter', 'fa-google-plus', 'fa-envelope', 'fa-linkedin');
		echo '<div class="agent-contacts clearfix">';
		if (!empty($userSocialArray)) {
			echo '<ul>';
			foreach ($userSocialArray as $key => $value) {
				if (!empty($value) && $userSocialClass[$key] == 'fa-envelope') {
					echo '<li><a href="mailto:' . $value . '" target="_blank"><i class="fa ' . $userSocialClass[$key] . '"></i></a></li>';
				} elseif (!empty($value)) {
					echo '<li><a href="' . $value . '" target="_blank"><i class="fa ' . $userSocialClass[$key] . '"></i></a></li>';
				}
			}
			echo '</ul>';
		}
		echo '</div></div></li>';
	}
	echo '</ul>';

	echo '</div>';
	$Total_Pages = $Count_Agent / $per_page;
	if (is_float($Total_Pages)) {
		$Total_Pages = $Total_Pages + 1;
	}
	if ($Count_Agent > $per_page) {
		pagination($Total_Pages, $per_page);
	}
} else {
	echo do_shortcode($imic_options['no_agents_msg']);
	echo '</div>';
}
echo '</div>'; ?>
<!-- Start Sidebar -->
<?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
	<div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
		<?php dynamic_sidebar($pageSidebar); ?>
	</div>
<?php } ?>
</div>
</div>
</div>
<?php get_footer(); ?>