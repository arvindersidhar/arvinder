function PropertiesMap() {
  var properties=[];
          jQuery('ul#property_grid_holder li').each(function(i)
      { 
        properties.push({  
        title :jQuery(this).find('.property_address').text(),                               
        price :jQuery(this).find('.property_price').html(),
        lat :jQuery(this).find('.latitude').text(),
        lng :jQuery(this).find('.longitude').text() ,
        thumb:jQuery(this).find('.property_image_map').text(),  
        url:jQuery(this).find('.property_url').text(),  
        icon:jQuery(this).find('.property_image_url').text() 
     });
   });
var mapOptions = {
                zoom: 12,
                scrollwheel: false
            }
            var map = new google.maps.Map(document.getElementById("gmap"), mapOptions);
            var bounds = new google.maps.LatLngBounds();
            var markers = new Array();
            var info_windows = new Array();
            for (var i=0; i < properties.length; i++) {
                              markers[i] = new google.maps.Marker({
                    position: new google.maps.LatLng(properties[i].lat,properties[i].lng),
                    map: map,
                    icon: properties[i].icon,
                    title: properties[i].title,
                    animation: google.maps.Animation.DROP
                });
				bounds.extend(markers[i].getPosition());
   info_windows[i] = new google.maps.InfoWindow({
                    content:    '<div class="map-property">'+
                        '<h4 class="property-title"><a class="title-link" href="'+properties[i].url+'">'+properties[i].title+'</a></h4>'+
                        '<a class="property-featured-image" href="'+properties[i].url+'"><img class="property-thumb" src="'+properties[i].thumb+'" alt="'+properties[i].title+'"/></a>'+
                        '<p><span class="price">'+properties[i].price+'</span></p>'+
                        '<a class="btn btn-primary btn-sm" href="'+properties[i].url+'">Details</a>'+
                        '</div>'
                });  
        attachInfoWindowToMarker(map, markers[i], info_windows[i]);
            }
            map.fitBounds(bounds);
            /* function to attach infowindow with marker */
            function attachInfoWindowToMarker( map, marker, infoWindow ){
                google.maps.event.addListener( marker, 'click', function(){
                    infoWindow.open( map, marker );
                });
            }
        }
       google.maps.event.addDomListener(window, 'load', PropertiesMap);