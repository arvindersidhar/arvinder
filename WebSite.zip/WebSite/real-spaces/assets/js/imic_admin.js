/*
 *
 *	Admin jQuery Functions
 *	------------------------------------------------
 *	Imic Framework
 * 	Copyright Imic 2014 - http://imithemes.com
 *
 */
jQuery(window).load(function () {
    var mb = jQuery('#realspaces-admin-notices'),
        mbl = mb.length;

    mb.hide();
    rand();

    function rand() {
        var r = getRand(0, mbl);

        mb.eq(r).fadeIn('slow', function () {
            jQuery(this).fadeOut('slow', function () {
                setTimeout(rand, 200);
            });
        });
    }


    function getRand(min, max) {
        return Math.floor(Math.random() * (max - min) + min);
    }

    jQuery('#wpseo_meta.postbox').show();
});
jQuery(function (jQuery) {
    // Amenities at property page
    jQuery("#imic_property_amenities-description").closest('.rwmb-text-wrapper').find('.rwmb-clone .rwmb-text').live('click', function () {
        var text_name = jQuery(this).attr('name');
        jQuery("body").data("text_name", text_name);
        if (jQuery("#amenity_array").length == 0) {
            jQuery("#imic_property_amenities-description").closest('.rwmb-text-wrapper').append(amenity_array.value);
            jQuery("#imic_property_amenities-description").closest('.rwmb-text-wrapper').find('select').focus();
        }
    });
    jQuery("#amenity_select_array").live('change', function () {
        text_name = jQuery("body").data("text_name");
        var current_value = jQuery("#amenity_select_array option:selected").text();
        jQuery("body").find('input[name$="' + text_name + '"]').val(current_value);
    });
});
jQuery(function ($) {
    if (jQuery('#upload_image_preview').attr('src') == '') {
        jQuery('#upload_image_preview').hide();
        jQuery('#upload_agent_button_remove').hide();
    }
    jQuery('#upload_agent_button_remove').live('click', function () {
        jQuery('#upload_image_preview').attr('src', '');
        jQuery('#agent_url').val('');
        jQuery('#upload_image_preview').hide();
    })
    jQuery('#upload_agent_button').live('click', function () {
        var fileFrame = wp.media.frames.file_frame = wp.media({
            multiple: false
        });
        fileFrame.on('select', function () {
            var attachment = fileFrame.state().get('selection').first().toJSON();
            jQuery('#agent_url').val(attachment.url);
            jQuery('#upload_image_preview').show();
            jQuery('#upload_agent_button_remove').show();
            jQuery('img#upload_image_preview').attr('src', attachment.url);
        });
        fileFrame.open();
    });
});
jQuery(function ($) {
    if (jQuery('#upload_banner_preview').attr('src') == '') {
        jQuery('#upload_banner_preview').hide();
        jQuery('#upload_agent_banner_remove').hide();
    }
    jQuery('#upload_agent_banner_remove').live('click', function () {
        jQuery('#upload_banner_preview').attr('src', '');
        jQuery('#agent_banner').val('');
        jQuery('#upload_banner_preview').hide();
    })
    jQuery('#upload_agent_banner').live('click', function () {
        var fileFrame = wp.media.frames.file_frame = wp.media({
            multiple: false
        });
        fileFrame.on('select', function () {
            var attachment = fileFrame.state().get('selection').first().toJSON();
            jQuery('#agent_banner').val(attachment.url);
            jQuery('#upload_banner_preview').show();
            jQuery('#upload_agent_banner_remove').show();
            jQuery('img#upload_banner_preview').attr('src', attachment.url);
        });
        fileFrame.open();
    });
    jQuery(".redux-message").hide()
});