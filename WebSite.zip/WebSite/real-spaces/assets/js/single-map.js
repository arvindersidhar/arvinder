function SingleMap() {
	var properties=[];
  	if(urlajax.is_property==1){
     	properties.push({  
        	title :jQuery('.single-property').find('.property_address').text(),                               
        	price :jQuery('.single-property').find('.property_price').html(),
        	lat :jQuery('.single-property').find('.latitude').text(),
        	lng :jQuery('.single-property').find('.longitude').text() ,
        	thumb:jQuery('.single-property').find('.property_image_map').text(),  
        	url:jQuery('.single-property').find('.property_url').text(),  
        	icon:jQuery('.single-property').find('.property_image_url').text() 
     	});   
 	}else{
     	if(urlajax.is_contact==1){
            properties.push({  
        		title :jQuery('.property_container').find('.property_address').text(),                               
        		lat :jQuery('.property_container').find('.latitude').text(),
        		lng :jQuery('.property_container').find('.longitude').text() ,
        		icon:jQuery('.property_container').find('.property_image_url').text() 
     		});   
    	}
		else{
      		properties.push({                                
        		lat :'10',
       			lng :'10' ,
     		});   
   		}
	}
  	var property_zoom;
   	if(urlajax.is_property==1||urlajax.is_contact==1){
    	property_zoom= parseInt(jQuery('.property_zoom_level').attr('id'));
    }
    else{
  		property_zoom=4;
   	}
	var mapOptions = {
      	zoom: property_zoom,
		center: new google.maps.LatLng(properties[0].lat,properties[0].lng),
        scrollwheel: false
   	}
    var map = new google.maps.Map(document.getElementById("onemap"), mapOptions);
   	var markers = new Array();
   	var info_windows = new Array();
   	for (var i=0; i < properties.length; i++) {
       	markers[i] = new google.maps.Marker({
       		position: map.getCenter(),
            map: map,
            icon: properties[i].icon,
          	title: properties[i].title,
          	animation: google.maps.Animation.DROP
      	});
   		if(urlajax.is_contact==1){
     		info_windows[i] = new google.maps.InfoWindow({
             	content:'<div class="map-property">'+
                 		'<h4 class="property-title">'+properties[i].title+'</h4>'+
                         '</div>'
            });  
     	}else{
   			info_windows[i] = new google.maps.InfoWindow({
          		content:'<div class="map-property">'+
                        '<h4 class="property-title"><a class="title-link" href="'+properties[i].url+'">'+properties[i].title+'</a></h4>'+
                        '<a class="property-featured-image" href="'+properties[i].url+'"><img class="property-thumb" src="'+properties[i].thumb+'" alt="'+properties[i].title+'"/></a>'+
                        '<p><span class="price">'+properties[i].price+'</span></p>'+
                        '<a class="btn btn-primary btn-sm" href="'+properties[i].url+'">Details</a>'+
                        '</div>'
           	});  
 		}
        attachInfoWindowToMarker(map, markers[i], info_windows[i]);
    }
    /* function to attach infowindow with marker */
   	function attachInfoWindowToMarker( map, marker, infoWindow ){
      	google.maps.event.addListener( marker, 'click', function(){
        	infoWindow.open( map, marker );
      	});
   	}
}
google.maps.event.addDomListener(window, 'load', SingleMap);