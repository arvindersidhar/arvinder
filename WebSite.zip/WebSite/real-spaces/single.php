<?php get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
/* Page Banner HTML
=============================*/
imic_page_banner($pageID = get_the_ID());
$image = '';
$id = get_the_ID();
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
  $ContentWidth = 12 - $imic_options['sidebar_width'];
  $SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
  $ContentWidth = 12 - $pageSidebarWidth;
  $SidebarWidth = $pageSidebarWidth;
}
$pageSidebarDefault = (isset($imic_options['post_sidebar'])) ? $imic_options['post_sidebar'] : '';
$pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar) || !empty($pageSidebarDefault) && is_active_sidebar($pageSidebarDefault)) {
  $class = $ContentWidth;
} else {
  $class = 12;
}
$thumb_size = (empty($sidebar) || !is_active_sidebar($sidebar[0])) ? 'full' : '600-400-size';
$post_format = get_post_format(get_the_ID());
if ($post_format == 'gallery') {
  $image = get_post_meta(get_the_ID(), 'imic_gallery_images', true);
  $image = wp_get_attachment_image_src($image, $thumb_size, true);
  $image = $image[0];
} else {
  if ('' != get_the_post_thumbnail()) {
    $image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), $thumb_size);
    $image = $image[0];
  }
} ?>
<div class="main" role="main">
  <div id="content" class="content full">
    <div class="container">
      <div class="row">
        <div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">
          <header class="single-post-header clearfix">
            <?php while (have_posts()) : the_post(); ?>
              <h2 class="post-title"><?php the_title(); ?></h2>
            </header>
            <article class="post-content">
              <div class="post-meta meta-data">
                <span><i class="fa fa-calendar"></i><?php esc_html_e(' Posted on ', 'framework');
                                                    echo get_the_date(); ?></span>
                <span><i class="fa fa-user"></i><?php esc_html_e(' By ', 'framework');
                                                $author_id = $post->post_author;
                                                the_author_meta('user_nicename', $author_id); ?></span>
                <span><i class="fa fa-tag"></i><?php esc_html_e(' Categories: ', 'framework'); ?><?php the_category(', '); ?></span>
                <span><?php comments_popup_link('<i class="fa fa-comment"></i>' . esc_html__('No comments yet', 'framework'), '<i class="fa fa-comment"></i>1', '<i class="fa fa-comment"></i>%', 'comments-link', esc_html__('Comments are off for this post', 'framework')); ?></span>
              </div>
              <?php if ('' != get_the_post_thumbnail()) { ?>
                <div class="featured-image"> <img src="<?php echo esc_url($image); ?>" alt="Image"> </div>
              <?php }
            the_content();
            if (isset($imic_options['switch_sharing']) && $imic_options['switch_sharing'] == 1 && $imic_options['share_post_types']['1'] == '1') {
              imic_share_buttons();
            }


            wp_link_pages();
          endwhile;
          if (has_tag()) {
            echo '<div class="post-meta">';
            echo '<i class="fa fa-tags"></i>';
            the_tags('', ', ');
            echo '</div>';
          } ?>
          </article>
          <?php comments_template('', true); ?>
        </div>
        <!-- Start Sidebar -->
        <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
          <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
            <?php dynamic_sidebar($pageSidebar); ?>
          </div>
        <?php } elseif (!empty($pageSidebarDefault) && is_active_sidebar($pageSidebarDefault)) { ?>
          <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
            <?php dynamic_sidebar($pageSidebarDefault); ?>
          </div>
        <?php } ?>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>