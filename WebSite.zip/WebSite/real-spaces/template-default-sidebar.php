<?php
/*
Template Name: with default sidebar
*/
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
    $ContentWidth = 12 - $imic_options['sidebar_width'];
    $SidebarWidth = $imic_options['sidebar_width'];
}
if (is_active_sidebar('inner-sidebar')) {
    $class = $ContentWidth;
} else {
    $class = 12;
}
/* Page Banner HTML
=============================*/
imic_page_banner($pageID = get_the_ID()); ?>
<!-- Start Content -->
<div class="main" role="main">
    <div id="content" class="content full">
        <div class="container">
            <div class="row">
                <div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">
                    <?php if (have_posts()) : while (have_posts()) : the_post();
                            the_content();
                        endwhile;
                    endif; ?>
                </div>
                <!-- Start Sidebar -->
                <?php if (is_active_sidebar('inner-sidebar')) { ?>
                    <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
                        <?php dynamic_sidebar('inner-sidebar'); ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
</div>
<?php get_footer(); ?>