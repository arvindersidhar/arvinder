<?php
/* Template Name: Agent Profile */
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
/* Site Showcase */
imic_page_banner($pageID = get_the_ID());
$id = get_the_ID();
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
    $ContentWidth = 12 - $imic_options['sidebar_width'];
    $SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
    $ContentWidth = 12 - $pageSidebarWidth;
    $SidebarWidth = $pageSidebarWidth;
}
$pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
    $class = $ContentWidth;
} else {
    $class = 12;
}
/* End Site Showcase */
if (is_user_logged_in()) {
    global $userdata;
    $current_user = wp_get_current_user();
    if (!empty($_POST['action'])) {
        $first_name = (isset($_POST['first_name'])) ? $_POST['first_name'] : '';
        $last_name = (isset($_POST['last_name'])) ? $_POST['last_name'] : '';
        $description = (isset($_POST['description'])) ? $_POST['description'] : '';
        wp_update_user(array('ID' => $user_ID, 'first_name' => $first_name, 'last_name' => $last_name, 'nickname' => $first_name, 'description' => $description));
        require_once(ABSPATH . 'wp-admin/includes/user.php');
        check_admin_referer('update-profile_' . $user_ID);
        $errors = edit_user($user_ID);
        $agentMobileNo = esc_sql(trim($_POST['mobile-phone']));
        $agentWorkNo = esc_sql(trim($_POST['work-phone']));
        $agentFaxNo = esc_sql(trim($_POST['fax-phone']));
        $agentFBLink = esc_sql(trim($_POST['fb-link']));
        $agentTWTLink = esc_sql(trim($_POST['twt-link']));
        $agentGPLink = esc_sql(trim($_POST['gp-link']));
        $agentyoutubeLink = esc_sql(trim($_POST['youtube-link']));
        $agentlinkedinLink = esc_sql(trim($_POST['linkedin-link']));
        $agentwebsiteLink = esc_sql(trim($_POST['website-link']));
        $agentMSGLink = esc_sql(trim($_POST['msg-link']));
        $agentRole = esc_sql(trim($_POST['change_role_member']));
        $agent_position = esc_sql(trim($_POST['position']));
        $agentDataKeys = array('mobile-phone', 'work-phone', 'fax-phone', 'fb-link', 'twt-link', 'gp-link', 'youtube-link', 'website-link', 'msg-link', 'role', 'imic_user_position', 'linkedin-link');
        $agentDataValues = array($agentMobileNo, $agentWorkNo, $agentFaxNo, $agentFBLink, $agentTWTLink, $agentGPLink, $agentyoutubeLink, $agentwebsiteLink, $agentMSGLink, $agentRole, $agent_position, $agentlinkedinLink);
        foreach (array_combine($agentDataKeys, $agentDataValues) as $agentKey => $agentValue) {
            update_user_meta($user_ID, $agentKey, $agentValue);
        }
        $updateUserdata = array();
        $updateUserdata['ID'] = $user_ID;
        $updateUserdata['role'] = $_POST['change_role_member'];
        if (!empty($_POST['change_role_member']) && ($_POST['change_role_member'] != esc_html__('Change Your Role', 'framework')) && !current_user_can('administrator')) {
            wp_update_user($updateUserdata);
        }
        //Image
        if (!empty($_FILES)) {
            $allowedExts = array("jpeg", "jpg", "JPG", "png", "gif");
            $temp = explode(".", $_FILES["agent-image"]["name"]);
            $extension = end($temp);
            if (in_array($extension, $allowedExts) && ($_FILES["agent-image"]["size"] < 2000000)) {
                if ($_FILES["agent-image"]["error"] > 0) {
                    $message = esc_html__("Return Code: ", "framework") . $_FILES["agent-image"]["error"] . "<br>";
                } else {
                    $user_image = sight('agent-image', $user_ID);
                    $user_image = wp_get_attachment_image_src($user_image, 'full');
                    $ss = update_user_meta($user_ID, 'agent-image', $user_image[0]);
                }
            }
        }
        $errmsg = '';
        if (is_wp_error($errors)) {
            foreach ($errors->get_error_messages() as $message)
                $errmsg = "$message";
        }
        if ($errmsg == '') {
            //do_action('personal_options_update', $user_ID);
            $successMsg= "<div id=\"message\"><div class=\"alert alert-success\">".esc_html__('Profile Successfully Updated','framework')."</div></div>";
        } else {
            $successMsg = '';
        }
    }
    $current_user = wp_get_current_user();
    $user_position = get_user_meta($user_ID, 'imic_user_position', true);
    ?>
    <!-- Start Content -->
    <div class="main" role="main">
        <div id="content" class="content full">
            <div class="container">
                <div class="page">
                    <div class="row">
                        <div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">

                            <?php if (have_posts()) : while (have_posts()) : the_post();
                                    the_content();
                                endwhile;
                            endif; ?>

                            <?php if (!empty($successMsg)) :
                                echo '' . $successMsg;
                            endif; ?>
                            <div class="single-agent">
                                <div class="counts pull-right">
                                    <strong><?php esc_html_e('Member Since', 'framework'); ?></strong>
                                    <span><?php echo date("l, M d, Y", strtotime(get_userdata(get_current_user_id())->user_registered)); ?></span>
                                </div>
                                <h2 class="page-title">
                                    <?php
                                    if (!empty($userdata->first_name)) {
                                        echo esc_attr($userdata->first_name);
                                    } else {
                                        echo esc_attr($userdata->user_login);
                                    }
                                    ?>
                                </h2>
                            </div>
                            <form name="profile" action="" method="post" id="agent-profile-form" enctype="multipart/form-data"> <?php wp_nonce_field('update-profile_' . $user_ID) ?>
                                <input type="hidden" name="from" value="profile" />
                                <input type="hidden" name="action" value="update" />
                                <input type="hidden" name="checkuser_id" value="<?php echo esc_attr($user_ID); ?>" />
                                <input type="hidden" name="dashboard_url" value="<?php echo get_option("dashboard_url"); ?>" />
                                <input type="hidden" name="user_id" id="user_id" value="<?php echo esc_attr($user_ID); ?>" />
                                <div class="block-heading" id="details">
                                    <h4><span class="heading-icon"><i class="fa fa-user"></i></span><?php esc_html_e('Profile Details', 'framework');
                                                                                                    echo ' ( ' . $userdata->user_login . ' )';   ?></h4>
                                </div>
                                <?php
                                $current_user = wp_get_current_user();

                                $user_roles = $current_user->roles;
                                $user_role = array_shift($user_roles);
                                if ($user_role == 'subscriber') {
                                    $become_member_as = esc_html__('Agent', 'framework');
                                    $change_role = 'agent';
                                } else {
                                    $become_member_as = esc_html__('Buyer', 'framework');
                                    $change_role = 'subscriber';
                                } ?>
                                <div class="row">
                                    <div class="change_user_info col-md-6 col-sm-6">
                                        <label><?php esc_html_e('Change Your Role', 'framework'); ?></label>
                                        <select name="change_role_member" class="form-control selectpicker">
                                            <option><?php esc_html_e('Change Your Role', 'framework'); ?></option>
                                            <option value="<?php echo esc_attr($change_role); ?>"><?php echo esc_html__('Change to ', 'framework') . $become_member_as; ?></option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <label><?php esc_html_e('Profile/Position', 'framework'); ?></label>
                                        <input type="text" name="position" id="position" value="<?php echo esc_attr($user_position); ?>" class="form-control position" placeholder="<?php esc_html_e('Position', 'framework'); ?>">
                                    </div>
                                </div>
                                <div class="padding-as25 margin-30 lgray-bg">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('First Name', 'framework'); ?></label>
                                            <input type="text" name="first_name" id="first_name" value="<?php echo esc_attr($userdata->first_name); ?>" class="form-control first_name" placeholder="<?php esc_html_e('First Name', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('Last Name', 'framework'); ?></label>
                                            <input type="text" name="last_name" id="last_name" value="<?php echo esc_attr($userdata->last_name); ?>" class="form-control last_name" placeholder="<?php esc_html_e('Last Name', 'framework'); ?>">

                                            <input type="hidden" name="nickname" id="nickname" value="<?php echo esc_attr($userdata->nickname); ?>" class="form-control">
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('Email', 'framework'); ?></label>
                                            <input type="email" id="email" value="<?php echo esc_attr($userdata->user_email); ?>" name="email" class="form-control email1" placeholder="<?php esc_html_e('Email', 'framework'); ?>">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <label for="password"><?php esc_html_e('Change Password', 'framework'); ?></label>
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('New password', 'framework'); ?></label>
                                            <input type="password" value="" name="pass1" id="pass1" class="form-control pwd1" placeholder="<?php esc_html_e('New password', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('Confirm password', 'framework'); ?></label>
                                            <input type="password" value="" name="pass2" id="pass2" class="form-control pwd2" placeholder="<?php esc_html_e('Confirm password', 'framework'); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="block-heading" id="additionalinfo">
                                    <h4><span class="heading-icon"><i class="fa fa-plus"></i></span><?php esc_html_e('Personal Info', 'framework'); ?></h4>
                                </div>
                                <div class="padding-as25 margin-30 lgray-bg">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4 ">
                                            <label><?php esc_html_e('Biographical Info', 'framework'); ?></label>
                                        </div>
                                        <div class="col-md-8 col-sm-8 submit-description">
                                            <textarea name="description" id="description" class="form-control margin-0" rows="5" cols="10" placeholder="<?php esc_html_e('Description', 'framework'); ?>"><?php echo '' . $userdata->description; ?></textarea>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('Upload Image', 'framework'); ?></label>
                                            <p><?php esc_html_e('Upload image that are best clicked for better appearance of your profile', 'framework'); ?></p>
                                        </div>
                                        <div class="col-md-8 col-sm-8 submit-image">
                                            <?php $userImgSrc = '';
                                            $userImg = get_the_author_meta('agent-image', $user_ID);
                                            if (!empty($userImg)) {
                                                //$userLoadedImgSrc = wp_get_attachment_image_src($userImg, '600-400-size');
                                                //$userImgSrc = $userLoadedImgSrc[0];
                                            }
                                            echo '<div class="image-placeholder"><img src="' . $userImg . '" class="image-placeholder" id="agent-image" alt="IMAGE NOT FOUND"/></div>'; ?>
                                            <input type="file" name="agent-image" id="agent-image" onChange="readURL(this);">
                                        </div>
                                    </div>
                                </div>
                                <div class="block-heading" id="amenities">
                                    <h4><span class="heading-icon"><i class="fa fa-phone"></i></span><?php esc_html_e('Contact Details', 'framework'); ?></h4>
                                </div>
                                <div class="padding-as25 margin-30 lgray-bg">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('Mobile Phone', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('mobile-phone', $user_ID)); ?>" name="mobile-phone" id="mobile-phone" class="form-control" placeholder="<?php esc_html_e('Mobile Phone', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('Work Phone', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('work-phone', $user_ID)); ?>" name="work-phone" id="work-phone" class="form-control" placeholder="<?php esc_html_e('Work Phone', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-4 col-sm-4">
                                            <label><?php esc_html_e('Fax Number', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('fax-phone', $user_ID)); ?>" name="fax-phone" id="fax-phone" class="form-control" placeholder="<?php esc_html_e('Fax Number', 'framework'); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="block-heading" id="amenities">
                                    <h4><span class="heading-icon"><i class="fa fa-group"></i></span><?php esc_html_e('Social Links', 'framework'); ?></h4>
                                </div>
                                <div class="padding-as25 margin-30 lgray-bg">
                                    <div class="row">
                                        <div class="col-md-3 col-sm-3">
                                            <label><?php esc_html_e('Facebook profile URL', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('fb-link', $user_ID)); ?>" name="fb-link" id="fb-link" class="form-control" placeholder="<?php esc_html_e('Facebook', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <label><?php esc_html_e('Twitter profile URL', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('twt-link', $user_ID)); ?>" name="twt-link" id="twt-link" class="form-control" placeholder="<?php esc_html_e('Twitter', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <label><?php esc_html_e('Google Plus profile URL', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('gp-link', $user_ID)); ?>" name="gp-link" id="gp-link" class="form-control" placeholder="<?php esc_html_e('Google Plus', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <label><?php esc_html_e('Email Address', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('msg-link', $user_ID)); ?>" name="msg-link" id="msg-link" class="form-control" placeholder="<?php esc_html_e('Email Address', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <label><?php esc_html_e('Linkedin Profile URL', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('linkedin-link', $user_ID)); ?>" name="linkedin-link" id="linkedin-link" class="form-control" placeholder="<?php esc_html_e('Linkedin Profile URL', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <label><?php esc_html_e('YouTube Profile URL', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('youtube-link', $user_ID)); ?>" name="youtube-link" id="youtube-link" class="form-control" placeholder="<?php esc_html_e('YouTube Profile URL', 'framework'); ?>">
                                        </div>
                                        <div class="col-md-3 col-sm-3">
                                            <label><?php esc_html_e('Website URL', 'framework'); ?></label>
                                            <input type="text" value="<?php echo esc_attr(get_the_author_meta('website-link', $user_ID)); ?>" name="website-link" id="website-link" class="form-control" placeholder="<?php esc_html_e('Website URL', 'framework'); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="text-align-center" id="submit-property">
                                    <button type="submit" name="submit" class="btn btn-primary btn-lg cus_submit"><i class="fa fa-check"></i><?php esc_html_e(' Update', 'framework'); ?></button>
                                </div>
                            </form>
                        </div>
                        <!-- Start Sidebar -->
                        <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
                            <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
                                <?php dynamic_sidebar($pageSidebar); ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    <?php } else {
    echo imic_unidentified_agent();
}
get_footer(); ?>