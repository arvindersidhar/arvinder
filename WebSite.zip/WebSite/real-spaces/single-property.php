<?php get_header();
$imic_options = get_option('imic_options');
wp_enqueue_script('imic_single_map');
imic_sidebar_position_module();
include_once(ABSPATH . 'wp-admin/includes/plugin.php');
//-- Site Showcase --
imic_singe_property_banner(get_the_ID());
function imic_match_favourite_property($user_id, $property_id)
{
	global $wpdb;
	$table_name = $wpdb->prefix . "favorite_property_search";
	$sql_select = "select property_name from $table_name WHERE `user_name` = '$user_id'";
	$q = $wpdb->get_results($sql_select, ARRAY_A);
	$array_id = array();
	if (!empty($q)) {
		foreach ($q[0] as $data) {
			$array_update = unserialize($data);
			if (!empty($array_update)) {
				foreach ($array_update as $key => $value) {
					array_push($array_id, $key);
				}
			}
		}
	}
	if (in_array($property_id, $array_id)) {
		$output = '<div class ="favorite_information">';
		$output .= '<a href="javascript:void(0);" class="accent-color" style="cursor:default; text-decoration:none;" data-toggle="tooltip" data-original-title="' . esc_html__('In your favorites', 'framework') . '"><i class="fa fa-heart"></i></a>';
		$output .= '</div>';
		return $output;
	} else {
		$output = '<div class ="favorite_information">';
		$output .= '<span class ="favorite"><div class="favorite-strings" style="display:none;"><span class="favorite-title">' . esc_html__('Add to Favourite', 'framework') . '</span><span class="favorite-body">' . esc_html__(' Sending Request To Add this Property ...', 'framework') . '</span><span class="favorite-success">' . esc_html__('In your favorites', 'framework') . '</span></div><a href="#" class="accent-color" style="text-decoration:none;" data-toggle="tooltip" data-original-title="' . esc_html__('Add this property to your favorites', 'framework') . '"><i class="fa fa-heart-o"></i></a></span>';
		$output .= '<span class ="f_author_n" id ="' . $user_id . '"></span>';
		$output .= '<span class ="f_property_n" id ="' . $property_id . '"></span>';
		$output .= '</div>';
		return $output;
	}
}
//-- End Site Showcase --
$currency_decimal_point = (isset($imic_options['currency_decimal_point'])) ? $imic_options['currency_decimal_point'] : '';
$currency_decimal_point = ($currency_decimal_point == '') ? 0 : $currency_decimal_point;
$currency_thousand_separator = (isset($imic_options['currency_thousand_separator'])) ? $imic_options['currency_thousand_separator'] : '';
$currency_decimal_separator = (isset($imic_options['currency_decimal_separator'])) ? $imic_options['currency_decimal_separator'] : '';
$property_type = $property_term_type = '';
$id = get_the_ID();
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
	$ContentWidth = 12 - $imic_options['sidebar_width'];
	$SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
	$ContentWidth = 12 - $pageSidebarWidth;
	$SidebarWidth = $pageSidebarWidth;
}
$pageSidebarDefault = (isset($imic_options['property_sidebar'])) ? $imic_options['property_sidebar'] : '';
$pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar) || !empty($pageSidebarDefault) && is_active_sidebar($pageSidebarDefault)) {
	$class = $ContentWidth;
} else {
	$class = 8;
	$SidebarWidth = 4;
}
$currency_symbol = (isset($imic_options['currency-select'])) ? imic_get_currency_symbol($imic_options['currency-select']) : ''; ?>
<!-- Start Content -->
<div class="main" role="main">
	<div id="content" class="content full">
		<div class="container">
			<div class="row">
				<div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">
					<div class="single-property">
						<?php
						$property_zoom_default = (isset($imic_options['property_map_zoom'])) ? $imic_options['property_map_zoom'] : '';
						$property_zoom_property = get_post_meta(get_the_ID(), 'imic_property_zoom_option', true);
						if ($property_zoom_property != '') {
							$property_zoom_value = $property_zoom_property;
						} elseif ($property_zoom_default != '') {
							$property_zoom_value = $property_zoom_default;
						} else {
							$property_zoom_value = 4;
						}
						echo '<span class ="property_zoom_level" id ="' . $property_zoom_value . '"></span>';
						if (have_posts()) : while (have_posts()) : the_post();
								$this_property_id = get_the_ID();
								$property_area = get_post_meta(get_the_ID(), 'imic_property_area', true);
								$property_baths = get_post_meta(get_the_ID(), 'imic_property_baths', true);
								$property_beds = get_post_meta(get_the_ID(), 'imic_property_beds', true);
								$property_parking = get_post_meta(get_the_ID(), 'imic_property_parking', true);
								$property_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
								$property_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
								$property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
								$property_price = number_format(intval($property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
								$contract = wp_get_object_terms(get_the_ID(), 'property-contract-type', array('fields' => 'ids'));
								$property_area_location = wp_get_object_terms(get_the_ID(), 'city-type');
								$sl = '';
								$total_area_location = count($property_area_location);
								$num = 1;
								foreach ($property_area_location as $sa) {
									$conc = ($num != $total_area_location) ? '->' : '';
									$sl .= $sa->name . $conc;
									$num++;
								}
								$property_longitude_and_latitude = get_post_meta(get_the_ID(), 'imic_lat_long', true);
								if (!empty($property_longitude_and_latitude)) {
									$property_longitude_and_latitude = explode(",", $property_longitude_and_latitude);
								} else {
									$property_longitude_and_latitude = getLongitudeLatitudeByAddress($property_address);
								}
								$src = wp_get_attachment_image_src(get_post_thumbnail_id(), '150-100-size');
								if (!empty($src)) :
									$image_container = '<span class ="property_image_map">' . $src[0] . '</span>';
								else :
									$image_container = '';
								endif;
								echo '<div id="property' . get_the_ID() . '" style="display:none;"><span class ="property_address">' . $property_address . '</span><span class ="property_price"><strong>$</strong> <span> ' . $property_price . '</span></span><span class ="latitude">' . $property_longitude_and_latitude[0] . '</span><span class ="longitude">' . $property_longitude_and_latitude[1] . '</span>' . $image_container . '<span class ="property_url">' . get_permalink(get_the_ID()) . '</span><span class ="property_image_url">' . IMIC_THEME_PATH . '/assets/images/map-marker.png</span></div>';
								if (!empty($contract)) {
									$term = get_term($contract[0], 'property-contract-type');
									$property_term_type = $term->name;
								}
								$contract_type = wp_get_object_terms(get_the_ID(), 'property-type', array('fields' => 'ids'));
								if (!empty($contract_type)) {
									$terms = get_term($contract_type[0], 'property-type');
									$property_type = $terms->slug;
								}
								?>
								<h2 class="page-title"><?php echo get_the_title(); ?>
									<?php if (!empty($property_city)) {
										echo ', <a class="accent-color" data-original-title="' . $sl . '" data-toggle="tooltip" style="cursor:default; text-decoration:none;" href="javascript:void(0);"><span class="location sort_by_location">' . $property_city . '</span></a>';
									} ?></h2>
								<?php if (!empty($property_price)) {
									echo imic_property_price_with_currency($property_price, $currency_symbol);
								}
								?>
								<div class="property-amenities clearfix">
									<?php if (!empty($property_term_type)) { ?><span class="area"><strong><?php esc_html_e('For', 'framework'); ?></strong><?php echo esc_attr($property_term_type); ?></span> <?php } ?>
									<?php if (!empty($property_area)) { ?><span class="area"><strong><?php echo '' . $property_area; ?></strong><?php esc_html_e('Area', 'framework'); ?></span> <?php } ?>
									<?php if (!empty($property_baths)) { ?><span class="baths"><strong><?php echo '' . $property_baths; ?></strong><?php esc_html_e('Baths', 'framework'); ?></span> <?php } ?>
									<?php if (!empty($property_beds)) { ?><span class="beds"><strong><?php echo '' . $property_beds; ?></strong><?php esc_html_e('Beds', 'framework'); ?></span> <?php } ?>
									<?php if (!empty($property_parking)) { ?><span class="parking"><strong><?php echo '' . $property_parking; ?></strong><?php esc_html_e('Parking', 'framework'); ?></span> <?php } ?> <span class="parking">
										<?php if (function_exists('create_favorite_table')) {
											if (is_user_logged_in()) {
												$current_user = wp_get_current_user();
												echo imic_match_favourite_property($current_user->ID, get_the_ID());
											} else {
												echo '<a id="show_login" data-ta rget="#logi n-modal" data-toggle="modal" title="' . esc_html__('Login to Add in Favourite', 'framework') . '">' . esc_html__('Login', 'framework') . '</a>
';
											}
										} ?></span></div>
								<?php $property_sights = get_post_meta(get_the_ID(), 'imic_property_sights', false); ?>
								<div class="property-slider">
									<?php if (!empty($property_sights)) { ?>
										<div id="property-images" class="flexslider">
											<ul class="slides">
												<?php foreach ($property_sights as $property_sight) {
													$image = wp_get_attachment_image_src($property_sight, '600-400-size', ''); ?>
													<li class="item"> <img src="<?php echo esc_url($image[0]); ?>" alt="Image"> </li>
												<?php } ?>
											</ul>
										</div>
										<?php if (count($property_sights) > 1) { ?>
											<div id="property-thumbs" class="flexslider">
												<?php $property_sights = get_post_meta(get_the_ID(), 'imic_property_sights', false); ?>
												<ul class="slides">
													<?php foreach ($property_sights as $property_sight) {
														$image = wp_get_attachment_image_src($property_sight, '600-400-size', ''); ?>
														<li class="item"> <img src="<?php echo esc_url($image[0]); ?>" alt="Image"> </li>
													<?php }
												$author_id = $post->post_author; ?>
												</ul>
											</div><?php }
										} else {
											echo get_the_post_thumbnail(get_the_ID(), '600-400-size');
										} ?>
								</div>
								<?php if (isset($imic_options['switch_sharing']) && $imic_options['switch_sharing'] == 1 && $imic_options['share_post_types']['3'] == '1') {
									imic_share_buttons();
								} ?>
								<?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar) || !empty($pageSidebarDefault) && is_active_sidebar($pageSidebarDefault)) { ?>
									<div class="tabs">
										<ul class="nav nav-tabs">
											<li class="active"> <a data-toggle="tab" href="#description"><?php esc_html_e(' Description ', 'framework'); ?></a> </li>
											<li> <a data-toggle="tab" href="#amenities"><?php esc_html_e(' Additional Amenities ', 'framework'); ?></a> </li>
											<li> <a data-toggle="tab" href="#address"><?php esc_html_e(' Property Details ', 'framework'); ?></a> </li>
										</ul>
										<div class="tab-content">
											<div id="description" class="tab-pane active">
												<?php the_content(); ?>
											</div>
											<div id="amenities" class="tab-pane">
												<div class="additional-amenities">
													<?php
													$amenity_array = array();
													$property_amenities = get_post_meta(get_the_ID(), 'imic_property_amenities', true);
													foreach ($property_amenities as $properties_amenities_temp) {
														if ($properties_amenities_temp != 'Not Selected') {
															array_push($amenity_array, $properties_amenities_temp);
														}
													}
													if (isset($imic_options['properties_amenities']) && count($imic_options['properties_amenities']) > 1) {
														foreach ($imic_options['properties_amenities'] as $properties_amenities) {
															$am_name = strtolower(str_replace(' ', '', $properties_amenities));
															if (in_array($properties_amenities, $amenity_array)) {
																$class = 'available';
															} else {
																$class = 'navailable';
															}
															if (!empty($properties_amenities)) {
																echo '<span class="' . $class . '"><i class="fa fa-check-square"></i> ' . $properties_amenities . '</span>';
															}
														}
													}
													$author_id = $post->post_author;
													?>
												</div>
											</div>
											<div id="address" class="tab-pane">
												<?php imicPropertyDetailById(get_the_ID()); ?>
											</div>
										</div>
									</div>
									<?php
									if (isset($imic_options['enable_agent_details']) && ($imic_options['enable_agent_details'] == 1)) {
										$user_position = get_user_meta($author_id, 'imic_user_position', true);
										$user_position = ($user_position != '') ? $user_position : esc_html__('Agent', 'framework'); ?>
										<h3><?php echo esc_attr($user_position); ?></h3>
										<div class="agent fw-agent-profile sidebar-agent-profile">
											<?php
											$author_id = $post->post_author;
											$userMobileNo = get_the_author_meta('mobile-phone', $author_id);
											$userWorkNo = get_the_author_meta('work-phone', $author_id);
											$userFaxNo = get_the_author_meta('fax-phone', $author_id);
											$agent_image = get_the_author_meta('agent-image', $author_id);
											$userFirstName = get_the_author_meta('first_name', $author_id);
											$userLastName = get_the_author_meta('last_name', $author_id);
											$userNiceName = get_the_author_meta('nicename', $author_id);
											$userName = get_userdata($author_id);
											if (!empty($userFirstName) || !empty($userLastName)) {
												$userName = $userFirstName . ' ' . $userLastName;
											} else {
												$userName = $userName->user_login;
											}
											$description = get_the_author_meta('description', $author_id);
											$userImageID = get_the_author_meta('agent-image', $author_id);
											$post_author_id = get_post_field('post_author', get_the_ID());
											if (!empty($userImageID)) :
												$image_id = imic_get_src_image_id($userImageID);
												$userImage = wp_get_attachment_image_src($image_id, 'medium');
												echo '<img src="' . $userImage[0] . '" alt="Image" class="agent-image"/>';
											else :
												echo '<img src="' . get_template_directory_uri() . '/assets/images/default_agent.png" alt="Image" class="agent-image"/>';
											endif; ?>
											<div class="agent-details">
												<h4 class="margin-0"><a href="<?php echo get_author_posts_url($author_id); ?>"><?php echo esc_attr($userName); ?></a></h4>
												<?php if ($user_position != '') { ?><span class="meta"><?php echo esc_attr($user_position); ?></span><?php } ?>
												<?php if ($userMobileNo != '') { ?><span class="con-info"><i class="fa fa-phone"></i> <?php echo esc_attr($userMobileNo); ?></span><?php } ?>
												<?php if ($userMobileNo != '') { ?><span class="con-info"><i class="fa fa-mobile"></i> <?php echo esc_attr($userMobileNo); ?></span><?php } ?>
												<?php if ($userFaxNo != '') { ?><span class="con-info"><i class="fa fa-fax"></i> <?php echo esc_attr($userFaxNo); ?></span><?php } ?>
												<div class="margin-10"></div>
												<?php echo apply_filters('the_content', $description); ?>
											</div>
											<div class="agent-contacts clearfix">
												<?php $userFB = get_the_author_meta('fb-link', $author_id);
												$userTWT = get_the_author_meta('twt-link', $author_id);
												$userGP = get_the_author_meta('gp-link', $author_id);
												$userMSG = get_the_author_meta('msg-link', $author_id);
												$userLINKEDIN = get_the_author_meta('linkedin-link', $author_id);
												$userYOUTUBE = get_the_author_meta('youtube-link', $author_id);
												$userWEBSITE = get_the_author_meta('website-link', $author_id);
												$userPosition = get_the_author_meta('position', $author_id);
												$userSocialArray = array_filter(array($userFB, $userTWT, $userGP, $userMSG, $userLINKEDIN, $userYOUTUBE, $userWEBSITE));
												$userSocialClass = array('fa-facebook', 'fa-twitter', 'fa-google-plus', 'fa-envelope', 'fa-linkedin', 'fa-youtube', 'fa-globe');
												if (!empty($userSocialArray)) {
													echo '<ul class="pull-left">';
													foreach ($userSocialArray as $key => $value) {
														if (!empty($value) && $userSocialClass[$key] == 'fa-envelope') {
															echo '<li><a href="mailto:' . $value . '" target="_blank"><i class="fa ' . $userSocialClass[$key] . '"></i></a></li>';
														} elseif (!empty($value)) {
															echo '<li><a href="' . $value . '" target="_blank"><i class="fa ' . $userSocialClass[$key] . '"></i></a></li>';
														}
													}
													echo '</ul>';
												} ?>
												<a id="show_login" data-target="#agentmodal" data-toggle="modal" class="btn btn-primary margin-left10"><?php esc_html_e('Contact', 'framework'); ?></a>
												<a href="<?php echo get_author_posts_url($author_id); ?>" class="btn btn-primary"><?php echo esc_html_e('View Profile', 'framework'); ?></a>
											</div>
										</div>
									<?php }
							}
						endwhile;
					endif; ?>
					</div>
					<!-- Start Related Properties -->
					<div id="related-properties-block">
						<?php query_posts(array('post_type' => 'property', 'post_status' => 'publish', 'property-type' => $property_type, 'posts_per_page' => 3, 'post__not_in' => array($this_property_id)));
						if ($wp_query->post_count != 0) { ?>
							<h3><?php esc_html_e('Related Properties', 'framework'); ?></h3>
							<hr>
							<div class="property-grid">
								<ul class="grid-holder col-3">
									<?php
									if (have_posts()) : while (have_posts()) : the_post();
											$property_images = get_post_meta(get_the_ID(), 'imic_property_sights', false);
											$total_images = count($property_images);
											$property_area = get_post_meta(get_the_ID(), 'imic_property_area', true);
											$property_baths = get_post_meta(get_the_ID(), 'imic_property_baths', true);
											$property_beds = get_post_meta(get_the_ID(), 'imic_property_beds', true);
											$property_parking = get_post_meta(get_the_ID(), 'imic_property_parking', true);
											$property_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
											$property_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
											$property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
											$property_price = number_format(intval($property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
											$property_area_location = wp_get_object_terms(get_the_ID(), 'city-type');
											$sl = '';
											$total_area_location = count($property_area_location);
											$num = 1;
											foreach ($property_area_location as $sa) {
												$conc = ($num != $total_area_location) ? '->' : '';
												$sl .= $sa->name . $conc;
												$num++;
											}
											$contract = wp_get_object_terms(get_the_ID(), 'property-contract-type', array('fields' => 'ids'));
											if (!empty($contract)) {
												$term = get_term($contract[0], 'property-contract-type');
											} ?>
											<li class="grid-item type-<?php if (!empty($term)) {
																			echo esc_attr($term->name);
																		} ?>">
												<div class="property-block"> <a href="<?php the_permalink(); ?>" class="property-featured-image"> <?php the_post_thumbnail('600-400-size'); ?> <span class="images-count"><i class="fa fa-picture-o"></i> <?php echo esc_attr($total_images); ?></span> <?php if (!empty($term)) { ?><span class="badges badge-<?php echo esc_attr($term->slug); ?>"><?php echo esc_attr($term->name); ?></span><?php } ?> </a>
													<div class="property-info">
														<h4><a href="<?php the_permalink(); ?>"><?php echo '' . $property_address; ?></a></h4>
														<?php if (!empty($property_city)) {
															echo '<a class="accent-color" data-original-title="' . $sl . '" data-toggle="tooltip" style="cursor:default; text-decoration:none;" href="javascript:void(0);"><span class="location sort_by_location">' . $property_city . '</span></a><br>';
														} ?>
														<?php if (!empty($property_price)) {
															echo imic_property_price_with_currency($property_price, $currency_symbol);
														} ?>
													</div>
													<div class="property-amenities clearfix">
														<?php if (!empty($property_area)) { ?><span class="area"><strong><?php echo '' . $property_area; ?></strong><?php esc_html_e('Area', 'framework'); ?></span> <?php } ?>
														<?php if (!empty($property_baths)) { ?><span class="baths"><strong><?php echo '' . $property_baths; ?></strong><?php esc_html_e('Baths', 'framework'); ?></span> <?php } ?>
														<?php if (!empty($property_beds)) { ?><span class="beds"><strong><?php echo '' . $property_beds; ?></strong><?php esc_html_e('Beds', 'framework'); ?></span> <?php } ?>
														<?php if (!empty($property_parking)) { ?> <span class="parking"><strong><?php echo '' . $property_parking; ?></strong><?php esc_html_e('Parking', 'framework'); ?></span> <?php } ?></div>
												</div>
											</li>
										<?php endwhile;
								endif;
								wp_reset_query(); ?>
								</ul>
							</div>
						<?php } ?>
					</div>
				</div>
				<!-- Start Sidebar -->
				<?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
					<div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>">
						<?php dynamic_sidebar($pageSidebar); ?>
					</div>
				<?php } elseif (!empty($pageSidebarDefault) && is_active_sidebar($pageSidebarDefault)) { ?>
					<div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>">
						<?php dynamic_sidebar($pageSidebarDefault); ?>
					</div>
				<?php } else { ?>
					<div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>">
						<?php get_template_part('loop', 'fw'); ?>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
<!--Favourite Login Form-->
<div id="login-modal" class="modal fade" aria-hidden="true" aria-labelledby="mymodalLabel" role="dialog" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" aria-hidden="true" data-dismiss="modal" type="button">×</button>
				<h4 id="mymodalLabel" class="modal-title"><?php esc_html_e(' Login', 'framework'); ?></h4>
			</div>
			<div class="modal-body">
				<form id="login" action="login" method="post">
					<?php
					$redirect_login = get_post_meta(get_the_ID(), 'imic_login_redirect_options', true);
					$redirect_login = !empty($redirect_login) ? $redirect_login : home_url();
					?>
					<input type="hidden" class="redirect_login" name="redirect_login" value="" />
					<label>Username</label>
					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-user"></i></span>
						<input class="form-control input1" id="loginname" type="text" name="loginname">
					</div>
					<br>
					<label>Password</label>
					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-lock"></i></span>
						<input class="form-control input1" id="password" type="password" name="password">
					</div>
					<div class="checkbox">
						<input type="checkbox" checked="checked" value="true" name="rememberme" id="rememberme" class="checkbox"> <?php esc_html_e('Remember Me!', 'framework'); ?>
					</div>
					<?php echo '<a href="' . imic_get_template_url('template-reset_password.php') . '" title="' . esc_html__('Forgot Password?', 'framework') . '">' . esc_html__('Forgot Password', 'framework') . '</a>'; ?>
					<div class="clearfix margin-20"></div>
					<input class="submit_button btn btn-primary button2" type="submit" value="<?php esc_html_e('Login Now', 'framework'); ?>" name="submit">
					<?php wp_nonce_field('ajax-login-nonce', 'security'); ?><p class="status"></p>
				</form>
			</div>
			<div class="modal-footer">
				<button class="btn btn-default inverted" data-dismiss="modal" type="button">Close</button>
			</div>
		</div>
	</div>
</div>
<!--Contact Agent Form-->
<div id="agentmodal" class="modal fade" aria-hidden="true" aria-labelledby="mymodalLabel" role="dialog" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" aria-hidden="true" data-dismiss="modal" type="button">×</button>
				<h4 id="mymodalLabel" class="modal-title"><?php esc_html_e(' Contact Agent', 'framework'); ?></h4>
			</div>
			<div class="modal-body">
				<div class="agent-contact-form">
					<h4><?php esc_html_e('Contact Agent For ', 'framework'); ?><span class="accent-color"><?php echo get_the_title(); ?></span></h4>
					<form method="post" id="agentcontactform" name="agentcontactform" class="agent-contact-form" action="<?php echo get_template_directory_uri() ?>/mail/agent_contact.php">
						<input type="email" id="email" name="Email Address" class="form-control" placeholder="<?php esc_html_e('Email Address', 'framework'); ?>">
						<textarea name="comments" id="comments" class="form-control" placeholder="<?php esc_html_e('Your message', 'framework'); ?>" cols="10" rows="5"></textarea>
						<input type="hidden" name="image_path" id="image_path" value="<?php echo get_template_directory_uri(); ?>">
						<input id="agent_email" name="agent_email" type="hidden" value="<?php echo get_the_author_meta('user_email', $author_id); ?>">
						<input type="hidden" value="<?php echo get_the_title(); ?>" name="subject" id="subject">
						<button type="submit" class="btn btn-primary pull-right"><?php esc_html_e('Submit', 'framework'); ?></button>
					</form>
				</div>
				<div class="clearfix"></div>
				<div id="message"></div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-default inverted" data-dismiss="modal" type="button">Close</button>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>