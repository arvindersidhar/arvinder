<?php global $author_id;
$imic_options = get_option('imic_options');
$user_position = get_user_meta($author_id, 'imic_user_position', true);
$user_position = ($user_position != '') ? $user_position : esc_html__('Agent', 'framework');
if (isset($imic_options['enable_agent_details']) && ($imic_options['enable_agent_details'] == 1)) { ?>
	<div class="widget">
		<h3 class="widgettitle"><?php esc_html_e('Contact Seller', 'framework'); ?></h3>
		<div class="agent sidebar-agent-profile">
			<?php
			$author_id = $post->post_author;
			$userMobileNo = get_the_author_meta('mobile-phone', $author_id);
			$userWorkNo = get_the_author_meta('work-phone', $author_id);
			$userFaxNo = get_the_author_meta('fax-phone', $author_id);
			$userFirstName = get_the_author_meta('first_name', $author_id);
			$userLastName = get_the_author_meta('last_name', $author_id);
			$userNiceName = get_the_author_meta('nicename', $author_id);
			$userName = get_userdata($author_id);
			if (!empty($userFirstName) || !empty($userLastName)) {
				$userName = $userFirstName . ' ' . $userLastName;
			} else {
				$userName = $userName->user_login;
			}
			$description = get_the_author_meta('description', $author_id);
			$userImageID = get_the_author_meta('agent-image', $author_id);
			$post_author_id = get_post_field('post_author', get_the_ID());
			if (!empty($userImageID)) :
				$image_id = imic_get_src_image_id($userImageID);
				$userImage = wp_get_attachment_image_src($image_id, '80-80-size');
				echo '<img src="' . $userImage[0] . '" alt="Image" class="agent-image">';
			else :
				echo '<img src="' . get_template_directory_uri() . '/assets/images/default_agent.png" alt="Image" class="agent-image">';
			endif; ?>
			<div class="agent-details">
				<h4 class="margin-0"><a href="<?php echo get_author_posts_url($author_id); ?>"><?php echo esc_attr($userName); ?></a></h4>
				<?php if ($user_position != '') { ?><span class="meta"><?php echo esc_attr($user_position); ?></span><?php } ?>
				<?php if ($userWorkNo != '') { ?><span class="con-info"><i class="fa fa-phone"></i> <?php echo esc_attr($userWorkNo); ?></span><?php } ?>
				<?php if ($userMobileNo != '') { ?><span class="con-info"><i class="fa fa-mobile"></i> <?php echo esc_attr($userMobileNo); ?></span><?php } ?>
				<?php if ($userFaxNo != '') { ?><span class="con-info"><i class="fa fa-fax"></i> <?php echo esc_attr($userFaxNo); ?></span><?php } ?>
			</div>
			<div class="margin-10"></div>
			<?php echo apply_filters('the_content', $description); ?>
			<div class="agent-contacts clearfix">
				<?php $userFB = get_the_author_meta('fb-link', $author_id);
				$userTWT = get_the_author_meta('twt-link', $author_id);
				$userGP = get_the_author_meta('gp-link', $author_id);
				$userMSG = get_the_author_meta('msg-link', $author_id);
				$userLINKEDIN = get_the_author_meta('linkedin-link', $author_id);
				$userYOUTUBE = get_the_author_meta('youtube-link', $author_id);
				$userWEBSITE = get_the_author_meta('website-link', $author_id);
				$userPosition = get_the_author_meta('position', $author_id);
				$userSocialArray = array_filter(array($userFB, $userTWT, $userGP, $userMSG, $userLINKEDIN, $userYOUTUBE, $userWEBSITE));
				$userSocialClass = array('fa-facebook', 'fa-twitter', 'fa-google-plus', 'fa-envelope', 'fa-linkedin', 'fa-youtube', 'fa-globe');
				$property_amenities = get_post_meta(get_the_ID(), 'imic_property_amenities', true);
				if (!empty($userSocialArray)) {
					echo '<ul>';
					foreach ($userSocialArray as $key => $value) {
						if (!empty($value) && $userSocialClass[$key] == 'fa-enveloper') {
							echo '<li><a href="mailto:' . $value . '" target="_blank"><i class="fa ' . $userSocialClass[$key] . '"></i></a></li>';
						} elseif (!empty($value)) {
							echo '<li><a href="' . $value . '" target="_blank"><i class="fa ' . $userSocialClass[$key] . '"></i></a></li>';
						}
					}
					echo '</ul>';
				} ?>
				<a href="<?php echo get_author_posts_url($author_id); ?>" class="btn btn-primary margin-right10"><?php echo esc_html_e('View Profile', 'framework'); ?></a><a id="show_login" data-target="#agentmodal" data-toggle="modal" class="btn btn-primary"><?php esc_html_e('Contact', 'framework'); ?></a>
			</div>
		</div>
	</div>
<?php } ?>
<div class="widget">
	<h3 class="widgettitle"><?php esc_html_e('Description', 'framework'); ?></h3>
	<div id="description">
		<?php the_content(); ?>
	</div>
</div>
<?php if (!empty($property_amenities)) {
	$show = 0;
	foreach ($property_amenities as $amenity) {
		if ($amenity != 'Not Selected') {
			$show = 1;
		}
	}
	if ($show == 1) { ?>
		<div class="widget">
			<h3 class="widgettitle"><?php esc_html_e('Additional Amenities', 'framework'); ?></h3>
			<div id="amenities">
				<div class="additional-amenities">
					<?php
					$amenity_array = array();
					foreach ($property_amenities as $properties_amenities_temp) {
						if ($properties_amenities_temp != 'Not Selected') {
							array_push($amenity_array, $properties_amenities_temp);
						}
					}
					if (isset($imic_options['properties_amenities']) && count($imic_options['properties_amenities']) > 1) {
						foreach ($imic_options['properties_amenities'] as $properties_amenities) {
							$am_name = strtolower(str_replace(' ', '', $properties_amenities));
							if (in_array($properties_amenities, $amenity_array)) {
								$class = 'available';
							} else {
								$class = 'navailable';
							}
							if (!empty($properties_amenities)) {
								echo '<span class="' . $class . '"><i class="fa fa-check-square"></i> ' . $properties_amenities . '</span>';
							}
						}
					}
					$author_id = $post->post_author;
					?>
				</div>
			</div>
		</div>
	<?php }
} ?>
<div class="widget">
	<h3 class="widgettitle"><?php esc_html_e('Property Details', 'framework'); ?></h3>
	<div id="address" class="tab-pane">
		<?php imicPropertyDetailById(get_the_ID()); ?>
	</div>
</div>