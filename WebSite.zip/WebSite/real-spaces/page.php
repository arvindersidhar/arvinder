<?php
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
/* Page Banner HTML
=============================*/
imic_page_banner($pageID = get_the_ID());
if (is_home()) {
    $id = get_option('page_for_posts');
} else {
    $id = get_the_ID();
}
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
    $ContentWidth = 12 - $imic_options['sidebar_width'];
    $SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
    $ContentWidth = 12 - $pageSidebarWidth;
    $SidebarWidth = $pageSidebarWidth;
}
$pageSidebarDefault = (isset($imic_options['page_sidebar'])) ? $imic_options['page_sidebar'] : '';
$pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar) || !empty($pageSidebarDefault) && is_active_sidebar($pageSidebarDefault)) {
    $class = $ContentWidth;
} else {
    $class = 12;
} ?>
<!-- Start Content -->
<div class="main" role="main">
    <div id="content" class="content full">
        <div class="container">
            <div class="row">
                <div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">
                    <?php if (have_posts()) : while (have_posts()) : the_post();
                            the_content();
                            if (isset($imic_options['switch_sharing']) && $imic_options['switch_sharing'] == 1 && $imic_options['share_post_types']['2'] == '1') {
                                imic_share_buttons();
                            }
                        endwhile;
                    endif; ?>
                </div>
                <!-- Start Sidebar -->
                <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
                    <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
                        <?php dynamic_sidebar($pageSidebar); ?>
                    </div>
                <?php } elseif (!empty($pageSidebarDefault) && is_active_sidebar($pageSidebarDefault)) { ?>
                    <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
                        <?php dynamic_sidebar($pageSidebarDefault); ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>