<?php
return $change_log = '
04 July 2019 - Version 2.6.1
	UPDATED! RealSpaces Core Plugin
	UPDATED! Demo data
	FIXED! A problem with theme options not working for some users
	FIXED! A bug with agents page template
	FIXED! Fixed addmin tabs not showing for some users after login
	FIXED! Taxonomies registration bug

30 May 2019 - Version 2.6
	NEW! Real Spaces Core plugin to add theme functionality in a separate plugin as per new WP standards
	UPDATED! Demo Importer
	UPDATED! Revolution Slider Plugin
	FIXED! Search not working with province
	FIXED! Theme not getting activated for some users
	FIXED! Price fields not showing correct search results
	FIXED! Some styling bugs
	FIXED! Widgets to support PHP version 7+

04 October 2018 - Version 2.5.1
	FIXED! Missing files for shortcode generator
	FIXED! Map generator in property add page in the backend not working
	FIXED! Global imic_options variable not working in some templates

04 October 2018 - Version 2.5
	NEW! Real Spaces Dashboard added for users to see all things in a single place
	NEW! HTML Template added (Worth $18)
	NEW! Option to add custom property ID
	UPDATED! Demo importer for more seamless one click import
	UPDATED! js conditional loading to improve site speed
	UPDATED! Theme file structure to load all assets from a single location/folder
	UPDATED! Language .pot file
	UPDATED! Revolution Slider Plugin
	UPDATED! Metabox plugins
	UPDATED! Meta boxes to support conditional show hide using official plugin
	UPDATED! Demo data
	UPDATED! Replaced placholder images in demo data with real images
	UPDATED! Custom widgets to support latest version of PHP
	FIXED! Some RTL language stylings
	FIXED! Some styling bugs
	
30 March 2018 - Version 2.4.1
	UPDATED! Revolution Slider plugin
	FIXED! Single property page map location bug
	
06 February 2018 - Version 2.4
	NEW! Option to hide home page search form in mobile devices
	UPDATED! Revolution Slider to latest version
	UPDATED! Ajax city listing in search form
	FIXED! A bug with TGM class while updating/activating bulk plugins
	FIXED! Styling issue with the demo importer

22 June 2017 - Version 2.3.2
	UPDATED! Revolution Slider plugin
	UPDATED! Demo importer to support PHP 7.0
	UPDATED! Theme custom widgets to support PHP 7.0

20 April 2017 - Version 2.3.1
	UPDATED! Demo data
	UPDATED! Currency options list
	UPDATED! Paid property imithemes plugin
	FIXED! Some styling bugs
	FIXED! Map on single property page not displaying for some users

01 April 2017 - Version 2.3
	UPDATED! Revolution Slider plugin to latest version
	UPDATED! Registration form to secure it from spam registration
	NEW! Option to add comma in property values from theme Options > Property Options
	NEW! Success message for front end profile update
	FIXED! LinkedIn URL field in profile page not updating
	NEW! Ajax city list as per the state/province selected

28 January 2017 - Version 2.2
	NEW! List property shortcode
	
10 January, 2017 - Version 2.1
	FIXED! Google Map API not working for back end add property page
	FIXED! Add amenities not working for back end add property page
	NEW! Website, Youtube, Fax fields for user profile
	
06 January, 2017 - Version 2.0.1
	Security Update
	UPDATED! Revolution Slider to latest version
	
14 September, 2016 - Version 2.0
	NEW! Redefined Theme Options panel
	NEW! Page design options
	NEW! Option to set default map zoom level for single property pages
	NEW! Option to set default height for inside page banners
	NEW! Option to add Contact Form 7 form in place of built in form in Contact page template
	NEW! Option to set default sidebar for property single pages
	NEW! Option to set a pricing plan popular/highlighted in the pricing table
	UPDATED! Demo content
	UPDATED! Redux Framework
	UPDATED! Metabox plugin
	UPDATED! Slider Revolution Plugin
	UPDATED! Language .pot file
	UPDATED! Paid property imithemes plugin
	UPDATED! Favorite property plugin
	FIXED! Payment payment return page showing error in transaction ID
	FIXED! Amenities block in full width single property page shows always even if no amenity selected
	FIXED! Profile picture change in front end user profile page not working
	FIXED! Testimonial slider responsive function
	
30 July, 2016 - Version 1.9.4
	FIXED! Google Map API not working for Add new property page in the WP Dashboard
	UPDATED! Metabox plugin
	
16 July, 2016 - Version 1.9.3
	FIXED! Issue with amenities not getting selecting while adding new property from the backend
	FIXED! Agent name and description not getting saved and showing on Agent profile
	FIXED! newly added Google map API field not working for some parts of theme
	FIXED! State/City list not getting generated in the add new property page in the WP Dashboard
	
15 July, 2016 - Version 1.9.2
	NEW! Option to add Google Map API Key at Theme Options
	UPDATED! Revolution Slider to latest version
	UPDATED! favourite property and paid property plugins
	UPDATED! Font Awesome icons to latest version
	UPDATED! Redux framework to latest version
	UPDATED! TGM Plugin Class
	FIXED! Layout problem with related property listing
	
26 April, 2016 - Version 1.9.1
	UPDATED! Revolution Slider to latest version
	UPDATED! Font Awesome Icons to latest version
	UPDATED! Meta Box plugin
	NEW! Thank you message for Newsletter subscript form widget
	FIXED! Grid/List view toggle URLs not working for listing templates
	FIXED! Some styling bugs
	
20 November, 2015 - Version 1.9
	UPDATED! Revolution Slider to latest version 5.1.2
	UPDATED! Revolution Slider will now install as a plugin instead of including as a part of theme
	FIXED! Property ID bug on property post update
	UPDATED! Search filters will use the taxonomy slug now instead of name
	NEW! Option to change all the notification messages like favourite property etc.
	NEW! Option to change the currency symbol position before or after the price
	NEW! Option to add user/agent position which displays at various pages where you see the agent/user name
	UPDATED! On single property page id property sights are available then featured images will not be shown
	UPDATED! Search functionality
	NEW! Link on property details page for the agents all property
	UPDATED! Unique class added for contract type badges which can be styled with custom css
	NEW! Support for Watermark plugin
	
15 July, 2016 - Version 1.9.2
	NEW! Option to add Google Map API Key at Theme Options
	UPDATED! Revolution Slider to latest version
	UPDATED! favourite property and paid property plugins
	UPDATED! Font Awesome icons to latest version
	UPDATED! Redux framework to latest version
	UPDATED! TGM Plugin Class
	FIXED! Layout problem with related property listing
	
26 June, 2015 - Version 1.8
	FIXED! prettyPhoto XSS fix
	NEW! One Click Demo Install feature
	NEW! Google Font Options at Theme Options
	FIXED! Home Latest Properties grid strcuture
	FIXED! Wrong spellings of Spain/States/Cities
	FIXED! Search widgets field options at Theme Options
	UPDATED! Some search form functions
	FIXED! Single property page image size
	NEW! Default Image for agent added
	UPDATED! Email when set a property as favorite
	FIXED! Property payment plans were not working when there is space in the Plan name
	FIXED! Single property page showing State when there is no state is selected
	NEW! LinkedIn Icon for Agent Profile
	FIXED! Amenities tab is like fw template
	FIXED! Some loops bugs
	ADDED! text group field of Redux framework
	FIXED! Popular agents shortcode orderby bug
	FIXED! Page content missing from home page template 2
	NEW! Option to add banner image on single agent pages
	FIXED! Owl carousel arrows bug on single property page
	NEW! Option to set auto scroll for testimonial slider shortcode
	FIXED! Agent Information not getting disabled on Full Width Property page
	FIXED! Few text strings were not getting translated
	FIXED! Theme Options menu position conflicting with some plugins
	FIXED! Some fixes for author.php
	FIXED! Comments strings not getting translated
	FIXED! Forgot password link not working
	NEW! Option to enable property submission for buyers as well
	NEW! Option to set 0 beds, 0 baths, 0 parking on front end listing form page
	FIXED! Comments form not working as no send button was there
	
28 April, 2015 - Version 1.7.1
	UPDATED! Theme framework and included plugins for the XSS vulnerability
	
27 February, 2015 - Version 1.7
	NEW! Custom Messages/Mails options in Theme Options
	NEW! Remove thumbnail of property from front end.
	NEW! Enable/Disable & Required/not required options for fields of submit property in Theme Options
	NEW! Set price range option for search form
	FIXED! Strings of js was not translated while using po file
	FIXED! Menu hides when scrolled on touch devices
	
03 February, 2015 - Version 1.6
	FIXED! Styling bug when top user dropdown is disabled via Theme Options
	UPDATED! functions.php file for some small bugs
	ADDED! Jamaican and Pakistan currency at Theme Options currency selection field
	UPDATED! Paid properties plugin for currency 
	ADDED! Default agent avatar for slider with property 
	FIXED! Styling bug on third level dropdown menu
	NEW! Post/page/property share buttons
	NEW! Option to change header info columns title and icons
	FIXED! Bug on homepage version 1 which shows all property button over carousel next/prev nav
	FIXED! Styling bug with home page search form
	
20 January, 2015 - Version 1.5
	NEW! Testimonial shortcode now allows to show testimonials as carousel
	FIXED! Agent template pagination was not showing all agents.
	NEW! Top Menu or login dropdown selection.
	FIXED! removed static text in pricing tables
	FIXED! Agent Template Profile template
	FIXED! Profile for dealers not showing correct number of properties
	FIXED! Agent’s recent properties permalink
	IMPROVED! Home page search form
	FIXED! Search result page showing no properties when no filter has any value selected
	FIXED! No image for popular agent
	FIXED! Yoast SEO fields not showing for pages.
	IMPROVED! State and city fields list are now interconnected
	
30 December, 2014 - Version 1.4
	FIXED! Home page search form responsive view bugs
	
22 November, 2014 - Version 1.3.0.2
	FIXED! Issue with assigning post thumbnails
	FIXED! Bug with updating user profiles
	
15 November, 2014 - Version 1.3.0.1
	FIXED! dxIDXPress Plugin styling bugs
	
15 November, 2014 - Version 1.3
	NEW! Revolution Slider added for Homepage
	NEW! Paid property listing with paypal payments
	NEW! Option to set if the new added properties will be listed directly or saved as draft
	NEW! Option to assign zoom level for map of each property
	NEW! Ability to make a listing private
	NEW! Administrator ability to change any property’s agent/author
	NEW! Administrator ability to add/change any agent’s profile photo
	NEW! Option to change property IDs wording
	NEW! Option to hide property IDs from listing and grid
	NEW! Ability to change agent’s name while quick editing any property
	NEW! Option to choose RTL language support at Theme Options
	NEW! Added 15 new pattern images for boxed layout
	FIXED! Some style bugs on single property and home page
	FIXED! problem while setting masonry layout blog page as posts page
	FIXED! Property Details not showing dynamic Amenities
	FIXED! Map not working on some servers
	
11 September, 2014 - Version 1.2
	NEW!Custom city and area option
	NEW! Property comparison
	NEW!Custom images/banners slider for homepage
	NEW! Option to show/hide top bar login button, drop down
	NEW! Option to add favicon at Theme Options
	NEW! option to hide/show agent details on property page
	NEW! Change header, footer backgrounds from Theme Options
	NEW! 18 Layered PSD files added
	NEW! Search filters on search results page
	NEW! ability to make properties private
	NEW! Option to choose multiple countries at Theme Options
	NEW! Option to choose map zoom level for each property
	NEW! Add custom amenities from theme options or manage default ones
	UPDATED! now map will be set as default property banner
	UPDATED! All search fields option added for search form widget with option to add/remove fields and drag drop positioning
	UPDATED! Agent details can be edited from wp-admin as well
	UPDATED! manage/add amenities to property from wp-admin
	FIXED! Small styling issues
	FIXED! Performance enhancement for smart phones
	FIXED! Colombian Pesos currency symbol problem
	
09 August, 2014 - Version 1.1
	NEW! Option to choose user type at Register page
	NEW! Add to favourite option for properties
	NEW! Save search for future reference
	NEW! Enable/Disable search form fields for home page search form
	NEW! Email notification to users when they add property to favourites
	NEW! Agent contact form on single property page for easy enquiry
	NEW! Agent details editing for admin from wp-admin
	NEW! Added option to search property by property id, postal code, address
	NEW! Added Boxed version with patterns
	NEW! Modal popup box on add property page after submission
	UPDATED! Removed image dimension restriction from add property page
	UPDATED! Removed image dimension restriction from agent profile page
	UPDATED! Changed wording draft to pending review on agent properties page 
	FIXED! Agent logged out after registering, now ill be logged in
	FIXED! A bug for zoom map on single property page
	
29 July, 2014 - Version 1.0.1
	UPDATED! Countries and city/states list
	
19 July 2014 - Version 1.0
	INITIAL RELEASE
';