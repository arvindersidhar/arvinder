<?php
/* Template Name: Contact */
get_header();
wp_enqueue_script('imic_single_map');
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
/* Site Showcase */
imic_page_banner($pageID = get_the_ID());
/* End Site Showcase */
$id = get_the_ID();
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
  $ContentWidth = 12 - $imic_options['sidebar_width'];
  $SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
  $ContentWidth = 12 - $pageSidebarWidth;
  $SidebarWidth = $pageSidebarWidth;
}
$pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
  $class = $ContentWidth;
} else {
  $class = 12;
}
?>
<!-- Start Content -->
<div class="main" role="main">
  <div id="content" class="content full">
    <?php $property_zoom_value = get_post_meta(get_the_ID(), 'imic_contact_zoom_option', true);
    $property_zoom_value = !empty($property_zoom_value) ? $property_zoom_value : 4;
    echo '<span class ="property_zoom_level" id ="' . $property_zoom_value . '"></span>'; ?>
    <div class="container">
      <div class="page">
        <div class="row">
          <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
            <div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">
            <?php } else { ?>
              <div class="col-md-6 col-sm-6">
              <?php }
            $FormShortcode = get_post_meta(get_the_ID(), 'imic_form_shortcode', true);
            ?>
              <?php if ($FormShortcode != '') { ?>
                <?php echo do_shortcode($FormShortcode); ?>
              <?php } else { ?>
                <h3><?php esc_html_e('Quick Contact Form', 'framework'); ?></h3>
                <div class="row">
                  <?php
                  /* Contact Form Details
				=================================*/
                  $contactFormEmailAdd = get_post_meta(get_the_ID(), 'imic_contact_email_us', true);
                  $contactFormSubjectText = get_post_meta(get_the_ID(), 'imic_contact_subject', true);
                  $contactFormEmail = (!empty($contactFormEmailAdd)) ? $contactFormEmailAdd : get_option('admin_email');
                  $contactFormSubject = (!empty($contactFormSubjectText)) ? $contactFormSubjectText : esc_html__('Contact Form', 'framework');
                  ?>
                  <form method="post" id="contactform" name="contactform" class="contact-form" action="<?php echo get_template_directory_uri() ?>/mail/contact.php">
                    <div class="col-md-6 margin-15">
                      <div class="form-group">
                        <input type="text" id="name" name="name" class="form-control input-lg" placeholder="<?php esc_html_e('Name*', 'framework'); ?>">
                      </div>
                      <div class="form-group">
                        <input type="email" id="email" name="email" class="form-control input-lg" placeholder="<?php esc_html_e('Email*', 'framework'); ?>">
                      </div>
                      <div class="form-group">
                        <input type="text" id="phone" name="phone" class="form-control input-lg" placeholder="<?php esc_html_e('Phone', 'framework'); ?>">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <textarea cols="6" rows="5" id="comments" name="comments" class="form-control input-lg" placeholder="<?php esc_html_e('Message', 'framework'); ?>"></textarea>
                        <input type="hidden" name="image_path" id="image_path" value="<?php echo IMIC_THEME_PATH; ?>/">
                        <input id="admin_email" name="admin_email" type="hidden" value="<?php echo esc_attr($contactFormEmail); ?>">
                        <input id="subject" name="subject" type="hidden" value="<?php echo esc_attr($contactFormSubject); ?>">
                        <input id="submit" name="submit" type="submit" class="btn btn-primary btn-lg btn-block" value="<?php esc_html_e('Submit now!', 'framework'); ?>">
                      </div>
                    </div>
                  </form>
                </div>
                <div class="clearfix"></div>
                <div id="message"></div>
              <?php } ?>
              <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
                <div class="margin-40"></div>
              <?php } else { ?>
              </div>
              <div class="col-md-6 col-sm-6">
              <?php } ?>

              <h3><?php esc_html_e('Our Location', 'framework'); ?></h3>
              <div class="padding-as25 lgray-bg">
                <?php
                /* Contact Page Details
		 			=================================*/
                $address = '';
                $address_for_map = get_post_meta(get_the_ID(), 'imic_our_location_address', true);
                if (have_posts()) : while (have_posts()) : the_post();
                    the_content();
                  endwhile;
                endif;

                $property_longitude_and_latitude = get_post_meta(get_the_ID(), 'imic_contact_lat_long', true);
                if (!empty($property_longitude_and_latitude)) {
                  $property_longitude_and_latitude = explode(',', $property_longitude_and_latitude);
                } else {
                  $property_longitude_and_latitude = getLongitudeLatitudeByAddress($address_for_map);
                }
                echo '<div id="contact' . get_the_ID() . '" class ="property_container" style="display:none;"><span class ="property_address">' . $address_for_map . '</span><span class ="latitude">' . $property_longitude_and_latitude[0] . '</span><span class ="longitude">' . $property_longitude_and_latitude[1] . '</span><span class ="property_image_url">' . IMIC_THEME_PATH . '/assets/images/map-marker.png</span></div>';
                ?>
              </div>
              <?php if (isset($imic_options['switch_sharing']) && $imic_options['switch_sharing'] == 1 && $imic_options['share_post_types']['2'] == '1') {
                imic_share_buttons();
              } ?>

              <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
                <div class="clearfix">
                <?php } else { ?>
                </div>
              <?php } ?>

            </div>
            <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
            </div>
          <?php } ?>
          <!-- Start Sidebar -->
          <?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
            <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
              <?php dynamic_sidebar($pageSidebar); ?>
            </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
  <?php get_footer(); ?>