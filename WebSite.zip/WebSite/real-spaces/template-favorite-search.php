<?php
/* Template Name: Saved Searches */
get_header();
imic_sidebar_position_module();
$imic_options = get_option('imic_options');
global $current_user; //Theme Global Variable
include_once(ABSPATH . 'wp-admin/includes/plugin.php');
if (function_exists('create_favorite_table')) {
	if (is_user_logged_in()) {
		/* Site Showcase */
		imic_page_banner($pageID = get_the_ID());
		/* End Site Showcase */
		$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		$currency_symbol = (isset($imic_options['currency-select'])) ? imic_get_currency_symbol($imic_options['currency-select']) : '';
		wp_get_current_user();
		$edit_url = imic_get_template_url('template-submit-property.php');
		$id = get_the_ID();
		if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
			$ContentWidth = 12 - $imic_options['sidebar_width'];
			$SidebarWidth = $imic_options['sidebar_width'];
		}
		$pageSidebarWidth = get_post_meta($id, 'imic_select_sidebar_width', true);
		if ($pageSidebarWidth != '') {
			$ContentWidth = 12 - $pageSidebarWidth;
			$SidebarWidth = $pageSidebarWidth;
		}
		$pageSidebar = get_post_meta($id, 'imic_select_sidebar_from_list', true);
		if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
			$class = $ContentWidth;
		} else {
			$class = 12;
		}
		?>
		<!-- Start Content -->
		<div class="main" role="main">
			<div id="content" class="content full">
				<div class="container">
					<div class="page">
						<div class="row">
							<div class="col-md-<?php echo esc_attr($class); ?>" id="content-col">

								<?php if (have_posts()) : while (have_posts()) : the_post();
										the_content();
									endwhile;
								endif; ?>

								<div class="block-heading" id="details">
									<h4><span class="heading-icon"><i class="fa fa-search"></i></span><?php esc_html_e('Saved Searches', 'framework'); ?></h4>
								</div>
								<?php global $wpdb;
								$table_name = $wpdb->prefix . "favorite_property_search";
								$current_id =  get_the_ID();
								$sql_select = "select search_name from $table_name WHERE `user_name` = '$current_user->ID'";
								$q = $wpdb->get_results($sql_select, ARRAY_A);
								if (!empty($q)) : ?>
									<div class="properties-table">
										<span id="<?php echo esc_attr($current_user->ID); ?>" class="f_author_n"></span>
										<table class="table table-striped">
											<thead>
												<tr>
													<th><?php esc_html_e('S.No', 'framework'); ?></th>
													<th><?php esc_html_e('Search Name', 'framework'); ?></th>
													<th><?php esc_html_e('Actions', 'framework'); ?></th>
												</tr>
											</thead>
											<tbody>
												<?php
												foreach ($q[0] as $data) {
													$array_update = unserialize($data);
													if (!empty($array_update)) {
														$i = 1;
														foreach ($array_update as $key => $value) {
															?>
															<tr>
																<td>
																	<?php echo '' . $i; ?>
																</td>
																<td><a href="<?php echo '' . $key; ?>" target="_blank"><?php echo '' . $value; ?></a></td>
																<td>
																	<a id="<?php echo '' . $key; ?>" class="remove-search action-button">
																		<div class="search-strings" style="display:none;"><span class="search-title"><?php esc_html_e(' Removing ...', 'framework'); ?></span></div><i class="fa fa-times"></i><span><?php esc_html_e('Remove', 'framework'); ?><span>
																	</a>
																	<a href="<?php echo '' . $key; ?>" target="_blank" class="action-button"><i class="fa fa-search"></i><span><?php esc_html_e('Search', 'framework'); ?><span></a></td>
															</tr>
															<?php $i++;
														}
													}
												} ?>
											</tbody>
										</table>
									</div>
								<?php
							else :
								echo '<h3>' . esc_html__("You do not have any Saved Search", 'framework') . '</h3>';
							endif; ?>
							</div>
							<!-- Start Sidebar -->
							<?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
								<div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
									<?php dynamic_sidebar($pageSidebar); ?>
								</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php } else {
	echo imic_unidentified_agent();
}
}
get_footer(); ?>