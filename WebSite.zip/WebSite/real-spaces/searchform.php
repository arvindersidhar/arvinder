 <form method="get" id="searchform" action="<?php echo home_url(); ?>/">
            <div class="input-group input-group-lg">
            <input type="text" class="form-control" name="s" id="s" value="" />
            <span class="input-group-btn">
            <button type ="submit" name ="submit" class="btn btn-primary"><i class="fa fa-search fa-lg"></i></button>
            </span> </div>
 </form>
