<!DOCTYPE HTML>
<html <?php language_attributes(); ?> class="no-js">

<head>
	<?php
	$imic_options = get_option('imic_options');
	$bodyClass = (isset($imic_options['site_layout']) && $imic_options['site_layout'] == 'boxed') ? ' boxed' : '';
	$style = '';
	if (isset($imic_options['site_layout']) && $imic_options['site_layout'] == 'boxed') {
		if (!empty($imic_options['upload-repeatable-bg-image']['id'])) {
			$style = ' style="background-image:url(' . $imic_options['upload-repeatable-bg-image']['url'] . '); background-repeat:repeat; background-size:auto;"';
		} else if (!empty($imic_options['full-screen-bg-image']['id'])) {
			$style = ' style="background-image:url(' . $imic_options['full-screen-bg-image']['url'] . '); background-repeat: no-repeat; background-size:cover;"';
		} else if (!empty($imic_options['repeatable-bg-image'])) {
			$style = ' style="background-image:url(' . get_template_directory_uri() . '/assets/images/patterns/' . $imic_options['repeatable-bg-image'] . '); background-repeat:repeat; background-size:auto;"';
		}
	} ?>
	<!-- Basic Page Needs
  ================================================== -->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta charset="<?php bloginfo('charset'); ?>" />
	<?php $switch_responsive = (isset($imic_options['switch-responsive'])) ? $imic_options['switch-responsive'] : '';
	$switch_zoom_pinch = (isset($imic_options['switch-zoom-pinch'])) ? $imic_options['switch-zoom-pinch'] : '';
	if ($switch_responsive == 1) { ?>
		<?php if ($switch_zoom_pinch == 1) { ?>
			<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0">
		<?php } else { ?>
			<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
		<?php } ?>
		<meta name="format-detection" content="telephone=no">
	<?php }  ?>
	<!--// PINGBACK & FAVICON //-->
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php if (function_exists('wp_site_icon') && has_site_icon()) {
		echo '<link rel="shortcut icon" href="' . get_site_icon_url() . '" />';
	} else {
		if (isset($imic_options['custom_favicon']) && $imic_options['custom_favicon'] != "") { ?>
			<link rel="shortcut icon" href="<?php echo esc_url($imic_options['custom_favicon']['url']); ?>" /><?php
		}
	} if (isset($imic_options['iphone_icon']) && $imic_options['iphone_icon'] != "") { ?>
		<link rel="apple-touch-icon-precomposed" href="<?php echo esc_url($imic_options['iphone_icon']['url']); ?>"><?php
		}
																																																						if (isset($imic_options['iphone_icon_retina']) && $imic_options['iphone_icon_retina'] != "") { ?>
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo esc_url($imic_options['iphone_icon_retina']['url']); ?>"><?php
																																																																		}
																																																																		if (isset($imic_options['ipad_icon']) && $imic_options['ipad_icon'] != "") { ?>
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo esc_url($imic_options['ipad_icon']['url']); ?>"><?php
																																																												}
																																																												if (isset($imic_options['ipad_icon_retina']) && $imic_options['ipad_icon_retina'] != "") { ?>
		<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo esc_url($imic_options['ipad_icon_retina']['url']); ?>"><?php
																																																																	} ?>
	<?php
	$space_beforeheader = (isset($imic_options['space-before-head'])) ? $imic_options['space-before-head'] : '';
	echo '' . $space_beforeheader;
	?>
	<?php wp_head();
	?>
</head>
<?php
$header_style = '';
if (isset($imic_options['header_background_color']) && !empty($imic_options['header_background_color'])) {
	$header_style = 'style="background-color: ' . $imic_options['header_background_color'] . '"';
}
if (is_page_template('template-home.php') || is_page_template('template-home-second.php')) {
	$home_class = 'home';
} else {
	$home_class = '';
} ?>

<body <?php body_class($home_class . ' ' . $bodyClass);
			echo '' . $style; ?>>
	<?php
	// Page Style Options
	if (is_home()) {
		$id = get_option('page_for_posts');
	} else {
		$id = get_the_ID();
	}
	$content_top_padding = get_post_meta($id, 'imic_content_padding_top', true);
	$content_bottom_padding = get_post_meta($id, 'imic_content_padding_bottom', true);
	$content_width = get_post_meta($id, 'imic_content_width', true);
	$page_header_show = get_post_meta($id, 'imic_page_header_show_hide', true);
	$page_header_show1 = get_post_meta($id, 'imic_page_header_show_hide1', true);
	$page_header_show2 = get_post_meta($id, 'imic_page_header_show_hide2', true);
	$page_social_show = get_post_meta($id, 'imic_pages_social_show', true);
	$page_title_show = get_post_meta($id, 'imic_pages_title_show', true);
	$page_body_bg_color = get_post_meta($id, 'imic_pages_body_bg_color', true);
	$page_body_bg_image = get_post_meta($id, 'imic_pages_body_bg_image', true);
	$page_body_bg_image_src = wp_get_attachment_image_src($page_body_bg_image, 'full', '', array());
	$page_body_bg_size = get_post_meta($id, 'imic_pages_body_bg_wide', true);
	if ($page_body_bg_size == 0) {
		$page_body_bg_size_result = 'auto';
		$page_body_bg_size_attachment = 'scroll';
	} else {
		$page_body_bg_size_result = 'cover';
		$page_body_bg_size_attachment = 'fixed';
	}
	$page_body_bg_repeat = get_post_meta($id, 'imic_pages_body_bg_repeat', true);
	$page_content_bg_color = get_post_meta($id, 'imic_pages_content_bg_color', true);
	$page_content_bg_image = get_post_meta($id, 'imic_pages_content_bg_image', true);
	$page_content_bg_image_src = wp_get_attachment_image_src($page_content_bg_image, 'full', '', array());
	$page_content_bg_size = get_post_meta($id, 'imic_pages_content_bg_wide', true);
	if ($page_content_bg_size == 0) {
		$page_content_bg_size_result = 'auto';
		$page_content_bg_size_attachment = 'scroll';
	} else {
		$page_content_bg_size_result = 'cover';
		$page_content_bg_size_attachment = 'fixed';
	}
	$page_content_bg_repeat = get_post_meta($id, 'imic_pages_content_bg_repeat', true);

	echo '<style type="text/css">';
	if ($page_header_show == 2) {
		echo '.site-showcase{display:none;}';
	} else {
		echo '.site-showcase{display:block;}';
	}
	if (is_singular('property')) {
		if ($page_header_show2 == 2) {
			echo '.site-showcase{display:none;}';
		} else {
			echo '.site-showcase{display:block;}';
		}
	}
	if (is_front_page()) {
		if ($page_header_show1 == 2) {
			echo '.site-showcase{display:none;}';
		} else {
			echo '.site-showcase{display:block;}';
		}
	}
	if ($page_social_show == 2) {
		echo '.share-bar{display:none;}';
	} else {
		echo '.share-bar{display:block;}';
	}
	if ($page_title_show == 2) {
		echo '.page-header h1{display:none;}';
	} else {
		echo '.page-header h1{display:block;}';
	}
	echo '.content{';
	if ($content_top_padding != '') {
		echo 'padding-top:' . esc_attr($content_top_padding) . 'px;';
	}
	if ($content_bottom_padding != '') {
		echo 'padding-bottom:' . esc_attr($content_bottom_padding) . 'px;';
	}
	echo '}';
	if ($content_width != '') {
		echo '
		.content .container{
			width:' . esc_attr($content_width) . ';
		}';
	}
	echo 'body.boxed{';
	if ($page_body_bg_color != '') {
		echo 'background-color:' . esc_attr($page_body_bg_color) . ';';
	}
	if ($page_body_bg_image != '') {
		echo 'background-image:url(' . esc_attr($page_body_bg_image_src[0]) . ')!important;';
	}
	if ($page_body_bg_image != '') {
		echo 'background-size:' . esc_attr($page_body_bg_size_result) . '!important;';
	}
	if ($page_body_bg_image != '') {
		echo 'background-repeat:' . esc_attr($page_body_bg_repeat) . '!important;';
	}
	if ($page_body_bg_image != '') {
		echo 'background-attachment:' . esc_attr($page_body_bg_size_attachment) . '!important;';
	}
	echo '}
		.content{';
	if ($page_content_bg_color != '') {
		echo 'background-color:' . esc_attr($page_content_bg_color) . ';';
	}
	if ($page_content_bg_image != '') {
		echo 'background-image:url(' . esc_attr($page_content_bg_image_src[0]) . ');';
	}
	if ($page_content_bg_image != '') {
		echo 'background-size:' . esc_attr($page_content_bg_size_result) . ';';
	}
	if ($page_content_bg_image != '') {
		echo 'background-repeat:' . esc_attr($page_content_bg_repeat) . ';';
	}
	if ($page_content_bg_image != '') {
		echo 'background-attachment:' . esc_attr($page_content_bg_size_attachment) . ';';
	}
	echo '}';
	echo '</style>';
	?>
	<div class="body">
		<!-- Start Site Header -->
		<header class="site-header" <?php echo '' . $header_style; ?>>
			<?php
			$menu_locations = get_nav_menu_locations();
			?>
			<div class="top-header">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-sm-6">
							<?php if (isset($imic_options['enable-top-header-login-dropdown']) && $imic_options['enable-top-header-login-dropdown'] == 1) { ?>
								<ul class="horiz-nav pull-left">
									<li class="dropdown">
										<?php
										if (is_user_logged_in()) {
											global $current_user;
											wp_get_current_user();

											/* Display Current Agent Options
						=========================================*/
											echo '<a data-toggle="dropdown">
			                	<i class="fa fa-user"></i> ';
											if (!empty($current_user->user_firstname)) {
												echo esc_attr($current_user->user_firstname);
											} else {
												echo esc_attr($current_user->user_login);
											}
											echo '	<b class="caret"></b>
                			  </a>';
										} else {
											//Agent login page link
											$agent_register_url = imic_get_template_url('template-register.php');

											/* Display Agent Login Options
						=========================================*/
											echo '<a href="' . $agent_register_url . '">
			                	<i class="fa fa-user"></i>'
												. esc_html__(' Login ', 'framework') .
												'</a>';
										}

										/* Current Agent Options
				=========================================*/
										global $current_user; // Use global
										wp_get_current_user(); // Make sure global is set, if not set it.
										if ((user_can($current_user, "agent")) || (user_can($current_user, "administrator"))) { ?>
											<ul class="dropdown-menu">
												<?php
												//Agent Profile page link
												$agent_properties = imic_get_template_url('template-agent-properties.php');
												$add_property = imic_get_template_url('template-submit-property.php');
												echo '<li><a href="' . $agent_properties . '">' . esc_html__('My properties', 'framework') . '</a></li>';
												?>
												<li><a href="<?php echo esc_url($add_property); ?>"><?php esc_html_e('Add a property', 'framework'); ?></a></li>
												<?php
												$agent_favourite_properties = imic_get_template_url('template-favorite-properties.php');
												echo '<li><a href="' . $agent_favourite_properties . '" title="' . esc_html__('Favorite Properties', 'framework') . '">' . esc_html__('Favorite Properties', 'framework') . '</a></li>';
												$agent_favourite_searches = imic_get_template_url('template-favorite-search.php');
												echo '<li><a href="' . $agent_favourite_searches . '" title="' . esc_html__('Saved Searches', 'framework') . '">' . esc_html__('Saved Searches', 'framework') . '</a></li>';
												//Agent Profile page link
												$agent_profile = imic_get_template_url('template-agent-profile.php');
												echo '<li class="register"><a href="' . $agent_profile . '" title="' . esc_html__('My Profile', 'framework') . '">' . esc_html__('My Profile', 'framework') . '</a></li>';
												?>
												<li class="login"><a href="<?php echo wp_logout_url(home_url()); ?>" title="<?php esc_html_e('Logout', 'framework'); ?>"><?php esc_html_e('Logout', 'framework'); ?></a></li>
											</ul>
										<?php } else { ?>
											<ul class="dropdown-menu">
												<?php
												$add_property = imic_get_template_url('template-submit-property.php');
												$agent_favourite_properties = imic_get_template_url('template-favorite-properties.php');
												echo '<li><a href="' . $agent_favourite_properties . '" title="' . esc_html__('Favorite Properties', 'framework') . '">' . esc_html__('Favorite Properties', 'framework') . '</a></li>';
												if (isset($imic_options['buyer_rights']) && $imic_options['buyer_rights'] == 1) {
													echo '<li><a href="' . $add_property . '">' . esc_html__('Add a property', 'framework') . '</a></li>';
												}
												$agent_favourite_searches = imic_get_template_url('template-favorite-search.php');
												echo '<li><a href="' . $agent_favourite_searches . '" title="' . esc_html__('Saved Searches', 'framework') . '">' . esc_html__('Saved Searches', 'framework') . '</a></li>';
												//Agent Profile page link
												$agent_profile = imic_get_template_url('template-agent-profile.php');
												echo '<li class="register"><a href="' . $agent_profile . '" title="' . esc_html__('My Profile', 'framework') . '">' . esc_html__('My Profile', 'framework') . '</a></li>';
												?>
												<li class="login"><a href="<?php echo wp_logout_url(home_url()); ?>" title="<?php esc_html_e('Logout', 'framework'); ?>"><?php esc_html_e('Logout', 'framework'); ?></a></li>
											</ul>
										<?php } ?>
									</li>
								</ul>
							<?php } else {
							if (!empty($menu_locations['top-menu'])) {
								wp_nav_menu(array('theme_location' => 'top-menu', 'menu_class' => 'sf-menu', 'container' => '', 'items_wrap' => '<ul id="%1$s" class="horiz-nav pull-left">%3$s</ul>', 'walker' => new My_Walker_Nav_Menu()));
							}
						} ?>
						</div>
						<div class="col-md-8 col-sm-6">
							<ul class="horiz-nav pull-right">
								<?php
								/* Display Top Bar Social Links
				=======================================*/
								$socialSites = (isset($imic_options['top_social_links'])) ? $imic_options['top_social_links'] : array();
								if (!empty($socialSites)) {
									foreach ($socialSites as $key => $value) {
										$string = substr($key, 3);
										if (filter_var($value, FILTER_VALIDATE_EMAIL)) {
											echo '<li><a href="mailto:' . $value . '" target="_blank"><i class="fa fa-' . $string . '"></i></a></li>';
										}
										if (filter_var($value, FILTER_VALIDATE_URL)) {
											echo '<li><a href="' . $value . '" target="_blank"><i class="fa fa-' . $string . '"></i></a></li>';
										} elseif ($key == 'fa-skype' && $value != '' && $value != 'Enter Skype ID') {
											echo '<li><a href="skype:' . $value . '?call" target="_blank"><i class="fa fa-' . $string . '"></i></a></li>';
										}
									}
								} ?>
							</ul>

						</div>
					</div>
				</div>
			</div>

			<div class="middle-header">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-sm-8 col-xs-8">
							<h1 class="logo">
								<?php
								/* Display Site Logo
				==========================*/
								if (isset($imic_options['logo_upload']) && !empty($imic_options['logo_upload']['url'])) {
									echo '<a href="' . esc_url(home_url('/')) . '" title="' . get_bloginfo('name') . '" class="default-logo"><img src="' . $imic_options['logo_upload']['url'] . '" alt="' . get_bloginfo('name') . '"></a>';
								} else {
									echo '<a href="' . esc_url(home_url('/')) . '" title="' . get_bloginfo('name') . '" class="default-logo theme-blogname">' . get_bloginfo('name') . '<br><em>' . get_bloginfo('description') . '</em></a>';
								}
								?>
								<?php
								if (isset($imic_options['retina_logo_upload']) && !empty($imic_options['retina_logo_upload']['url'])) {
									echo '<a href="' . esc_url(home_url('/')) . '" title="' . get_bloginfo('name') . '" class="retina-logo"><img src="' . esc_url($imic_options['retina_logo_upload']['url']) . '" alt="' . get_bloginfo('name') . '" width="' . $imic_options['retina_logo_width'] . '" height="' . $imic_options['retina_logo_height'] . '"></a>';
								} elseif (isset($imic_options['logo_upload']) && !empty($imic_options['logo_upload']['url'])) {
									echo '<a href="' . esc_url(home_url('/')) . '" title="' . get_bloginfo('name') . '" class="retina-logo"><img src="' . esc_url($imic_options['logo_upload']['url']) . '" alt="' . get_bloginfo('name') . '" width="' . $imic_options['retina_logo_width'] . '" height="' . $imic_options['retina_logo_height'] . '"></a>';
								} else {
									echo '<a href="' . esc_url(home_url('/')) . '" title="' . get_bloginfo('name') . '" class="retina-logo theme-blogname">' . get_bloginfo('name') . '<br><em>' . get_bloginfo('description') . '</em></a>';
								} ?>
							</h1>
						</div>
						<div class="col-md-8 col-sm-4 col-xs-4">
							<div class="contact-info-blocks hidden-sm hidden-xs">
								<?php
								/* Display Header Content Info Block
				===========================================*/
								if (isset($imic_options['header_free_line_icon']) && $imic_options['header_free_line_icon'] != '') {
									$hinfo1icon = $imic_options['header_free_line_icon'];
								}
								if (isset($imic_options['header_email_us_icon']) && $imic_options['header_email_us_icon'] != '') {
									$hinfo2icon = $imic_options['header_email_us_icon'];
								}
								if (isset($imic_options['header_working_hours_icon']) && $imic_options['header_working_hours_icon'] != '') {
									$hinfo3icon = $imic_options['header_working_hours_icon'];
								}

								if (isset($imic_options['header_free_line_title']) && $imic_options['header_free_line_title'] != '') {
									$hinfo1title = $imic_options['header_free_line_title'];
								}
								if (isset($imic_options['header_email_us_title']) && $imic_options['header_email_us_title'] != '') {
									$hinfo2title = $imic_options['header_email_us_title'];
								}
								if (isset($imic_options['header_working_hours_title']) && $imic_options['header_working_hours_title'] != '') {
									$hinfo3title = $imic_options['header_working_hours_title'];
								}

								if (isset($imic_options['header_free_line']) && $imic_options['header_free_line'] != '') {
									echo '<div>
							<i class="fa fa-' . $hinfo1icon . '"></i> ' . $hinfo1title . '
							<span>' . $imic_options['header_free_line'] . '</span>
						  </div>';
								}
								if (isset($imic_options['header_email_us']) && $imic_options['header_email_us'] != '') {
									echo '<div>
							<i class="fa fa-' . $hinfo2icon . '"></i> ' . $hinfo2title . '
							<span>' . $imic_options['header_email_us'] . '</span>
						  </div>';
								}
								if (isset($imic_options['header_working_hours']) && $imic_options['header_working_hours'] != '') {
									echo '<div>
							<i class="fa fa-' . $hinfo3icon . '"></i> ' . $hinfo3title . '
							<span>' . $imic_options['header_working_hours'] . '</span>
						  </div>';
								}
								?>
							</div>
							<a href="#" class="visible-sm visible-xs menu-toggle"><i class="fa fa-bars"></i></a>
						</div>
					</div>
				</div>
			</div>
			<?php  ?>
			<div class="main-menu-wrapper">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<nav class="navigation">
								<?php if (!empty($menu_locations['primary-menu'])) {
									/* Display Header Primary Menu
			  ===========================================*/
									wp_nav_menu(array('theme_location' => 'primary-menu', 'menu_class' => 'sf-menu', 'container' => '')); ?> <?php } else {
																																																														echo '<ul class="sf-menu sf-js-enabled">';
																																																														wp_list_pages('number=8&title_li=');
																																																														echo '</ul>';
																																																													} ?>
							</nav>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- End Site Header -->