<?php
/*
  Template Name: Home Second
 */
get_header();
imic_sidebar_position_module();
/* Hero Slider Options
===========================*/
$imic_options = get_option('imic_options');
global $author_id;
$currency_decimal_point = (isset($imic_options['currency_decimal_point'])) ? $imic_options['currency_decimal_point'] : '';
$currency_decimal_point = ($currency_decimal_point == '') ? 0 : $currency_decimal_point;
$currency_thousand_separator = (isset($imic_options['currency_thousand_separator'])) ? $imic_options['currency_thousand_separator'] : '';
$currency_decimal_separator = (isset($imic_options['currency_decimal_separator'])) ? $imic_options['currency_decimal_separator'] : '';
$currency_symbol = imic_get_currency_symbol($imic_options['currency-select']);
if (is_home() && !empty($page_for_posts)) {
    $homeID = $page_for_posts;
} else {
    $homeID = get_the_ID();
}
$autoSlide = get_post_meta($homeID, 'imic_slider_auto_slide', true);
$sliderArrows = get_post_meta($homeID, 'imic_slider_direction_arrows', true);
$sliderEffect = get_post_meta($homeID, 'imic_slider_effects', true);
?>
<!-- Site Showcase -->
<div class="site-showcase">
    <?php
    $imic_slider_with_property = get_post_meta($homeID, 'imic_slider_with_property', true);
    if ($imic_slider_with_property == 1) {
        $imic_slider_image = get_post_meta($homeID, 'imic_slider_image', false);
        if (count($imic_slider_image) > 0) {
            echo '<div class="slider-mask overlay-transparent"></div>
                <!-- Start Hero Slider -->
    <div class="hero-slider flexslider clearfix" data-autoplay=' . $autoSlide . ' data-pagination="no" data-arrows=' . $sliderArrows . ' data-style=' . $sliderEffect . ' data-pause="yes">';
            echo '<ul class="slides">';
            foreach ($imic_slider_image as $custom_home_image) {
                $image = wp_get_attachment_image_src($custom_home_image, '1200-500-size');
                echo '<li class=" parallax" style="background-image:url(' . $image[0] . ')">';
                echo '</li>';
            }
            echo '</ul></div>';
        }
    } else if ($imic_slider_with_property == 2) {
        $imic_select_revolution_from_list = get_post_meta($homeID, 'imic_pages_select_revolution_from_list', true);
        echo '<div class="slider-revolution-new">';
        $imic_select_revolution_from_list = preg_replace('/\\\\/', '', $imic_select_revolution_from_list);
        echo do_shortcode($imic_select_revolution_from_list);
        echo '</div>';
    } else {
        query_posts(array('post_type' => 'property', 'post_status' => 'publish', 'posts_per_page' => -1, 'meta_query' => array(array('key' => 'imic_slide_property', 'value' => 1, 'compare' => '=='),),));
        if (have_posts()) :
            echo '<div class="slider-mask overlay-transparent"></div>
    <!-- Start Hero Slider -->
    <div class="hero-slider flexslider clearfix" data-autoplay=' . $autoSlide . ' data-pagination="no" data-arrows=' . $sliderArrows . ' data-style=' . $sliderEffect . ' data-pause="yes">';
            echo '<ul class="slides">';
            while (have_posts()) : the_post();
                $image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), '1200-500-size');
                echo '<li class=" parallax" style="background-image:url(' . $image[0] . ')">';
                echo '<div class="flex-caption">';
                $imic_property_site_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
                if (!empty($imic_property_site_address)) :
                    echo '<strong class="title">' . $imic_property_site_address;
                    $imic_property_site_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
                    if (!empty($imic_property_site_city)) {
                        echo ', <em>' . $imic_property_site_city . '</em>';
                    }
                    echo '</strong>';
                endif;
                $imic_property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
                $imic_property_price = number_format(intval($imic_property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
                if (!empty($imic_property_price)) :
                    echo imic_property_price_with_currency($imic_property_price, $currency_symbol);
                endif;
                echo '<a href="' . get_permalink(get_the_ID()) . '" class="btn btn-primary btn-block">' . esc_html__('Details', 'framework') . '</a>';
                echo '<div class="hero-agent">';
                $userImageID = get_the_author_meta('agent-image', $author_id);
                $post_author_id = get_post_field('post_author', get_the_ID());
                if (!empty($userImageID)) :
                    $image_id = imic_get_src_image_id($userImageID);
                    $userImage = wp_get_attachment_image_src($image_id, 'thumbnail');
                    echo '<img src="' . $userImage[0] . '" alt="Image" class="hero-agent-pic"/>';
                else :
                    echo '<img src="' . get_template_directory_uri() . '/assets/images/default_agent.png" alt="Image" class="hero-agent-pic"/>';
                endif;
                echo '<a href="' . get_author_posts_url($post_author_id) . '" class="hero-agent-contact" data-placement="left"  data-toggle="tooltip" data-original-title="' . esc_html__('Contact Agent', 'framework') . '"><i class="fa fa-envelope"></i></a>';
                echo '</div></div>';
                echo '</li>';
            endwhile;
            echo '</ul></div>';
        endif;
        wp_reset_query();
    } ?>
    <!-- Site Search Module -->
    <?php $output = '';
    $search_home_blocks = (isset($imic_options['search-home-blocks'])) ? $imic_options['search-home-blocks']['Enabled'] : array();
    if (count($search_home_blocks) > 1) :
        foreach ($search_home_blocks as $key => $value) {
            switch ($key) {
                case 'property_type':
                    $args_terms = array('orderby' => 'count', 'hide_empty' => true);
                    $propertyterms = get_terms('property-type', $args_terms);
                    if (!empty($propertyterms)) {
                        $output .= '<div class="search-field"><label>' . esc_html__('Property Type', 'framework') . '</label><select name="propery_type" class="form-control selectpicker">';
                        $output .= '<option selected>' . esc_html__('Property Type', 'framework') . '</option>';
                        foreach ($propertyterms as $term) {
                            $term_name = $term->name;
                            $term_slug = $term->slug;
                            $output .= "<option value='" . $term_slug . "'>" . $term_name . "</option>";
                        }
                        $output .= "</select></div>";
                    }
                    break;
                case 'contract':
                    $args_contract = array('orderby' => 'count', 'hide_empty' => true);
                    $property_contract_type_terms = get_terms('property-contract-type', $args_contract);
                    if (!empty($property_contract_type_terms)) {
                        $output .= '<div class="search-field"><label>' . esc_html__('Contract Type', 'framework') . '</label><select name="propery_contract_type" class="form-control selectpicker">';
                        $output .= '<option selected>' . esc_html__('Contract', 'framework') . '</option>';
                        foreach ($property_contract_type_terms as $term) {
                            $term_name = $term->name;
                            $term_slug = $term->slug;
                            $output .= "<option value='" . $term_slug . "'>" . $term_name . "</option>";
                        }
                        $output .= "</select></div>";
                    }
                    break;
                case 'location':
                    $imic_country_wise_city = imic_get_multiple_city();
                    if (!empty($imic_country_wise_city)) {
                        $output .= '<div class="search-field"><label>' . esc_html__('State', 'framework') . '</label><select name="propery_location" class="form-control selectpicker">
                          <option selected>' . esc_html__('State', 'framework') . '</option>';
                        foreach ($imic_country_wise_city as $key => $value) {
                            if (is_int($key)) {
                                $output .= '<optgroup label="' . $value . '">';
                            } else {
                                $output .= "<option value='" . $key . "'>" . $value . "</option>";
                            }
                        }
                        $output .= '</select></div>';
                    }
                    break;
                case 'baths':
                    $output .= '<div class="search-field"><label>' . esc_html__('Min Baths', 'framework') . '</label>
                              <select name="baths" class="form-control selectpicker">';
                    $output .= '<option selected>' . esc_html__('Any', 'framework') . '</option>';
                    $baths_options = (isset($imic_options['properties_baths'])) ? $imic_options['properties_baths'] : array();
                    if ($baths_options) {
                        foreach ($baths_options as $baths) {
                            $output .= "<option value='" . $baths . "'>" . $baths . "</option>";
                        }
                    }

                    $output .= '</select></div>';
                    break;
                case 'city':
                    $args_c = array('orderby' => 'count', 'hide_empty' => true);
                    $terms = get_terms(array('city-type'), $args_c);
                    if (!empty($terms)) {
                        $output .= '<div class="search-field"><label>' . esc_html__('City', 'framework') . '</label><select name="property_city" class="form-control selectpicker">
                    <option selected>' . esc_html__('City', 'framework') . '</option>';
                        foreach ($terms as $term_data) {
                            $output .= "<option value='" . $term_data->slug . "'>" . $term_data->name . "</option>";
                        }
                        $output .= '</select></div>';
                    }
                    break;
                case 'beds':
                    $output .= '<div class="search-field"><label>' . esc_html__('Min Beds', 'framework') . '</label>
                                <select name="beds" class="form-control selectpicker">';
                    $output .= '<option selected>' . esc_html__('Any', 'framework') . '</option>';
                    $beds_options = (isset($imic_options['properties_beds'])) ? $imic_options['properties_beds'] : array();
                    if ($beds_options) {
                        foreach ($beds_options as $beds) {
                            $output .= "<option value='" . $beds . "'>" . $beds . "</option>";
                        }
                    }

                    $output .= '</select></div>';
                    break;
                case 'price':
                    $output .= '<div class="search-field"><label>' . esc_html__('Min Price', 'framework') . '</label>
                                <select name="min_price" class="form-control selectpicker">';
                    $output .= '<option selected>' . esc_html__('Any', 'framework') . '</option>';
                    $m_price_value = (isset($imic_options['properties_price_range'])) ? $imic_options['properties_price_range'] : array();
                    if ($m_price_value) {
                        foreach ($m_price_value as $price_value) {
                            $output .= "<option value='" . $price_value . "'>" . $currency_symbol . " " . $price_value . "</option>";
                        }
                    }

                    $output .= '</select></div>';
                    $output .= '<div class="search-field">
                            <label>' . esc_html__('Max Price', 'framework') . '</label>
                            <select name="max_price" class="form-control selectpicker">';
                    $output .= '<option selected>' . esc_html__('Any', 'framework') . '</option>';
                    $max_price_value = (isset($imic_options['properties_price_range'])) ? $imic_options['properties_price_range'] : array();
                    if ($max_price_value) {
                        foreach ($max_price_value as $price_value) {
                            $output .= "<option value='" . $price_value . "'>" . $currency_symbol . " " . $price_value . "</option>";
                        }
                    }

                    $output .= '</select>
                            </div>';
                    break;
                case 'area':
                    $output .= '<div class="search-field">
                                <label>' . esc_html__('Min Area (Sq Ft)', 'framework') . '</label>
                                <input type="text" name="min_area" class="form-control input-lg" placeholder="' . esc_html__('Any', 'framework') . '">
                            </div>
                            <div class="search-field">
                                <label>' . esc_html__('Max Area (Sq Ft)', 'framework') . '</label>
                                <input type="text" name="max_area" class="form-control input-lg" placeholder="' . esc_html__('Any', 'framework') . '">
                            </div>';
                    break;
                case 'search_by':
                    $output .= '<div class="search_by">
                            <div class="search-field">
                                <label>' . esc_html__('Search By', 'framework') . '</label>
                                <select name="search_by" class="form-control selectpicker">';
                    $output .= '<option selected>' . esc_html__('Search By', 'framework') . '</option>';
                    $output .= "<option value='Id'>" . esc_html__('ID', 'framework') . "</option>";
                    $output .= "<option value='Address'>" . esc_html__('Address', 'framework') . "</option>";
                    $output .= "<option value='Pincode'>" . esc_html__('Pincode', 'framework') . "</option>";
                    $output .= '</select>
                            </div>
                            <div class="search-field">';
                    $output .= '<label>' . esc_html__('Keyword', 'framework') . '</label>
                             	<input type="text" name="search_by_keyword" class="form-control input-lg search_by_keyword" placeholder="' . esc_html__('Please enter ', 'framework') . '">
                            </div>
                            </div>';
                    break;
            }
        }



        ?>
        <div class="site-search-module">
            <div class="container">
                <div class="site-search-module-inside">
                    <form method="get" action="<?php echo home_url(); ?>/">
                        <input type="hidden" class="form-control" name="s" id="s" value="<?php esc_html_e('Search1', 'framework'); ?>" />
                        <div class="row">

                            <?php
                            echo '<div class="col-md-8 search-fields">';
                            echo '' . $output;

                            echo '</div><div class="col-md-4 search-buttons"><div class="search-button"> <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fa fa-search"></i> ' . esc_html__('Search', 'framework') . ' </button> </div>';
                            echo '<div class="search-button"> <a href="#" id="ads-trigger" class="btn btn-default btn-block"><i class="fa fa-plus"></i> <span>' . esc_html__('Advanced', 'framework') . '</span></a> </div></div>';
                            ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    <?php endif; ?>
</div>

<!-- Start Content -->
<?php
echo '<div class="main" role="main">';
echo '<div id="content" class="content full">';
echo '<div class="container">';

if (have_posts()) : while (have_posts()) : the_post();
        the_content();
    endwhile;
endif;

echo '</div><div class="margin-30"></div>';
if (isset($imic_options['opt-slides'])) {
    $fblocks = $imic_options['opt-slides'];
} else {
    $fblocks = '';
}
if (!empty($fblocks[0]['title'])) {
    echo '<div class="featured-blocks"><div class="container"><div class="row">';
    foreach ($fblocks as $fblock) {
        $link = $link_close = '';
        if ($fblock['url'] != '') {
            $link = '<a href="' . $fblock['url'] . '">';
            $link_close = '</a>';
        }
        echo '' . $link;
        echo '<div class="col-md-4 col-sm-4 featured-block">';
        if (!empty($fblock['image'])) {
            echo '<img alt="featured block" src="' . $fblock['image'] . '" class="img-thumbnail">';
        }
        if (!empty($fblock['title'])) {
            echo '<h3>' . $fblock['title'] . '</h3>';
        }
        if (!empty($fblock['description'])) {
            echo '' . $fblock['description'];
        }
        echo '</div>';
        echo '' . $link_close;
    }
    echo '</div></div></div><div class="spacer-40"></div>';
} ?>
<?php $Featured_List = get_post_meta(get_the_ID(), 'imic_home_featured_section', true);
if ($Featured_List == 1) {
    echo '<div id="featured-properties">
        <div class="container">';
    echo '<div class="row">
            <div class="col-md-12">
              <div class="block-heading">';
    $imic_home_featured_heading = get_post_meta(get_the_ID(), 'imic_home_featured_heading', true);
    $imic_home_featured_heading = !empty($imic_home_featured_heading) ? $imic_home_featured_heading : esc_html__('Featured Section Heading', 'framework');
    echo '<h4><span class="heading-icon"><i class="fa fa-star"></i></span>' . $imic_home_featured_heading . '</h4>';
    echo ' </div></div></div>';
    query_posts(array('post_type' => 'property', 'post_status' => 'publish', 'posts_per_page' => -1, 'meta_query' => array(array('key' => 'imic_featured_property', 'value' => 1, 'compare' => '=='),),));
    if (have_posts()) : ?>
        <?php $data_rtl = (isset($imic_options['enable_rtl']) && $imic_options['enable_rtl'] == 1) ? 'data-rtl="rtl"' : '';
        echo '<div class="row"><ul class="owl-carousel owl-alt-controls" data-columns="4" data-autoplay="no" data-pagination="no" data-arrows="yes" data-single-item="no" ' . $data_rtl . '>';
        while (have_posts()) : the_post();
            $property_images = get_post_meta(get_the_ID(), 'imic_property_sights', false);
            $total_images = count($property_images);
            echo '<li class="item property-block">';
            if (has_post_thumbnail()) :
                echo '<a href="' . get_permalink() . '" class="property-featured-image">';
                the_post_thumbnail('600-400-size');
                echo '<span class="images-count"><i class="fa fa-picture-o"></i> ' . $total_images . '</span>';
                $contract = wp_get_object_terms(get_the_ID(), 'property-contract-type', array('fields' => 'ids'));
                if (!empty($contract)) {
                    $term = get_term($contract[0], 'property-contract-type');
                    echo '<span class="badges badge-' . $term->slug . '">';
                    echo esc_attr($term->name);
                    echo '</span></a>';
                }
            endif;
            $imic_property_site_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
            $imic_property_site_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
            $imic_property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
            $imic_property_price = number_format(intval($imic_property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
            $property_area_location = wp_get_object_terms(get_the_ID(), 'city-type');
            $sl = '';
            $total_area_location = count($property_area_location);
            $num = 1;
            foreach ($property_area_location as $sa) {
                $conc = ($num != $total_area_location) ? '->' : '';
                $sl .= $sa->name . $conc;
                $num++;
            }
            if (!empty($imic_property_site_address) || !empty($imic_property_site_city) || !empty($imic_property_price)) {
                echo '<div class="property-info">';
                echo '<h4><a href="' . get_permalink() . '">' . get_the_title() . '</a>' . imicPropertyId(get_the_ID()) . '</h4>';
                if (!empty($imic_property_site_city)) {
                    echo '<a class="accent-color" data-original-title="' . $sl . '" data-toggle="tooltip" style="cursor:default; text-decoration:none;" href="javascript:void(0);"><span class="location">' . $imic_property_site_city . '</span></a><br>';
                }
                if (!empty($imic_property_price)) {
                    echo imic_property_price_with_currency($imic_property_price, $currency_symbol);
                }
                echo '</div>';
            }
            echo '</li>';
        endwhile;
        echo '</ul></div>';
    endif;
    wp_reset_query();
    echo '</div>
                          </div><div class="spacer-40"></div>';
}
echo '<div class="container">';
$Recent_List = get_post_meta(get_the_ID(), 'imic_home_recent_section', true);
if (isset($imic_options['sidebar_width']) && $imic_options['sidebar_width'] != '') {
    $ContentWidth = 12 - $imic_options['sidebar_width'];
    $SidebarWidth = $imic_options['sidebar_width'];
}
$pageSidebarWidth = get_post_meta($homeID, 'imic_select_sidebar_width', true);
if ($pageSidebarWidth != '') {
    $ContentWidth = 12 - $pageSidebarWidth;
    $SidebarWidth = $pageSidebarWidth;
}
$pageSidebar = get_post_meta($homeID, 'imic_select_sidebar_from_list', true);
if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) {
    $class = $ContentWidth;
} else {
    $class = 12;
}
if ($Recent_List == 1) {
    echo '<div class="row"><div class="col-md-' . $class . '" id="content-col"><div class="block-heading">';
    $imic_home_recent_heading = get_post_meta(get_the_ID(), 'imic_home_recent_heading', true);
    $imic_home_recent_heading = !empty($imic_home_recent_heading) ? $imic_home_recent_heading : esc_html__('Recent Listed', 'framework');
    echo '<h4><span class="heading-icon"><i class="fa fa-leaf"></i></span>' . $imic_home_recent_heading . '</h4>';
    $imic_home_recent_more = get_post_meta(get_the_ID(), 'imic_home_recent_more', true);
    if (!empty($imic_home_recent_more)) {
        echo '<a href="' . $imic_home_recent_more . '" class="btn btn-primary btn-sm pull-right">' . esc_html__('View more properties ', 'framework') . '<i class="fa fa-long-arrow-right"></i></a>';
    }
    echo ' </div><div class="property-listing">';
    $Recent_Page = get_post_meta(get_the_ID(), 'imic_home_recent_property_no', true);
    query_posts(array('post_type' => 'property', 'post_status' => 'publish', 'posts_per_page' => $Recent_Page));
    if (have_posts()) :
        echo '<ul>';
        while (have_posts()) : the_post();
            $property_images = get_post_meta(get_the_ID(), 'imic_property_sights', false);
            $total_images = count($property_images);
            $property_area = get_post_meta(get_the_ID(), 'imic_property_area', true);
            $property_baths = get_post_meta(get_the_ID(), 'imic_property_baths', true);
            $property_beds = get_post_meta(get_the_ID(), 'imic_property_beds', true);
            $property_parking = get_post_meta(get_the_ID(), 'imic_property_parking', true);
            $property_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
            $property_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
            $property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
            $property_price = number_format(intval($property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
            $contract = wp_get_object_terms(get_the_ID(), 'property-contract-type', array('fields' => 'ids'));
            if (!empty($contract)) {
                $term = get_term($contract[0], 'property-contract-type');
            }
            echo '<li class="type-rent col-md-12">';
            if (has_post_thumbnail()) :
                echo '<div class="col-md-4">
                    		<a href="' . get_permalink() . '" class="property-featured-image">';
                the_post_thumbnail('600-400-size');
                echo '<span class="images-count"><i class="fa fa-picture-o"></i> ' . $total_images . '</span>';
                if (!empty($term)) {
                    echo '<span class="badges badge-' . $term->slug . '">' . $term->name . '</span>';
                }
                echo '</a>
                   	</div>';
            endif;
            $imic_property_site_address = get_post_meta(get_the_ID(), 'imic_property_site_address', true);
            $imic_property_site_city = get_post_meta(get_the_ID(), 'imic_property_site_city', true);
            $imic_property_price = get_post_meta(get_the_ID(), 'imic_property_price', true);
            $imic_property_price = number_format(intval($imic_property_price), $currency_decimal_point, $currency_decimal_separator, $currency_thousand_separator);
            $property_area_location = wp_get_object_terms(get_the_ID(), 'city-type');
            $sl = '';
            $total_area_location = count($property_area_location);
            $num = 1;
            foreach ($property_area_location as $sa) {
                $conc = ($num != $total_area_location) ? '->' : '';
                $sl .= $sa->name . $conc;
                $num++;
            }
            echo '<div class="col-md-8">';
            if (!empty($imic_property_site_address) || !empty($imic_property_site_city) || !empty($imic_property_price)) {
                echo '<div class="property-info">';
                if (!empty($imic_property_price)) {
                    echo imic_property_price_with_currency($imic_property_price, $currency_symbol);
                }
                echo '<h3><a href="' . get_permalink() . '">' . get_the_title() . '</a>' . imicPropertyId(get_the_ID()) . '</h3>';
                if (!empty($imic_property_site_city)) {
                    echo '<a class="accent-color" data-original-title="' . $sl . '" data-toggle="tooltip" style="cursor:default; text-decoration:none;" href="javascript:void(0);"><span class="location">' . $imic_property_site_city . '</span></a>';
                }
                echo imic_excerpt(10);
                echo '</div>';
            }
            $imic_property_area = get_post_meta(get_the_ID(), 'imic_property_area', true);
            $imic_property_baths = get_post_meta(get_the_ID(), 'imic_property_baths', true);
            $imic_property_beds = get_post_meta(get_the_ID(), 'imic_property_beds', true);
            $imic_property_parking = get_post_meta(get_the_ID(), 'imic_property_parking', true);
            if (!empty($imic_property_area) || !empty($imic_property_baths) || !empty($imic_property_beds) || !empty($imic_property_parking)) :
                echo '<div class="property-amenities clearfix">';
                if (!empty($imic_property_area)) :
                    echo '<span class="area">' . $imic_property_area . '<strong></strong>' . esc_html__('Area', 'framework') . '</span>';
                endif;
                if (!empty($imic_property_baths)) :
                    echo '<span class="baths"><strong>' . $imic_property_baths . '</strong>' . esc_html__('Baths', 'framework') . '</span>';
                endif;
                if (!empty($imic_property_beds)) :
                    echo '<span class="beds"><strong>' . $imic_property_beds . '</strong>' . esc_html__('Beds', 'framework') . '</span>';
                endif;
                if (!empty($imic_property_parking)) :
                    echo '<span class="parking"><strong>' . $imic_property_parking . '</strong>' . esc_html__('Parking', 'framework') . '</span>';
                endif;
                echo '</div>';
            endif;
            echo '</div></li>';
        endwhile;
        echo '</ul>';
    endif;
    echo '</div></div>';
}  ?>
<!-- Start Sidebar -->
<?php if (!empty($pageSidebar) && is_active_sidebar($pageSidebar)) { ?>
    <div class="sidebar right-sidebar col-md-<?php echo esc_attr($SidebarWidth); ?>" id="sidebar-col">
        <?php dynamic_sidebar($pageSidebar); ?>
    </div>
<?php }
echo '</div></div>';
$Partner_Heading = get_post_meta($homeID, 'imic_home_partner_heading', true);
$Partner_Heading_Url = get_post_meta($homeID, 'imic_home_partner_url', true);
$Partner_Section = get_post_meta($homeID, 'imic_home_partners_section', true);
$Partner_Heading = !empty($Partner_Heading) ? $Partner_Heading : esc_html__('Our Partners', 'framework');
if ($Partner_Section != 0) {
    echo '<div class="container"><div class="block-heading">';
    echo '<h4><span class="heading-icon"><i class="fa fa-users"></i></span>' . $Partner_Heading . '</h4>';
    if ($Partner_Heading_Url != '') {
        echo '<a href="' . $Partner_Heading_Url . '" class="btn btn-primary btn-sm pull-right">' . esc_html__('All partners ', 'framework') . '<i class="fa fa-long-arrow-right"></i></a>';
    }
    echo '</div>';
    query_posts(array('post_type' => 'partner', 'posts_per_page' => -1));
    if (have_posts()) :
        echo '<div class="row">' ?>
        <?php $data_rtl = (isset($imic_options['enable_rtl']) && $imic_options['enable_rtl'] == 1) ? 'data-rtl="rtl"' : '';
        echo '<ul class="owl-carousel owl-alt-controls" data-columns="4" data-autoplay="no" data-pagination="no" data-arrows="no" data-single-item="no" ' . $data_rtl . '>';
        while (have_posts()) : the_post();
            $partner_logo = get_post_meta(get_the_ID(), 'imic_partner_logo', true);
            $partner_url = get_post_meta(get_the_ID(), 'imic_partner_url', true);
            if (!empty($partner_logo)) {
                $userLoadedImgSrc = wp_get_attachment_image_src($partner_logo, '140-47-size');
                $userImgSrc = $userLoadedImgSrc[0];
            }
            $target = get_post_meta(get_the_ID(), 'imic_partner_target', true);
            if ($target == 1) {
                $target = "self";
            } else {
                $target = "blank";
            }
            if ($partner_url != '') {
                echo '<li class="item"> <a href="' . $partner_url . '" target="_' . $target . '"><img src="' . $userImgSrc . '" alt="Image"></a> </li>';
            } else {
                echo '<li class="item"> <img src="' . $userImgSrc . '" alt="Image"></li>';
            }
        endwhile;
        echo '</ul></div>';
    endif;
    wp_reset_query();
    echo '</div>';
}
echo '</div>';
get_footer(); ?>